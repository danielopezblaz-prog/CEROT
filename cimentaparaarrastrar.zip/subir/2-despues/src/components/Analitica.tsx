import Script from "next/script";

/**
 * ————————————————————————————————————————————————————————————————
 *  ANALÍTICA SIN COOKIES
 *
 *  No se carga nada mientras no configures las variables de entorno,
 *  así que el sitio arranca sin medición y sin banner.
 *
 *  Está pensada para herramientas de medición de audiencia que encajan
 *  en la exención del art. 22.2 LSSI-CE según la guía de la AEPD sobre
 *  cookies de medición de audiencia (11-01-2024). Para acogerte a ella,
 *  la herramienta que configures debe cumplir las cinco condiciones:
 *
 *    1 · medir únicamente este sitio, nada más;
 *    2 · tratarse solo por cuenta del editor;
 *    3 · no permitir seguir al usuario entre webs o aplicaciones;
 *    4 · no combinar los datos con otros de terceros;
 *    5 · no ceder ni reutilizar los datos para otra finalidad.
 *
 *  Plausible, Umami y Matomo autoalojado (sin cookies) cumplen las cinco.
 *  Google Analytics NO: si algún día lo instalas —o el píxel de Meta, o
 *  las conversiones de Google Ads— hacen falta banner con CMP certificado
 *  y Consent Mode v2, y hay que reescribir la política de privacidad, que
 *  hoy afirma que este sitio no usa cookies de seguimiento.
 *
 *  Variables (todas NEXT_PUBLIC_, se inyectan en el cliente):
 *    NEXT_PUBLIC_ANALITICA_SRC      URL del script.
 *    NEXT_PUBLIC_ANALITICA_DOMINIO  dominio medido (estilo Plausible).
 *    NEXT_PUBLIC_ANALITICA_ID       id de sitio (estilo Umami).
 * ————————————————————————————————————————————————————————————————
 */

const SRC = process.env.NEXT_PUBLIC_ANALITICA_SRC ?? "";
const DOMINIO = process.env.NEXT_PUBLIC_ANALITICA_DOMINIO ?? "";
const ID = process.env.NEXT_PUBLIC_ANALITICA_ID ?? "";

export function Analitica() {
  /* Sin script configurado no se pinta nada: ni petición, ni almacenamiento. */
  if (!SRC || (!DOMINIO && !ID)) return null;

  return (
    <>
      {/* Cola de eventos: recoge los disparados antes de que cargue el script. */}
      {DOMINIO && (
        <Script id="analitica-cola" strategy="afterInteractive">
          {`window.plausible=window.plausible||function(){(window.plausible.q=window.plausible.q||[]).push(arguments)}`}
        </Script>
      )}
      <Script
        src={SRC}
        strategy="afterInteractive"
        data-domain={DOMINIO || undefined}
        data-website-id={ID || undefined}
      />
    </>
  );
}
