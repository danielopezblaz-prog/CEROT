"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const ENLACES = [
  { destino: "/crm", texto: "Panel", icono: "▦", exacto: true },
  { destino: "/crm/leads", texto: "Leads", icono: "☰", exacto: false },
  { destino: "/crm/pipeline", texto: "Pipeline", icono: "⇶", exacto: false },
  { destino: "/crm/tareas", texto: "Tareas", icono: "✓", exacto: false },
] as const;

const ENLACES_ADMIN = [
  { destino: "/crm/usuarios", texto: "Usuarios", icono: "◉", exacto: false },
] as const;

const ENLACES_FINAL = [
  { destino: "/crm/ajustes", texto: "Ajustes", icono: "⚙", exacto: false },
] as const;

function listaEnlaces(esAdmin: boolean) {
  return [...ENLACES, ...(esAdmin ? ENLACES_ADMIN : []), ...ENLACES_FINAL];
}

function Enlaces({
  esAdmin,
  alPulsar,
}: {
  esAdmin: boolean;
  alPulsar?: () => void;
}) {
  const ruta = usePathname();
  const activo = (destino: string, exacto: boolean) =>
    exacto ? ruta === destino : ruta.startsWith(destino);

  return (
    <div className="grid gap-1">
      {listaEnlaces(esAdmin).map((enlace) => (
        <Link
          key={enlace.destino}
          href={enlace.destino}
          onClick={alPulsar}
          aria-current={activo(enlace.destino, enlace.exacto) ? "page" : undefined}
          className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-[14px] font-semibold transition-colors ${
            activo(enlace.destino, enlace.exacto)
              ? "bg-verde text-white"
              : "text-gris hover:bg-lavado hover:text-tinta"
          }`}
        >
          <span aria-hidden="true" className="w-4 text-center font-mono text-[13px]">
            {enlace.icono}
          </span>
          {enlace.texto}
        </Link>
      ))}
    </div>
  );
}

/** Navegación fija de escritorio (columna izquierda). */
export function NavEscritorio({ esAdmin }: { esAdmin: boolean }) {
  return (
    <nav aria-label="Secciones del CRM" className="sticky top-6">
      <Enlaces esAdmin={esAdmin} />
    </nav>
  );
}

/** Botón + panel desplegable para móvil (vive en la cabecera). */
export function NavMovil({ esAdmin }: { esAdmin: boolean }) {
  const [abierta, setAbierta] = useState(false);

  return (
    <div className="lg:hidden">
      <button
        type="button"
        onClick={() => setAbierta((estado) => !estado)}
        aria-expanded={abierta}
        aria-controls="navegacion-crm-movil"
        className="rounded-full border border-linea-fuerte px-3.5 py-2 text-[13px] font-semibold text-tinta"
      >
        {abierta ? "Cerrar" : "Menú"}
      </button>
      {abierta && (
        <nav
          id="navegacion-crm-movil"
          aria-label="Secciones del CRM"
          className="absolute top-full right-0 left-0 z-40 border-b border-linea bg-superficie p-3 shadow-[0_20px_50px_rgba(24,33,28,.12)]"
        >
          <Enlaces esAdmin={esAdmin} alPulsar={() => setAbierta(false)} />
        </nav>
      )}
    </div>
  );
}
