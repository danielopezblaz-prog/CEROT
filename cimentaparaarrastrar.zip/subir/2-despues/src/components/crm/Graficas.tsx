import { fechaCorta } from "@/lib/crm/fechas";

/**
 * Gráficos del dashboard, renderizados en servidor.
 * Método: un solo tono (verde de marca) por gráfico — la identidad la
 * llevan las etiquetas de fila, nunca el color; tooltips nativos con
 * <title>; rejilla recesiva; extremos de dato redondeados (4px).
 */

const VERDE = "#25714f";
const LINEA = "rgba(24,33,28,.1)";

export function TarjetaGrafica({
  titulo,
  children,
}: {
  titulo: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-3xl border border-linea bg-superficie p-5">
      <h2 className="font-mono text-[9px] tracking-[0.14em] text-verde uppercase">{titulo}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

export function Kpi({
  valor,
  etiqueta,
  alerta = false,
}: {
  valor: string | number;
  etiqueta: string;
  alerta?: boolean;
}) {
  return (
    <div className="rounded-2xl border border-linea bg-superficie px-4 py-3.5">
      <p
        className={`font-mono text-[26px] leading-none font-bold tabular-nums ${
          alerta ? "text-[#8a5b5b]" : "text-tinta"
        }`}
      >
        {valor}
      </p>
      <p className="mt-1.5 font-mono text-[8.5px] leading-snug tracking-[0.12em] text-gris uppercase">
        {etiqueta}
      </p>
    </div>
  );
}

export function VacioGrafica({ texto }: { texto: string }) {
  return (
    <p className="rounded-xl border border-dashed border-linea-fuerte px-4 py-8 text-center font-mono text-[9.5px] tracking-[0.1em] text-gris uppercase">
      {texto}
    </p>
  );
}

/** Evolución temporal: área + línea de 2px con puntos con tooltip nativo. */
export function LineaTemporal({ datos }: { datos: { dia: Date; total: number }[] }) {
  if (datos.length === 0 || datos.every((punto) => punto.total === 0)) {
    return <VacioGrafica texto="Sin leads en este periodo" />;
  }

  const ancho = 600;
  const alto = 200;
  const margen = { izq: 30, der: 10, arr: 10, aba: 26 };
  const maximo = Math.max(4, ...datos.map((punto) => punto.total));
  const anchoUtil = ancho - margen.izq - margen.der;
  const altoUtil = alto - margen.arr - margen.aba;
  const x = (indice: number) =>
    margen.izq + (datos.length === 1 ? anchoUtil / 2 : (indice / (datos.length - 1)) * anchoUtil);
  const y = (valor: number) => margen.arr + altoUtil - (valor / maximo) * altoUtil;

  const linea = datos.map((punto, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(punto.total).toFixed(1)}`).join(" ");
  const area = `${linea} L${x(datos.length - 1).toFixed(1)},${y(0)} L${x(0).toFixed(1)},${y(0)} Z`;
  const pasoEtiqueta = Math.max(1, Math.ceil(datos.length / 6));
  const rejilla = [0.5, 1].map((f) => Math.round(maximo * f));

  return (
    <svg viewBox={`0 0 ${ancho} ${alto}`} className="w-full" role="img" aria-label="Evolución de leads en el tiempo">
      {rejilla.map((valor) => (
        <g key={valor}>
          <line x1={margen.izq} x2={ancho - margen.der} y1={y(valor)} y2={y(valor)} stroke={LINEA} strokeWidth="1" />
          <text x={margen.izq - 6} y={y(valor) + 3} textAnchor="end" fontSize="9" fill="#5b6862" fontFamily="ui-monospace, monospace">
            {valor}
          </text>
        </g>
      ))}
      <line x1={margen.izq} x2={ancho - margen.der} y1={y(0)} y2={y(0)} stroke="rgba(24,33,28,.2)" strokeWidth="1" />
      <path d={area} fill={VERDE} opacity="0.08" />
      <path d={linea} fill="none" stroke={VERDE} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {datos.map((punto, i) => (
        <g key={i}>
          {punto.total > 0 && (
            <circle cx={x(i)} cy={y(punto.total)} r="3.5" fill="#ffffff" stroke={VERDE} strokeWidth="2">
              <title>{`${fechaCorta(punto.dia)}: ${punto.total} lead${punto.total === 1 ? "" : "s"}`}</title>
            </circle>
          )}
          {/* objetivo de puntería mayor que la marca */}
          <circle cx={x(i)} cy={y(punto.total)} r="9" fill="transparent">
            <title>{`${fechaCorta(punto.dia)}: ${punto.total} lead${punto.total === 1 ? "" : "s"}`}</title>
          </circle>
          {i % pasoEtiqueta === 0 && (
            <text x={x(i)} y={alto - 8} textAnchor="middle" fontSize="9" fill="#5b6862" fontFamily="ui-monospace, monospace">
              {fechaCorta(punto.dia)}
            </text>
          )}
        </g>
      ))}
    </svg>
  );
}

/** Barras horizontales de un solo tono; identidad en la etiqueta de fila. */
export function BarrasH({
  filas,
  formato = (valor: number) => String(valor),
  maximo,
}: {
  filas: { etiqueta: string; valor: number; punto?: string }[];
  formato?: (valor: number) => string;
  maximo?: number;
}) {
  if (filas.length === 0 || filas.every((fila) => fila.valor === 0)) {
    return <VacioGrafica texto="Sin datos en este periodo" />;
  }
  const tope = maximo ?? Math.max(1, ...filas.map((fila) => fila.valor));

  return (
    <div className="grid gap-2.5">
      {filas.map((fila) => (
        <div key={fila.etiqueta} className="group grid grid-cols-[150px_1fr_44px] items-center gap-2.5">
          <p className="flex items-center gap-1.5 truncate text-[12px] text-tinta" title={fila.etiqueta}>
            {fila.punto && (
              <span
                aria-hidden="true"
                className="inline-block h-2 w-2 shrink-0 rounded-full"
                style={{ backgroundColor: fila.punto }}
              />
            )}
            {fila.etiqueta}
          </p>
          <div className="h-[14px] overflow-hidden rounded-r-[4px] bg-lavado" title={`${fila.etiqueta}: ${formato(fila.valor)}`}>
            <div
              className="h-full rounded-r-[4px] bg-verde transition-opacity group-hover:opacity-80"
              style={{ width: `${Math.max(fila.valor > 0 ? 2 : 0, (fila.valor / tope) * 100)}%` }}
            />
          </div>
          <p className="text-right font-mono text-[11px] font-bold text-tinta tabular-nums">
            {formato(fila.valor)}
          </p>
        </div>
      ))}
    </div>
  );
}
