import Link from "next/link";
import { estadoLead, PRIORIDADES } from "@/db/catalogo";

/** Chip de estado con el color del catálogo. */
export function ChipEstado({ clave }: { clave: string }) {
  const estado = estadoLead(clave);
  if (!estado) return <span className="text-[12px] text-gris">{clave}</span>;
  const claro = estado.clave === "junta";
  return (
    <span
      className="etiqueta-cota inline-block rounded-full px-2.5 py-1 text-[8.5px] whitespace-nowrap"
      style={{ backgroundColor: estado.color, color: claro ? "#18211c" : "#ffffff" }}
    >
      {estado.nombre}
    </span>
  );
}

export function ChipPrioridad({ clave }: { clave: string }) {
  const prioridad = PRIORIDADES.find((p) => p.clave === clave);
  const estilo =
    clave === "alta"
      ? "border-verde text-verde"
      : clave === "baja"
        ? "border-linea-fuerte text-gris"
        : "border-malla text-verde-oscuro";
  return (
    <span
      className={`etiqueta-cota inline-block rounded-full border px-2 py-0.5 text-[8.5px] ${estilo}`}
    >
      {prioridad?.nombre ?? clave}
    </span>
  );
}

export function ChipDuplicado() {
  return (
    <span className="etiqueta-cota inline-block rounded-full border border-[#b98a3c]/60 bg-[#b98a3c]/10 px-2 py-0.5 text-[8.5px] text-[#8a6528]">
      Posible duplicado
    </span>
  );
}

/** Paginación por enlaces conservando el resto de parámetros. */
export function Paginacion({
  pagina,
  paginas,
  total,
  base,
  parametros,
}: {
  pagina: number;
  paginas: number;
  total: number;
  base: string;
  parametros: Record<string, string | undefined>;
}) {
  const enlace = (destino: number) => {
    const params = new URLSearchParams();
    for (const [clave, valor] of Object.entries(parametros)) {
      if (valor) params.set(clave, valor);
    }
    params.set("pagina", String(destino));
    return `${base}?${params.toString()}`;
  };

  if (paginas <= 1) {
    return (
      <p className="font-mono text-[10.5px] tracking-[0.08em] text-gris uppercase">
        {total} resultado{total === 1 ? "" : "s"}
      </p>
    );
  }

  return (
    <nav aria-label="Paginación" className="flex flex-wrap items-center gap-3">
      <p className="font-mono text-[10.5px] tracking-[0.08em] text-gris uppercase">
        {total} resultados · página {pagina} de {paginas}
      </p>
      <div className="flex gap-2">
        {pagina > 1 && (
          <Link
            href={enlace(pagina - 1)}
            className="rounded-full border border-linea-fuerte px-3.5 py-1.5 text-[12.5px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde"
          >
            ← Anterior
          </Link>
        )}
        {pagina < paginas && (
          <Link
            href={enlace(pagina + 1)}
            className="rounded-full border border-linea-fuerte px-3.5 py-1.5 text-[12.5px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde"
          >
            Siguiente →
          </Link>
        )}
      </div>
    </nav>
  );
}

/** Estado vacío con la voz de la marca. */
export function VistaVacia({
  titulo,
  texto,
  accion,
}: {
  titulo: string;
  texto: string;
  accion?: React.ReactNode;
}) {
  return (
    <div className="rounded-3xl border border-dashed border-linea-fuerte bg-superficie/60 px-6 py-14 text-center">
      <p className="font-mono text-[28px] text-verde" aria-hidden="true">
        ⌀
      </p>
      <h3 className="mt-3 text-[17px] font-bold tracking-display">{titulo}</h3>
      <p className="mx-auto mt-1.5 max-w-[44ch] text-[13.5px] text-gris">{texto}</p>
      {accion && <div className="mt-5">{accion}</div>}
    </div>
  );
}
