"use client";

import { aliados } from "@/content";
import { conNegritas } from "@/lib/texto";
import { Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";

export function Aliados() {
  return (
    <section aria-label="Administradores y empresas" className="mx-auto max-w-[1120px] px-5 py-20 sm:px-8 md:py-28">
      <Reveal>
        <Cejilla>{aliados.cejilla}</Cejilla>
        <h2 className="max-w-[22ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display">
          {aliados.titulo}
        </h2>
      </Reveal>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        {aliados.bloques.map((bloque, i) => (
          <Reveal key={bloque.titulo} retraso={i * 0.08}>
            <article className="flex h-full flex-col rounded-3xl border border-dashed border-linea-fuerte p-6 transition-colors hover:border-verde/50 sm:p-7">
              <h3 className="text-[19px] font-extrabold tracking-display">
                {bloque.titulo}
              </h3>
              <p className="mt-2.5 flex-1 text-[15px] leading-relaxed text-gris">
                {conNegritas(bloque.texto)}
              </p>
              <a
                href={"ruta" in bloque && bloque.ruta ? bloque.ruta : "#contacto"}
                className="mt-5 inline-flex items-center gap-2 self-start rounded-md text-[15px] font-semibold text-verde transition-colors hover:text-verde-oscuro"
              >
                {bloque.enlace}
                <span aria-hidden="true" className="font-mono">→</span>
              </a>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
