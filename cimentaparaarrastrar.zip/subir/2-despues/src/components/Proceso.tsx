"use client";

import { useRef } from "react";
import {
  m,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
  type MotionValue,
} from "framer-motion";
import { comoFunciona } from "@/content";
import { conNegritas } from "@/lib/texto";
import { Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";

const TOTAL = comoFunciona.pasos.length;

/** Nodo de la línea temporal: se "sella" cuando el trazo lo alcanza. */
function Nodo({
  indice,
  decision,
  trazo,
  sinMovimiento,
}: {
  indice: number;
  decision: boolean;
  trazo: MotionValue<number>;
  sinMovimiento: boolean;
}) {
  const umbral = indice / (TOTAL - 1);
  const sello = useTransform(
    trazo,
    [Math.max(0, umbral - 0.06), Math.min(1, umbral + 0.02)],
    [0, 1],
  );

  return (
    <span
      aria-hidden="true"
      className="absolute top-0 left-0 flex h-10 w-10 items-center justify-center rounded-full border border-verde/30 bg-superficie font-mono text-[13px] font-semibold text-verde shadow-[0_2px_10px_rgba(24,33,28,.06)]"
    >
      {indice + 1}
      <m.span
        className={`absolute inset-0 flex items-center justify-center rounded-full font-mono text-[13px] font-semibold ${
          decision ? "bg-malla text-tinta" : "bg-verde text-white"
        }`}
        style={{ opacity: sinMovimiento ? 1 : sello }}
      >
        {indice + 1}
      </m.span>
    </span>
  );
}

/**
 * Cómo funciona: expediente a dos carriles. La línea se traza con el
 * scroll y va sellando nodos; cada paso dice quién actúa (nosotros /
 * la junta), qué entrega, y el marcador sticky muestra el paso activo.
 */
export function Proceso() {
  const sinMovimiento = useReducedMotion();
  const refLista = useRef<HTMLOListElement>(null);
  const { scrollYProgress } = useScroll({
    target: refLista,
    offset: ["start 0.72", "end 0.55"],
  });
  const trazo = useSpring(scrollYProgress, { stiffness: 120, damping: 24 });

  const indiceActivo = useTransform(trazo, (v) =>
    Math.min(TOTAL - 1, Math.max(0, Math.round(v * (TOTAL - 1)))),
  );
  const numeroActivo = useTransform(indiceActivo, (i) => `0${i + 1}`);
  const tituloActivo = useTransform(
    indiceActivo,
    (i) => comoFunciona.pasos[i].titulo,
  );

  return (
    <section id="como-funciona" className="bg-lavado/60">
      <div className="mx-auto max-w-[1120px] px-5 py-20 sm:px-8 md:py-28">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,4fr)_minmax(0,7fr)] lg:gap-14">
          {/* ————— Cabecera sticky con el marcador ————— */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <Reveal>
              <Cejilla>{comoFunciona.cejilla}</Cejilla>
              <h2 className="max-w-[18ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display">
                {comoFunciona.titulo}
              </h2>
              <p className="mt-4 max-w-[44ch] text-[15px] leading-relaxed text-gris">
                {comoFunciona.intro}
              </p>

              <div className="mt-5 flex flex-wrap gap-2">
                <span className="etiqueta-cota inline-flex items-center gap-2 rounded-full bg-verde px-3 py-1.5 text-[9px] text-white">
                  {comoFunciona.leyenda.nosotros}
                </span>
                <span className="etiqueta-cota inline-flex items-center gap-2 rounded-full bg-malla px-3 py-1.5 text-[9px] text-tinta">
                  {comoFunciona.leyenda.junta}
                </span>
              </div>
            </Reveal>

            {/* marcador del paso activo, dibujado en línea como el resto de la marca */}
            <div aria-hidden="true" className="mt-10 hidden lg:block">
              <m.p
                className="font-mono text-[104px] leading-none font-bold tracking-display text-transparent tabular-nums"
                style={{ WebkitTextStroke: "1.5px #25714f" }}
              >
                {numeroActivo}
              </m.p>
              <div className="mt-3 flex items-center gap-3">
                <span className="inline-block h-px w-8 bg-verde" />
                <m.p className="etiqueta-cota text-[10px] text-verde">
                  {tituloActivo}
                </m.p>
              </div>
            </div>
          </div>

          {/* ————— Línea temporal ————— */}
          <ol ref={refLista} className="relative">
            <span
              aria-hidden="true"
              className="absolute top-3 bottom-3 left-[19px] w-px bg-linea-fuerte"
            />
            <m.span
              aria-hidden="true"
              className="absolute top-3 bottom-3 left-[19px] w-px origin-top bg-verde"
              style={{ scaleY: sinMovimiento ? 1 : trazo }}
            />

            {comoFunciona.pasos.map((paso, i) => (
              <li key={paso.titulo} className="relative pb-6 pl-16 last:pb-0">
                <Nodo
                  indice={i}
                  decision={paso.quien === "junta"}
                  trazo={trazo}
                  sinMovimiento={!!sinMovimiento}
                />
                <Reveal retraso={0.05}>
                  <article className="rounded-3xl border border-linea bg-superficie p-5 shadow-[0_2px_14px_rgba(24,33,28,.04)] sm:p-6">
                    <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1.5">
                      <h3 className="text-[17.5px] font-bold tracking-display">
                        {paso.titulo}
                      </h3>
                      <span className="etiqueta-cota rounded-full bg-malla-suave px-2.5 py-1 text-[9px] text-verde">
                        {paso.plazo}
                      </span>
                      <span
                        className={`etiqueta-cota ml-auto rounded-full px-2.5 py-1 text-[9px] ${
                          paso.quien === "junta"
                            ? "bg-malla text-tinta"
                            : "bg-verde text-white"
                        }`}
                      >
                        {paso.quien === "junta"
                          ? comoFunciona.leyenda.junta
                          : comoFunciona.leyenda.nosotros}
                      </span>
                    </div>
                    <p className="mt-2 max-w-[58ch] text-[15px] leading-relaxed text-gris">
                      {conNegritas(paso.texto)}
                    </p>
                    <p className="mt-3.5 border-t border-dashed border-linea-fuerte pt-3 font-mono text-[10px] leading-relaxed tracking-[0.08em] text-verde uppercase">
                      <span aria-hidden="true">→ </span>
                      {comoFunciona.recibes}: {paso.entregable}
                    </p>
                  </article>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>

        {/* ————— Balance final ————— */}
        <Reveal retraso={0.08}>
          <div className="mt-12 flex flex-col gap-5 rounded-3xl border border-dashed border-linea-fuerte bg-superficie/70 px-6 py-6 sm:flex-row sm:items-center sm:justify-between sm:gap-8 sm:px-8">
            <p className="max-w-[22ch] text-[16px] leading-snug font-bold tracking-display">
              {comoFunciona.balance.titulo}
            </p>
            <dl className="flex flex-wrap gap-x-10 gap-y-4">
              {comoFunciona.balance.datos.map((dato) => (
                <div key={dato.etiqueta}>
                  <dd className="font-mono text-[34px] leading-none font-bold text-verde tabular-nums">
                    {dato.valor}
                  </dd>
                  <dt className="etiqueta-cota mt-2 text-[9px] text-gris">
                    {dato.etiqueta}
                  </dt>
                </div>
              ))}
            </dl>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
