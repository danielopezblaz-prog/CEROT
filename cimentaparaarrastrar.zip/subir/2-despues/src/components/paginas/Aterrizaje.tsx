import dynamic from "next/dynamic";
import Link from "next/link";
import { marca, nav } from "@/content";
import type { Bloque, Pagina } from "@/content-paginas";
import { conNegritas, sinMarcas } from "@/lib/texto";
import { Nav } from "@/components/Nav";
import { PieDePagina } from "@/components/PieDePagina";
import { Cejilla } from "@/components/Compartidos";
import { Reveal } from "@/components/Reveal";

/* El formulario es lo último de la página: se trocea igual que en la home. */
const Formulario = dynamic(() =>
  import("@/components/Formulario").then((m) => m.Formulario),
);

/* ————————————————————————————————————————————————————————————
   Piezas de bloque. Reutilizan el mismo sistema visual que la home:
   estas páginas son puertas distintas a la misma casa, no microsites.
   ———————————————————————————————————————————————————————————— */

function Titulo({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="text-[clamp(21px,3.4vw,27px)] leading-[1.18] font-extrabold tracking-display">
      {children}
    </h2>
  );
}

function Parrafo({ texto }: { texto: string }) {
  return (
    <p className="mt-3 max-w-[68ch] text-[15.5px] leading-relaxed text-gris">
      {conNegritas(texto)}
    </p>
  );
}

function BloqueTexto({ bloque }: { bloque: Extract<Bloque, { tipo: "texto" }> }) {
  return (
    <section>
      <Titulo>{bloque.titulo}</Titulo>
      {bloque.parrafos.map((parrafo) => (
        <Parrafo key={parrafo} texto={parrafo} />
      ))}
    </section>
  );
}

function BloquePuntos({
  bloque,
}: {
  bloque: Extract<Bloque, { tipo: "puntos" }>;
}) {
  return (
    <section>
      <Titulo>{bloque.titulo}</Titulo>
      {bloque.intro && <Parrafo texto={bloque.intro} />}
      <ul className="mt-5 grid gap-3 sm:grid-cols-2">
        {bloque.puntos.map((punto) => (
          <li
            key={punto.titulo}
            className="rounded-2xl border border-linea bg-superficie p-5"
          >
            <h3 className="text-[15px] font-bold tracking-display">
              {punto.titulo}
            </h3>
            <p className="mt-1.5 text-[14px] leading-relaxed text-gris">
              {conNegritas(punto.texto)}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}

function BloquePasos({ bloque }: { bloque: Extract<Bloque, { tipo: "pasos" }> }) {
  return (
    <section>
      <Titulo>{bloque.titulo}</Titulo>
      {bloque.intro && <Parrafo texto={bloque.intro} />}
      <ol className="mt-5 grid gap-4">
        {bloque.pasos.map((paso, indice) => (
          <li key={paso.titulo} className="flex gap-4">
            <span
              aria-hidden="true"
              className="mt-0.5 w-[26px] shrink-0 font-mono text-[13px] font-bold text-verde tabular-nums"
            >
              {String(indice + 1).padStart(2, "0")}
            </span>
            <div className="border-b border-linea pb-4">
              <h3 className="text-[15px] font-bold tracking-display">
                {paso.titulo}
              </h3>
              <p className="mt-1 max-w-[62ch] text-[14.5px] leading-relaxed text-gris">
                {conNegritas(paso.texto)}
              </p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}

function BloqueTabla({ bloque }: { bloque: Extract<Bloque, { tipo: "tabla" }> }) {
  return (
    <section>
      <Titulo>{bloque.titulo}</Titulo>
      {bloque.intro && <Parrafo texto={bloque.intro} />}
      <div className="mt-5 overflow-x-auto rounded-2xl border border-linea bg-superficie">
        <table className="w-full min-w-[560px] border-collapse text-[14px]">
          <thead>
            <tr>
              {bloque.cabeceras.map((cabecera) => (
                <th
                  key={cabecera}
                  scope="col"
                  className="etiqueta-cota border-b-2 border-verde px-4 pt-4 pb-2.5 text-left text-[9px] text-gris"
                >
                  {cabecera}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {bloque.filas.map((fila) => (
              <tr key={fila[0]} className="border-b border-linea last:border-0">
                {fila.map((celda, columna) => (
                  <td
                    key={`${fila[0]}-${columna}`}
                    className={`px-4 py-3 align-top ${
                      columna === 0
                        ? "font-semibold text-tinta"
                        : "text-[13.5px] text-gris"
                    }`}
                  >
                    {celda}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {bloque.nota && (
        <p className="mt-3 max-w-[68ch] font-mono text-[10.5px] leading-relaxed tracking-[0.04em] text-gris">
          {bloque.nota}
        </p>
      )}
    </section>
  );
}

function BloqueDestacado({
  bloque,
}: {
  bloque: Extract<Bloque, { tipo: "destacado" }>;
}) {
  return (
    <section className="rounded-3xl border border-verde/25 bg-lavado p-6 sm:p-8">
      <h2 className="text-[clamp(19px,3vw,24px)] leading-[1.2] font-extrabold tracking-display">
        {bloque.titulo}
      </h2>
      {bloque.parrafos.map((parrafo) => (
        <p
          key={parrafo}
          className="mt-3 max-w-[66ch] text-[15px] leading-relaxed text-gris"
        >
          {conNegritas(parrafo)}
        </p>
      ))}
    </section>
  );
}

function BloqueAviso({ bloque }: { bloque: Extract<Bloque, { tipo: "aviso" }> }) {
  return (
    <section className="rounded-r-2xl border-l-[3px] border-verde bg-malla-suave py-4 pr-5 pl-5">
      <h2 className="text-[14.5px] font-bold tracking-display">{bloque.titulo}</h2>
      <p className="mt-1.5 max-w-[66ch] text-[14px] leading-relaxed text-gris">
        {conNegritas(bloque.texto)}
      </p>
    </section>
  );
}

function PintarBloque({ bloque }: { bloque: Bloque }) {
  switch (bloque.tipo) {
    case "texto":
      return <BloqueTexto bloque={bloque} />;
    case "puntos":
      return <BloquePuntos bloque={bloque} />;
    case "pasos":
      return <BloquePasos bloque={bloque} />;
    case "tabla":
      return <BloqueTabla bloque={bloque} />;
    case "destacado":
      return <BloqueDestacado bloque={bloque} />;
    case "aviso":
      return <BloqueAviso bloque={bloque} />;
  }
}

/* ———————————————————————————————————————————————————————————— */

export function Aterrizaje({
  pagina,
  children,
}: {
  pagina: Pagina;
  /** Contenido extra que va tras la entradilla (p. ej. el simulador). */
  children?: React.ReactNode;
}) {
  const url = `${marca.dominio}${pagina.ruta}`;

  const datosEstructurados = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebPage",
        "@id": url,
        url,
        name: pagina.titulo,
        description: pagina.descripcion,
        isPartOf: { "@type": "WebSite", url: marca.dominio, name: marca.nombre },
        inLanguage: "es-ES",
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          {
            "@type": "ListItem",
            position: 1,
            name: marca.nombre,
            item: marca.dominio,
          },
          { "@type": "ListItem", position: 2, name: pagina.nombre, item: url },
        ],
      },
      ...(pagina.faq
        ? [
            {
              "@type": "FAQPage",
              mainEntity: pagina.faq.map((elemento) => ({
                "@type": "Question",
                name: elemento.pregunta,
                acceptedAnswer: {
                  "@type": "Answer",
                  text: sinMarcas(elemento.respuesta),
                },
              })),
            },
          ]
        : []),
    ],
  };

  return (
    <>
      <a
        href="#contenido"
        className="sr-only z-[60] rounded-lg bg-verde px-4 py-2 font-semibold text-white focus:not-sr-only focus:fixed focus:top-3 focus:left-3"
      >
        {nav.saltar}
      </a>
      <Nav base="/" />

      <main id="contenido">
        <div className="mx-auto max-w-[1120px] px-5 pt-10 pb-4 sm:px-8 sm:pt-14">
          <nav aria-label="Migas de pan" className="mb-6">
            <ol className="flex flex-wrap items-center gap-2 font-mono text-[10px] tracking-[0.1em] text-gris uppercase">
              <li>
                <Link href="/" className="rounded-md hover:text-verde">
                  Inicio
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li className="text-tinta">{pagina.nombre}</li>
            </ol>
          </nav>

          <Reveal>
            <Cejilla>{pagina.cejilla}</Cejilla>
            <h1 className="max-w-[22ch] text-[clamp(29px,5.4vw,46px)] leading-[1.06] font-extrabold tracking-display">
              {pagina.h1}
            </h1>
            <p className="mt-5 max-w-[62ch] text-[17px] leading-relaxed text-gris">
              {conNegritas(pagina.entradilla)}
            </p>

            {pagina.datos && (
              <dl className="mt-8 grid gap-3 sm:grid-cols-3">
                {pagina.datos.map((dato) => (
                  <div
                    key={dato.etiqueta}
                    className="rounded-2xl border border-linea bg-superficie px-5 py-4"
                  >
                    <dt className="sr-only">{dato.etiqueta}</dt>
                    <dd>
                      <span className="block font-mono text-[24px] leading-none font-bold text-verde tabular-nums">
                        {dato.valor}
                      </span>
                      <span className="mt-2 block text-[13px] leading-snug text-gris">
                        {dato.etiqueta}
                      </span>
                    </dd>
                  </div>
                ))}
              </dl>
            )}
          </Reveal>
        </div>

        {children}

        <div className="mx-auto grid max-w-[1120px] gap-12 px-5 py-12 sm:px-8 sm:py-16">
          {pagina.bloques.map((bloque, indice) => (
            <Reveal key={`${bloque.tipo}-${indice}`}>
              <PintarBloque bloque={bloque} />
            </Reveal>
          ))}

          {pagina.faq && (
            <Reveal>
              <section>
                <Titulo>Preguntas frecuentes</Titulo>
                <div className="mt-5 grid gap-2">
                  {pagina.faq.map((elemento) => (
                    <details
                      key={elemento.pregunta}
                      className="group rounded-2xl border border-linea bg-superficie px-5 py-4"
                    >
                      <summary className="cursor-pointer list-none text-[15px] font-bold tracking-display marker:content-none">
                        <span className="flex items-start justify-between gap-4">
                          {elemento.pregunta}
                          <span
                            aria-hidden="true"
                            className="mt-1 shrink-0 font-mono text-[13px] text-verde transition-transform group-open:rotate-45"
                          >
                            +
                          </span>
                        </span>
                      </summary>
                      <p className="mt-2.5 max-w-[66ch] text-[14.5px] leading-relaxed text-gris">
                        {conNegritas(elemento.respuesta)}
                      </p>
                    </details>
                  ))}
                </div>
              </section>
            </Reveal>
          )}

          <Reveal>
            <section className="border-t border-linea pt-10">
              <Titulo>{pagina.cierre.titulo}</Titulo>
              <Parrafo texto={pagina.cierre.texto} />
              <a
                href="#contacto"
                className="mt-5 inline-block rounded-full bg-verde px-7 py-3.5 text-[15px] font-semibold text-white transition-colors hover:bg-verde-oscuro"
              >
                {nav.cta}
              </a>
            </section>
          </Reveal>

          {pagina.actualizado && (
            <p className="font-mono text-[10px] tracking-[0.1em] text-gris uppercase">
              {pagina.actualizado}
            </p>
          )}
        </div>

        <Formulario />
      </main>

      <PieDePagina base="/" />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(datosEstructurados) }}
      />
    </>
  );
}
