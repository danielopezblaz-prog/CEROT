"use client";

import { m, useReducedMotion } from "framer-motion";
import { planes } from "@/content";
import type { ReactNode } from "react";
import { Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";

/** Negritas sobre fondo tinta. */
function claras(texto: string): ReactNode[] {
  return texto.split("**").map((parte, i) =>
    i % 2 === 1 ? (
      <strong key={i} className="font-semibold text-white">
        {parte}
      </strong>
    ) : (
      parte
    ),
  );
}

/**
 * Los planes de ayudas como bloque institucional sobre tinta:
 * tarjetas de programa con la cifra protagonista, la escalera de
 * módulos del plan estatal (RD 326/2026) y los topes por vivienda.
 */
export function Planes() {
  const sinMovimiento = useReducedMotion();

  return (
    <section id="planes" className="sobre-tinta trama-malla bg-tinta">
      <div className="mx-auto max-w-[1120px] px-5 py-20 sm:px-8 md:py-28">
        <Reveal>
          <Cejilla clara>{planes.cejilla}</Cejilla>
          <h2 className="max-w-[24ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display text-white">
            {planes.titulo}
          </h2>
          <p className="mt-4 max-w-[60ch] text-[15px] text-white/70">
            {claras(planes.intro)}
          </p>
        </Reveal>

        <div className="mt-10 grid gap-5 lg:grid-cols-3">
          {planes.tarjetas.map((plan, i) => (
            <Reveal key={plan.clave} retraso={i * 0.07}>
              <article className="flex h-full flex-col rounded-3xl border border-white/10 bg-white/[.05] p-6 sm:p-7">
                <p className="etiqueta-cota inline-flex self-start rounded-full border border-malla/30 px-3 py-1.5 text-[9px] text-malla">
                  {plan.estado}
                </p>
                <h3 className="mt-4 text-[19px] leading-snug font-extrabold tracking-display text-white">
                  {plan.nombre}
                </h3>
                <p className="mt-4 flex items-baseline gap-1.5">
                  <span className="text-[52px] leading-none font-extrabold tracking-display text-malla tabular-nums">
                    {plan.destacado}
                  </span>
                  <span className="text-[24px] leading-none font-bold text-malla">
                    {plan.destacadoSufijo}
                  </span>
                </p>
                <p className="etiqueta-cota mt-1.5 text-[9px] text-white/55">
                  {plan.destacadoEtiqueta}
                </p>
                <p className="mt-4 flex-1 text-[14.5px] leading-relaxed text-white/70">
                  {claras(plan.texto)}
                </p>
                <p className="mt-5 border-t border-white/10 pt-3 font-mono text-[9.5px] leading-relaxed tracking-[0.08em] text-white/55 uppercase">
                  {plan.nota}
                </p>
              </article>
            </Reveal>
          ))}
        </div>

        {/* escalera de módulos + topes por vivienda */}
        <div className="mt-8 grid gap-5 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
          <Reveal retraso={0.06}>
            <div className="h-full rounded-3xl border border-white/10 bg-white/[.05] p-6 sm:p-7">
              <h3 className="text-[16px] font-bold tracking-display text-white">
                {planes.escalera.titulo}
              </h3>
              <div className="mt-6 grid grid-cols-3 items-end gap-3 sm:gap-5">
                {planes.escalera.pasos.map((paso, i) => (
                  <div key={paso.etiqueta} className="flex flex-col">
                    <div
                      className="flex items-end"
                      style={{ height: `${(paso.valor / 80) * 190}px` }}
                    >
                      <m.div
                        initial={sinMovimiento ? false : { scaleY: 0 }}
                        whileInView={{ scaleY: 1 }}
                        viewport={{ once: true, margin: "0px 0px -10% 0px" }}
                        transition={{
                          type: "spring",
                          stiffness: 90,
                          damping: 18,
                          delay: 0.1 + i * 0.12,
                        }}
                        className={`flex h-full w-full origin-bottom items-start justify-center rounded-t-xl pt-3 ${
                          i === 2 ? "bg-malla" : i === 1 ? "bg-verde" : "bg-verde/60"
                        }`}
                      >
                        <span
                          className={`text-[22px] leading-none font-extrabold tracking-display sm:text-[26px] ${
                            i === 2 ? "text-tinta" : "text-white"
                          }`}
                        >
                          {paso.valor}
                          <span className="text-[13px] font-bold sm:text-[15px]"> %</span>
                        </span>
                      </m.div>
                    </div>
                    <p className="etiqueta-cota mt-3 text-[8px] tracking-[0.08em] whitespace-nowrap text-malla sm:text-[9.5px] sm:tracking-[0.16em]">
                      {paso.etiqueta}
                    </p>
                    <p className="mt-1 text-[11.5px] leading-snug text-white/60">
                      {paso.detalle}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal retraso={0.12}>
            <div className="flex h-full flex-col rounded-3xl border border-white/10 bg-white/[.05] p-6 sm:p-7">
              <h3 className="text-[16px] font-bold tracking-display text-white">
                {planes.cuantias.titulo}
              </h3>
              <dl className="mt-5 flex-1">
                {planes.cuantias.filas.map(([concepto, tope], i) => (
                  <div
                    key={concepto}
                    className={`flex items-baseline justify-between gap-4 py-3.5 ${
                      i > 0 ? "border-t border-white/10" : ""
                    }`}
                  >
                    <dt className="text-[13.5px] text-white/70">{concepto}</dt>
                    <dd className="font-mono text-[15px] font-bold whitespace-nowrap text-malla tabular-nums">
                      {tope}
                    </dd>
                  </div>
                ))}
              </dl>
              <p className="mt-4 border-t border-white/10 pt-3.5 text-[12px] leading-relaxed text-white/55">
                {planes.cuantias.nota}
              </p>
            </div>
          </Reveal>
        </div>

        <Reveal retraso={0.1}>
          <div className="mt-9">
            <m.a
              href="#contacto"
              whileTap={{ scale: 0.98 }}
              className="inline-block rounded-full bg-malla px-7 py-3.5 text-center text-[15px] font-bold text-tinta transition-colors hover:bg-[#8fd4b0]"
            >
              {planes.cta}
            </m.a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
