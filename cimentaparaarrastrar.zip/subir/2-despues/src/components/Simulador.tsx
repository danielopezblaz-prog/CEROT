"use client";

import { useEffect, useState } from "react";
import {
  animate,
  m,
  useMotionValue,
  useReducedMotion,
  useTransform,
} from "framer-motion";
import { simulador } from "@/content";
import { numeroES } from "@/lib/texto";
import { Boton, Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";

/* ————————————————————————————————————————————————————————————
   CONSTANTES EDITABLES DEL SIMULADOR
   Tramos y topes por vivienda del RD 326/2026 (Plan 2026-2030).
   TODO: ajustar costes de obra con datos propios y repasar cada
   convocatoria antes de publicar campañas.
   ———————————————————————————————————————————————————————————— */
const OBRAS = {
  /** Coste = fijo del edificio + coste por vivienda (para sugerir el importe medio). */
  fachada: { costeFijo: 60_000, costePorVivienda: 3_800, tramo: "t40" },
  fachadaCubierta: { costeFijo: 90_000, costePorVivienda: 5_200, tramo: "t65" },
  integral: { costeFijo: 140_000, costePorVivienda: 8_500, tramo: "t80" },
} as const;

/** Rango del importe medio de obra por vivienda, ajustable a mano. */
const IMPORTE = { minimo: 2_000, maximo: 30_000, paso: 250 };

/** Tramos de ayuda por ahorro certificado, con tope por vivienda. */
const TRAMOS = {
  t40: { ayuda: 0.4, tope: null },
  t65: { ayuda: 0.65, tope: 13_000 },
  t80: { ayuda: 0.8, tope: 20_500 },
} as const;

const VIVIENDAS = { minimo: 6, maximo: 80, inicial: 24 };
const PLAZOS = [5, 10, 15] as const;
const INTERES_ANUAL = 0.059;

/** Meses que la comunidad adelanta la parte subvencionada si no hay anticipo. */
const MESES_PUENTE = 18;
/* ———————————————————————————————————————————————————————————— */

type ClaveObra = keyof typeof OBRAS;
type ClaveTramo = keyof typeof TRAMOS;

/** Importe medio por vivienda que proponemos según obra y tamaño del edificio. */
function importeSugerido(viviendas: number, claveObra: ClaveObra) {
  const obra = OBRAS[claveObra];
  const bruto = obra.costeFijo / viviendas + obra.costePorVivienda;
  const redondeado = Math.round(bruto / IMPORTE.paso) * IMPORTE.paso;
  return Math.min(IMPORTE.maximo, Math.max(IMPORTE.minimo, redondeado));
}

function calcular(
  viviendas: number,
  importe: number,
  claveTramo: ClaveTramo,
  anios: number,
) {
  const tramo = TRAMOS[claveTramo];
  const costeTotal = importe * viviendas;

  const ayudaBruta = costeTotal * tramo.ayuda;
  const ayudaMaxima = tramo.tope === null ? Infinity : tramo.tope * viviendas;
  const ayudaTotal = Math.min(ayudaBruta, ayudaMaxima);
  const topeAplicado = ayudaTotal < ayudaBruta - 0.5;
  const pctEfectivo = (ayudaTotal / costeTotal) * 100;

  const netoTotal = costeTotal - ayudaTotal;
  const netoPorVivienda = netoTotal / viviendas;

  const meses = anios * 12;
  const interesMensual = INTERES_ANUAL / 12;
  const cuota = (principal: number) =>
    (principal * interesMensual) / (1 - Math.pow(1 + interesMensual, -meses));

  /** Coste de adelantar la parte subvencionada hasta cobrar la ayuda. */
  const costePuentePorVivienda =
    (ayudaTotal * INTERES_ANUAL * (MESES_PUENTE / 12)) / viviendas;

  return {
    conAyuda: cuota(netoPorVivienda + costePuentePorVivienda),
    conAnticipo: cuota(netoPorVivienda),
    derramaSinAyuda: costeTotal / viviendas,
    porcentajeNominal: tramo.ayuda * 100,
    pctEfectivo,
    topeAplicado,
    tope: tramo.tope,
    costeTotal,
    ayudaTotal,
    netoTotal,
    netoPorVivienda,
    meses,
  };
}

/** Pictogramas de obra, dibujados a línea como el resto de la marca. */
function IconoObra({ tipo }: { tipo: ClaveObra }) {
  const comun = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.5,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  const conCubierta = tipo !== "fachada";
  const yAlero = conCubierta ? 12 : 9;
  const forjado1 = yAlero + 9;
  const forjado2 = yAlero + 18;

  return (
    <svg width="40" height="40" viewBox="0 0 44 44" aria-hidden="true">
      {/* volumen del edificio */}
      <rect x="14" y={yAlero} width="16" height={conCubierta ? 25 : 28} {...comun} />
      {conCubierta && <path d="M12 12 L22 4.5 L32 12" {...comun} />}
      {/* forjados */}
      <path
        d={`M14 ${forjado1} h16 M14 ${forjado2} h16`}
        {...comun}
        strokeWidth={1}
        opacity={0.55}
      />
      {/* andamio delante de la fachada */}
      {tipo !== "integral" && (
        <>
          <path d="M10.5 8 V39 M33.5 8 V39" {...comun} strokeWidth={1.2} />
          <path
            d="M10.5 15 h3.5 M10.5 24 h3.5 M10.5 33 h3.5 M30 15 h3.5 M30 24 h3.5 M30 33 h3.5"
            {...comun}
            strokeWidth={1}
          />
        </>
      )}
      {/* trama: cubierta o edificio entero */}
      {tipo === "fachadaCubierta" && (
        <path
          d="M17 9.7 L20.5 7 M21.5 9.7 L25 7 M26 9.7 L29.5 7.3"
          {...comun}
          strokeWidth={1}
        />
      )}
      {tipo === "integral" && (
        <path
          d="M14 20 L22 12 M14 28 L30 12 M14 36 L30 20 M20 37 L30 27"
          {...comun}
          strokeWidth={1}
          opacity={0.8}
        />
      )}
      {/* suelo */}
      <path d="M8 39 H36" {...comun} strokeWidth={1.2} />
    </svg>
  );
}

/** Cifra con animación de conteo (spring) cada vez que cambia. */
function NumeroAnimado({ valor }: { valor: number }) {
  const sinMovimiento = useReducedMotion();
  const bruto = useMotionValue(valor);
  const texto = useTransform(bruto, (v) => numeroES(Math.round(v)));

  useEffect(() => {
    if (sinMovimiento) {
      bruto.set(valor);
      return;
    }
    const control = animate(bruto, valor, {
      type: "spring",
      stiffness: 110,
      damping: 24,
    });
    return () => control.stop();
  }, [valor, bruto, sinMovimiento]);

  return <m.span>{texto}</m.span>;
}

/**
 * Memoria de cálculo: el desglose completo, partida a partida, de cómo
 * sale la cuota. Se actualiza en vivo con los controles del simulador.
 */
function MemoriaCalculo({
  viviendas,
  importe,
  nombreObra,
  resultado,
}: {
  viviendas: number;
  importe: number;
  nombreObra: string;
  resultado: ReturnType<typeof calcular>;
}) {
  const memoria = simulador.memoria;
  const interesTexto = new Intl.NumberFormat("es-ES", {
    maximumFractionDigits: 1,
  }).format(INTERES_ANUAL * 100);
  const puenteMensual = resultado.conAyuda - resultado.conAnticipo;

  const filaAyuda = resultado.topeAplicado
    ? memoria.filas.ayudaTope
        .replace("{tope}", numeroES(resultado.tope ?? 0))
        .replace("{viviendas}", String(viviendas))
    : `${memoria.filas.ayuda} (${numeroES(resultado.porcentajeNominal)} %)`;

  const partidas = [
    {
      indice: "01",
      texto: memoria.filas.costeObra
        .replace("{importe}", numeroES(importe))
        .replace("{viviendas}", String(viviendas)),
      valor: `${numeroES(Math.round(resultado.costeTotal))} €`,
      clase: "text-tinta",
    },
    {
      indice: "02",
      texto: filaAyuda,
      valor: `−${numeroES(Math.round(resultado.ayudaTotal))} €`,
      clase: "text-verde",
    },
    {
      indice: "03",
      texto: memoria.filas.neto,
      valor: `${numeroES(Math.round(resultado.netoTotal))} €`,
      clase: "text-tinta",
    },
    {
      indice: "04",
      texto: `${memoria.filas.porVivienda} (÷ ${viviendas})`,
      valor: `${numeroES(Math.round(resultado.netoPorVivienda))} €`,
      clase: "text-tinta",
    },
    {
      indice: "05",
      texto: `${memoria.filas.financiacion
        .replace("{meses}", String(resultado.meses))
        .replace("{interes}", `${interesTexto} %`)} · ${memoria.cuotaConAnticipo}`,
      valor: `${numeroES(Math.round(resultado.conAnticipo))} €/mes`,
      clase: "font-bold text-verde",
    },
    {
      indice: "06",
      texto: `${memoria.filas.puente.replace("{meses}", String(MESES_PUENTE))} +${numeroES(
        Math.round(puenteMensual),
      )} €/mes · ${memoria.cuotaSinAnticipo}`,
      valor: `${numeroES(Math.round(resultado.conAyuda))} €/mes`,
      clase: "font-bold text-tinta",
    },
  ];

  return (
    <div className="mt-5 rounded-xl border border-linea bg-papel p-4 sm:p-5">
      <p className="etiqueta-cota text-[9.5px] text-verde">
        {memoria.titulo} · {viviendas} viviendas · {nombreObra}
      </p>
      <p className="mt-1 text-[14px] font-bold">{memoria.subtitulo}</p>
      <dl className="mt-3 grid gap-2.5">
        {partidas.map((partida) => (
          <div
            key={partida.indice}
            className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5"
          >
            <dt className="font-mono text-[11px] leading-snug text-gris">
              <span className="mr-1.5 font-semibold text-verde">
                {partida.indice}
              </span>
              {partida.texto}
            </dt>
            <span
              aria-hidden="true"
              className="min-w-6 flex-1 -translate-y-[3px] border-b border-dotted border-linea-fuerte"
            />
            <dd
              className={`font-mono text-[12px] tabular-nums ${partida.clase}`}
            >
              {partida.valor}
            </dd>
          </div>
        ))}
      </dl>
      <p className="mt-3.5 border-t border-linea pt-3 text-[12.5px] leading-relaxed text-gris">
        {memoria.notaComunidad}
      </p>
    </div>
  );
}

/**
 * `conCabecera` a false oculta la cejilla y el titular internos: lo usa
 * la página /simulador, donde ese titular ya es el h1 de la página.
 */
export function Simulador({ conCabecera = true }: { conCabecera?: boolean }) {
  const [viviendas, setViviendas] = useState(VIVIENDAS.inicial);
  const [obra, setObra] = useState<ClaveObra>("fachadaCubierta");
  const [tramo, setTramo] = useState<ClaveTramo>("t65");
  const [anios, setAnios] = useState<number>(10);
  /** null = importe sugerido automáticamente; número = lo ha fijado la persona. */
  const [importeManual, setImporteManual] = useState<number | null>(null);
  /** true en cuanto la persona toca cualquier control: activa el traspaso al formulario. */
  const [tocado, setTocado] = useState(false);

  const importe = importeManual ?? importeSugerido(viviendas, obra);
  const resultado = calcular(viviendas, importe, tramo, anios);
  const nombreObra =
    simulador.obras.find((o) => o.clave === obra)?.nombre ?? "";
  const pctAyuda = Math.round(resultado.pctEfectivo);

  /* la simulación viaja al formulario: se guarda y se anuncia en cada cambio */
  const cuotaResumen = Math.round(resultado.conAnticipo);
  useEffect(() => {
    if (!tocado) return;
    const resumen = {
      viviendas,
      obra: nombreObra,
      importe,
      ayuda: pctAyuda,
      cuota: cuotaResumen,
    };
    try {
      sessionStorage.setItem("cimenta-simulacion", JSON.stringify(resumen));
    } catch {
      /* almacenamiento no disponible: el evento sigue funcionando */
    }
    window.dispatchEvent(
      new CustomEvent("cimenta:simulacion", { detail: resumen }),
    );
  }, [tocado, viviendas, nombreObra, importe, pctAyuda, cuotaResumen]);
  const progresoDeslizador =
    ((viviendas - VIVIENDAS.minimo) / (VIVIENDAS.maximo - VIVIENDAS.minimo)) *
    100;
  const progresoImporte =
    ((importe - IMPORTE.minimo) / (IMPORTE.maximo - IMPORTE.minimo)) * 100;

  const cambiarViviendas = (delta: number) => {
    setTocado(true);
    setViviendas((actual) =>
      Math.min(VIVIENDAS.maximo, Math.max(VIVIENDAS.minimo, actual + delta)),
    );
  };

  const elegirObra = (clave: ClaveObra) => {
    setTocado(true);
    setObra(clave);
    setTramo(OBRAS[clave].tramo);
    setImporteManual(null);
  };

  return (
    <section
      id="simulador"
      className={`mx-auto max-w-[1120px] px-5 sm:px-8 ${
        conCabecera ? "py-20 md:py-28" : "pb-16 md:pb-20"
      }`}
    >
      {conCabecera && (
        <Reveal>
          <Cejilla>{simulador.cejilla}</Cejilla>
          <h2 className="max-w-[22ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display">
            {simulador.titulo}
          </h2>
          <p className="mt-4 max-w-[52ch] text-gris">{simulador.intro}</p>
        </Reveal>
      )}

      <div
        className={`grid items-start gap-6 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)] ${
          conCabecera ? "mt-10" : "mt-4"
        }`}
      >
        {/* ————— Panel de controles ————— */}
        <Reveal retraso={0.06}>
          <div className="rounded-3xl border border-linea bg-superficie p-6 shadow-[0_20px_60px_rgba(24,33,28,.07)] sm:p-7">
            <div>
              <div className="flex items-end justify-between gap-4">
                <label htmlFor="control-viviendas" className="etiqueta-cota text-gris">
                  {simulador.etiquetaViviendas}
                </label>
                <p className="font-mono text-[28px] leading-none font-bold text-tinta" aria-hidden="true">
                  {viviendas}
                </p>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <m.button
                  type="button"
                  whileTap={{ scale: 0.94 }}
                  onClick={() => cambiarViviendas(-1)}
                  disabled={viviendas <= VIVIENDAS.minimo}
                  aria-label="Una vivienda menos"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-linea-fuerte bg-superficie text-xl font-semibold text-tinta transition-colors hover:border-verde hover:text-verde disabled:opacity-35 disabled:hover:border-linea-fuerte disabled:hover:text-tinta"
                >
                  −
                </m.button>
                <input
                  id="control-viviendas"
                  type="range"
                  className="deslizador min-w-0 flex-1"
                  min={VIVIENDAS.minimo}
                  max={VIVIENDAS.maximo}
                  step={1}
                  value={viviendas}
                  onChange={(evento) => {
                    setTocado(true);
                    setViviendas(Number(evento.target.value));
                  }}
                  style={{ "--progreso": `${progresoDeslizador}%` } as React.CSSProperties}
                  aria-valuetext={`${viviendas} viviendas`}
                />
                <m.button
                  type="button"
                  whileTap={{ scale: 0.94 }}
                  onClick={() => cambiarViviendas(1)}
                  disabled={viviendas >= VIVIENDAS.maximo}
                  aria-label="Una vivienda más"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-linea-fuerte bg-superficie text-xl font-semibold text-tinta transition-colors hover:border-verde hover:text-verde disabled:opacity-35 disabled:hover:border-linea-fuerte disabled:hover:text-tinta"
                >
                  +
                </m.button>
              </div>
            </div>

            <div className="mt-7">
              <p id="etiqueta-obra" className="etiqueta-cota text-gris">
                {simulador.etiquetaObra}
              </p>
              <div
                role="radiogroup"
                aria-labelledby="etiqueta-obra"
                className="mt-3 grid grid-cols-3 gap-2"
              >
                {simulador.obras.map(({ clave, nombre }) => {
                  const activa = obra === clave;
                  return (
                    <m.button
                      key={clave}
                      type="button"
                      role="radio"
                      aria-checked={activa}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => elegirObra(clave as ClaveObra)}
                      className={`flex flex-col items-center gap-1.5 rounded-2xl border px-2 pt-3 pb-2.5 text-[12px] leading-tight font-semibold transition-colors ${
                        activa
                          ? "border-verde bg-verde text-white"
                          : "border-linea-fuerte bg-superficie text-gris hover:border-verde/60 hover:text-tinta"
                      }`}
                    >
                      <IconoObra tipo={clave as ClaveObra} />
                      {nombre}
                    </m.button>
                  );
                })}
              </div>
            </div>

            <div className="mt-7">
              <div className="flex items-end justify-between gap-4">
                <label htmlFor="control-importe" className="etiqueta-cota text-gris">
                  {simulador.etiquetaImporte}
                </label>
                <p
                  className="font-mono text-[22px] leading-none font-bold whitespace-nowrap text-tinta tabular-nums"
                  aria-hidden="true"
                >
                  {numeroES(importe)} <span className="text-[14px]">€</span>
                </p>
              </div>
              <input
                id="control-importe"
                type="range"
                className="deslizador mt-1 w-full"
                min={IMPORTE.minimo}
                max={IMPORTE.maximo}
                step={IMPORTE.paso}
                value={importe}
                onChange={(evento) => {
                  setTocado(true);
                  setImporteManual(Number(evento.target.value));
                }}
                style={{ "--progreso": `${progresoImporte}%` } as React.CSSProperties}
                aria-valuetext={`${numeroES(importe)} euros por vivienda`}
              />
              <p className="mt-1.5 text-[12px] leading-relaxed text-gris">
                {simulador.notaImporte}
              </p>
            </div>

            <div className="mt-7">
              <p id="etiqueta-tramo" className="etiqueta-cota text-gris">
                {simulador.etiquetaTramo}
              </p>
              <div
                role="radiogroup"
                aria-labelledby="etiqueta-tramo"
                className="mt-3 grid grid-cols-3 gap-2"
              >
                {simulador.tramos.map(({ clave, pct, ahorro }) => {
                  const activo = tramo === clave;
                  return (
                    <m.button
                      key={clave}
                      type="button"
                      role="radio"
                      aria-checked={activo}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        setTocado(true);
                        setTramo(clave as ClaveTramo);
                      }}
                      className={`rounded-2xl border px-2 py-2.5 transition-colors ${
                        activo
                          ? "border-verde bg-verde text-white"
                          : "border-linea-fuerte bg-superficie text-gris hover:border-verde/60 hover:text-tinta"
                      }`}
                    >
                      <span className="block text-[17px] leading-none font-extrabold tracking-display">
                        {pct}
                      </span>
                      <span
                        className={`mt-1.5 block font-mono text-[8px] tracking-[0.1em] uppercase ${
                          activo ? "text-white/75" : "text-gris"
                        }`}
                      >
                        {ahorro}
                      </span>
                    </m.button>
                  );
                })}
              </div>
              <p className="mt-2.5 text-[12px] leading-relaxed text-gris">
                {simulador.notaTramo}
              </p>
            </div>

            <div className="mt-7">
              <p id="etiqueta-plazo" className="etiqueta-cota text-gris">
                {simulador.etiquetaPlazo}
              </p>
              <div
                role="radiogroup"
                aria-labelledby="etiqueta-plazo"
                className="mt-3 flex gap-2"
              >
                {PLAZOS.map((plazo) => {
                  const activo = anios === plazo;
                  return (
                    <m.button
                      key={plazo}
                      type="button"
                      role="radio"
                      aria-checked={activo}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        setTocado(true);
                        setAnios(plazo);
                      }}
                      className={`flex-1 rounded-2xl border px-2 py-2.5 font-mono text-[13px] font-semibold tabular-nums transition-colors ${
                        activo
                          ? "border-verde bg-verde text-white"
                          : "border-linea-fuerte bg-superficie text-gris hover:border-verde/60 hover:text-tinta"
                      }`}
                    >
                      {plazo} {simulador.plazoSufijo}
                    </m.button>
                  );
                })}
              </div>
            </div>

            <p className="mt-7 hidden border-t border-linea pt-5 text-[13px] leading-relaxed text-gris lg:block">
              {simulador.supuestos}
            </p>
          </div>
        </Reveal>

        {/* ————— Ficha de resultado ————— */}
        <Reveal retraso={0.12}>
          <div
            className="overflow-hidden rounded-3xl border border-linea bg-superficie shadow-[0_20px_60px_rgba(24,33,28,.07)]"
            aria-live="polite"
            aria-atomic="true"
          >
            <div className="trama-malla flex flex-wrap items-center justify-between gap-x-4 gap-y-1 bg-tinta px-5 py-3.5 sm:px-6">
              <p className="etiqueta-cota text-[9px] text-malla">
                {simulador.ficha.cabecera} · {viviendas} viv · {nombreObra}
              </p>
              <p className="etiqueta-cota text-[9px] text-white/60">
                Ayuda {pctAyuda} %
              </p>
            </div>

            <div className="p-5 sm:p-6">
              <p className="text-[13.5px] text-gris">
                {simulador.ficha.derramaAntes}{" "}
                <strong className="font-mono font-bold text-tinta line-through decoration-tinta/60 decoration-2 tabular-nums">
                  {numeroES(Math.round(resultado.derramaSinAyuda))}
                </strong>{" "}
                {simulador.ficha.derramaDespues}
              </p>

              <div className="mt-4 flex flex-wrap items-end justify-between gap-x-6 gap-y-3">
                <div>
                  <p className="text-[54px] leading-none font-extrabold tracking-display text-verde">
                    <NumeroAnimado valor={resultado.conAnticipo} />
                    <span className="text-[22px] font-bold"> €</span>
                  </p>
                  <p className="etiqueta-cota mt-2 text-[9px] text-gris">
                    {simulador.ficha.porVecinoMes}
                  </p>
                </div>
                <span className="etiqueta-cota rounded-full bg-malla px-3 py-1.5 text-[9px] text-tinta">
                  {simulador.ficha.conAnticipoChip}
                </span>
              </div>

              <p className="mt-3 text-[12.5px] leading-relaxed text-gris">
                {simulador.ficha.sinAnticipo}{" "}
                <strong className="font-mono font-bold text-tinta tabular-nums">
                  {numeroES(Math.round(resultado.conAyuda))}
                </strong>{" "}
                {simulador.ficha.sinAnticipoSufijo}
              </p>

              {/* quién paga la obra */}
              <div className="mt-6">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="etiqueta-cota text-[9px] text-gris">
                    {simulador.ficha.quienPaga}
                  </p>
                  {resultado.topeAplicado && (
                    <p className="etiqueta-cota rounded-full border border-verde/40 bg-lavado px-2.5 py-1 text-[8.5px] text-verde-oscuro">
                      {simulador.ficha.topeChip.replace(
                        "{tope}",
                        numeroES(resultado.tope ?? 0),
                      )}
                    </p>
                  )}
                </div>
                <div className="mt-2.5 flex h-8 w-full overflow-hidden rounded-lg">
                  <m.div
                    className="trama-malla-clara h-full bg-malla"
                    initial={false}
                    animate={{ width: `${pctAyuda}%` }}
                    transition={{ type: "spring", stiffness: 90, damping: 20 }}
                  />
                  <m.div
                    className="h-full flex-1 bg-verde"
                    initial={false}
                    animate={{ width: `${100 - pctAyuda}%` }}
                    transition={{ type: "spring", stiffness: 90, damping: 20 }}
                  />
                </div>
                <div className="mt-2 flex flex-wrap gap-x-6 gap-y-1">
                  <p className="flex items-center gap-2 font-mono text-[10px] tracking-[0.08em] text-gris uppercase">
                    <span aria-hidden="true" className="inline-block h-2.5 w-2.5 rounded-[3px] bg-malla" />
                    {simulador.ficha.segAyudas}{" "}
                    <strong className="text-tinta tabular-nums">{pctAyuda} %</strong>
                  </p>
                  <p className="flex items-center gap-2 font-mono text-[10px] tracking-[0.08em] text-gris uppercase">
                    <span aria-hidden="true" className="inline-block h-2.5 w-2.5 rounded-[3px] bg-verde" />
                    {simulador.ficha.segComunidad}{" "}
                    <strong className="text-tinta tabular-nums">{100 - pctAyuda} %</strong>
                  </p>
                </div>
              </div>

              <MemoriaCalculo
                viviendas={viviendas}
                importe={importe}
                nombreObra={nombreObra}
                resultado={resultado}
              />

              <p className="etiqueta-cota mt-4 inline-flex items-center gap-2 text-[9.5px] text-verde">
                <span aria-hidden="true" className="inline-block h-2 w-2 rounded-full bg-malla" />
                {simulador.avisoEstimacion}
              </p>
              <p className="mt-3 text-[13px] leading-relaxed text-gris lg:hidden">
                {simulador.supuestos}
              </p>

              <div className="mt-5">
                <Boton href="#contacto" className="w-full sm:w-auto">
                  {simulador.cta}
                </Boton>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
