"use client";

import { m } from "framer-motion";
import { nav } from "@/content";
import { Logotipo } from "./Compartidos";

/**
 * `base` es el prefijo de las anclas de sección. Vacío en la home
 * (`#servicios`); "/" en las páginas de aterrizaje, donde esas secciones
 * viven en otra URL (`/#servicios`). El ancla de contacto nunca lleva
 * prefijo: todas las páginas terminan en el mismo formulario.
 */
export function Nav({ base = "" }: { base?: string }) {
  return (
    <nav
      aria-label="Principal"
      className="sticky top-0 z-50 border-b border-linea bg-papel/85 backdrop-blur-md backdrop-saturate-150"
    >
      <div className="mx-auto flex max-w-[1120px] items-center justify-between gap-4 px-5 py-3 sm:px-8">
        <a
          href={base || "#inicio"}
          aria-label="Cimenta, volver al inicio"
          className="rounded-md"
        >
          <Logotipo />
        </a>

        <div className="hidden items-center gap-7 md:flex">
          {nav.enlaces.map((enlace) => (
            <a
              key={enlace.ancla}
              href={`${base}${enlace.ancla}`}
              className="rounded-md text-[14px] text-gris transition-colors hover:text-tinta"
            >
              {enlace.texto}
            </a>
          ))}
        </div>

        <m.a
          href="#contacto"
          whileTap={{ scale: 0.98 }}
          className="rounded-full bg-verde px-5 py-2.5 text-[13.5px] font-semibold whitespace-nowrap text-white transition-colors hover:bg-verde-oscuro"
        >
          {nav.cta}
        </m.a>
      </div>
    </nav>
  );
}
