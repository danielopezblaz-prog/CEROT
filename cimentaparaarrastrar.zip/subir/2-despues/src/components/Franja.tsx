"use client";

import { franja } from "@/content";
import { Reveal } from "./Reveal";

/** Franja de confianza: tres compromisos sobre fondo tinta. */
export function Franja() {
  return (
    <section aria-label="Nuestros compromisos" className="trama-malla bg-tinta">
      <div className="mx-auto grid max-w-[1120px] gap-8 px-5 py-10 sm:px-8 md:grid-cols-3 md:gap-10 md:py-12">
        {franja.map((compromiso, i) => (
          <Reveal key={compromiso.titulo} retraso={i * 0.07}>
            <div className="flex gap-4">
              <span
                aria-hidden="true"
                className="mt-1.5 inline-block h-8 w-1 shrink-0 rounded-full bg-malla"
              />
              <div>
                <h2 className="text-[16px] font-bold text-white">
                  {compromiso.titulo}
                </h2>
                <p className="mt-1 text-[13.5px] leading-relaxed text-white/65">
                  {compromiso.texto}
                </p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
