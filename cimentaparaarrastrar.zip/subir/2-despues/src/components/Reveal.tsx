"use client";

import { m, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";

/**
 * Aparición al entrar en viewport: desplazamiento suave hacia arriba
 * con spring (rigidez 120, amortiguación 20). `retraso` permite
 * escalonar hermanos entre 60 y 90 ms.
 */
export function Reveal({
  children,
  retraso = 0,
  className,
}: {
  children: ReactNode;
  retraso?: number;
  className?: string;
}) {
  const sinMovimiento = useReducedMotion();

  if (sinMovimiento) {
    return <div className={className}>{children}</div>;
  }

  return (
    <m.div
      className={className}
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "0px 0px -8% 0px" }}
      transition={{
        type: "spring",
        stiffness: 120,
        damping: 20,
        delay: retraso,
      }}
    >
      {children}
    </m.div>
  );
}
