"use client";

import { useEffect, useRef, useState } from "react";
import {
  m,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
  type MotionValue,
} from "framer-motion";
import { hero } from "@/content";
import { numeroES } from "@/lib/texto";
import { Boton, Cejilla } from "@/components/Compartidos";
import { EscenaEsquina } from "./EscenaEsquina";

/* ————— Ventanas de progreso de cada pieza (0 → 1 del scroll) ————— */
const VENTANAS = {
  ite: { entrada: [0.02, 0.08], salida: [0.26, 0.33] },
  anotacion: (i: number) => ({
    entrada: [0.5 + i * 0.055, 0.56 + i * 0.055],
    salida: [0.71, 0.755],
  }),
  contador: { entrada: [0.76, 0.84] },
  actos: [
    [0, 0.3],
    [0.3, 0.72],
    [0.72, 1],
  ] as [number, number][],
};

/* ————— Posiciones de los chips sobre la lámina (fracciones del lienzo) ————— */
const POSICIONES = {
  ite: { left: "39%", top: "40%" },
  anotaciones: [
    { left: "31.5%", top: "29.7%" },
    { left: "8.5%", top: "47.5%" },
    { left: "20.7%", top: "66%" },
  ],
};

function ChipFlotante({
  p,
  estatico,
  entrada,
  salida,
  posicion,
  children,
  oculto = false,
  desdeInicio = false,
}: {
  p: MotionValue<number>;
  estatico: boolean;
  entrada: number[];
  salida?: number[];
  posicion: React.CSSProperties;
  children: React.ReactNode;
  oculto?: boolean;
  /** Visible ya en reposo; solo se anima su salida. */
  desdeInicio?: boolean;
}) {
  const soloSalida = desdeInicio && salida;
  const claves = soloSalida ? salida : salida ? [...entrada, ...salida] : entrada;
  const valores = soloSalida ? [1, 0] : salida ? [0, 1, 1, 0] : [0, 1];
  const opacidad = useTransform(p, claves, valores);
  const y = useTransform(p, entrada, [10, 0]);

  if (estatico && oculto) return null;

  return (
    <span
      aria-hidden="true"
      className={`absolute ${estatico ? "hidden sm:block" : "hidden lg:block"}`}
      style={{ ...posicion, transform: "translateY(calc(-100% - 8px))" }}
    >
      <m.span
        className="block"
        style={
          estatico
            ? undefined
            : desdeInicio
              ? { opacity: opacidad }
              : { opacity: opacidad, y }
        }
      >
        {children}
      </m.span>
    </span>
  );
}

function ContenidoChip({ indice, texto }: { indice?: string; texto: string }) {
  return (
    <span className="flex items-center gap-1.5 rounded-md border border-linea-fuerte bg-superficie px-2.5 py-1.5 font-mono text-[9px] tracking-[0.13em] whitespace-nowrap text-tinta uppercase shadow-[0_2px_10px_rgba(24,33,28,.08)] sm:text-[10px]">
      {indice && <span className="font-semibold text-verde">{indice}</span>}
      {texto}
    </span>
  );
}

/** Riel de actos: mapa de la historia, siempre legible junto al titular. */
function RielActos({
  p,
  estatico,
}: {
  p: MotionValue<number>;
  estatico: boolean;
}) {
  const opacidades = [
    useTransform(p, [0.28, 0.34], [1, 0.4]),
    useTransform(p, [0.28, 0.34, 0.7, 0.76], [0.4, 1, 1, 0.4]),
    useTransform(p, [0.7, 0.76], [0.4, 1]),
  ];
  const rellenos = [
    useTransform(p, VENTANAS.actos[0], [0, 1]),
    useTransform(p, VENTANAS.actos[1], [0, 1]),
    useTransform(p, VENTANAS.actos[2], [0, 1]),
  ];

  return (
    <ol className="mt-10 hidden max-w-[340px] flex-col gap-2.5 md:flex" aria-label="Los tres actos de la animación">
      {hero.actos.map((acto, i) => (
        <li key={acto.numero}>
          <m.span
            className="flex items-center gap-3"
            style={estatico ? undefined : { opacity: opacidades[i] }}
          >
            <span className="font-mono text-[10px] font-semibold tracking-[0.14em] text-verde">
              {acto.numero}
            </span>
            <span className="etiqueta-cota text-tinta">{acto.nombre}</span>
            <span className="relative h-px flex-1 overflow-hidden rounded bg-linea">
              <m.span
                className="absolute inset-0 origin-left bg-verde"
                style={{ scaleX: estatico ? 1 : rellenos[i] }}
              />
            </span>
          </m.span>
        </li>
      ))}
    </ol>
  );
}

/** Tarjeta final: los porcentajes que cambian la historia. */
function TarjetaContador({
  p,
  estatico,
}: {
  p: MotionValue<number>;
  estatico: boolean;
}) {
  const c = hero.contador;
  const opacidad = useTransform(p, VENTANAS.contador.entrada, [0, 1]);
  const y = useTransform(p, VENTANAS.contador.entrada, [24, 0]);
  const ayudaBruta = useTransform(p, [0.8, 0.96], [0, c.principal.valor]);
  const ayudaTexto = useTransform(ayudaBruta, (v) => numeroES(Math.round(v)));
  const restoBruta = useTransform(p, [0.84, 0.98], [0, c.secundario.valor]);
  const restoTexto = useTransform(restoBruta, (v) => numeroES(Math.round(v)));

  return (
    <m.div
      className={`rounded-2xl border border-linea bg-superficie/95 shadow-[0_14px_40px_rgba(24,33,28,.14)] backdrop-blur-sm ${
        estatico
          ? "mx-auto mt-5 max-w-[380px] p-4 sm:p-5"
          : "absolute inset-x-3 bottom-[2.5%] mx-auto max-w-[380px] p-4 sm:p-5"
      }`}
      style={estatico ? undefined : { opacity: opacidad, y }}
    >
      <p className="etiqueta-cota mb-3 text-verde">{c.titulo}</p>
      <div className="flex items-start justify-between gap-5">
        <div>
          <p className="text-[36px] leading-none font-extrabold tracking-display text-verde">
            <span className="mr-1 text-[13px] font-bold">{c.principal.prefijo}</span>
            {estatico ? (
              numeroES(c.principal.valor)
            ) : (
              <m.span>{ayudaTexto}</m.span>
            )}
            <span className="ml-1 text-[18px] font-bold">{c.principal.sufijo}</span>
          </p>
          <p className="mt-1.5 max-w-[16ch] text-[11.5px] leading-tight text-gris">
            {c.principal.etiqueta}
          </p>
        </div>
        <div className="text-right">
          <p className="text-[26px] leading-none font-extrabold tracking-display text-tinta">
            <span className="mr-1 text-[11px] font-bold">{c.secundario.prefijo}</span>
            {estatico ? (
              numeroES(c.secundario.valor)
            ) : (
              <m.span>{restoTexto}</m.span>
            )}
            <span className="ml-1 text-[14px] font-bold">{c.secundario.sufijo}</span>
          </p>
          <p className="mt-1.5 max-w-[17ch] text-[11.5px] leading-tight text-gris">
            {c.secundario.etiqueta}
          </p>
        </div>
      </div>
      <p className="mt-3 border-t border-linea pt-2.5 font-mono text-[9px] tracking-[0.06em] text-gris uppercase">
        {c.nota}
      </p>
    </m.div>
  );
}

function MicroLinea() {
  return (
    <p className="mt-3 font-mono text-[10.5px] tracking-[0.08em] text-gris">
      {hero.micro.split("**").map((parte, i) =>
        i % 2 === 1 ? (
          <strong key={i} className="font-semibold text-verde">
            {parte}
          </strong>
        ) : (
          parte
        ),
      )}
    </p>
  );
}

function ColumnaTexto({
  p,
  estatico,
}: {
  p: MotionValue<number>;
  estatico: boolean;
}) {
  return (
    <div className="relative z-10 max-w-[580px] lg:self-center">
      <Cejilla>{hero.cejilla}</Cejilla>
      <h1 className="text-[clamp(27px,7.6vw,54px)] leading-[1.05] font-extrabold tracking-display text-balance">
        {hero.titularLinea1}
        <span className="block text-verde">{hero.titularLinea2}</span>
      </h1>
      <p className="mt-4 max-w-[46ch] text-[15.5px] text-gris sm:mt-5 sm:text-[17.5px]">
        {hero.subtitulo.split("**").map((parte, i) =>
          i % 2 === 1 ? (
            <strong key={i} className="font-semibold text-tinta">
              {parte}
            </strong>
          ) : (
            parte
          ),
        )}
      </p>
      <div className="mt-5 flex flex-wrap gap-2.5 sm:mt-7 sm:gap-3">
        <Boton href="#contacto" className="max-sm:px-5 max-sm:py-3 max-sm:text-[14px]">
          {hero.ctaPrimario}
        </Boton>
        <Boton
          href="#como-funciona"
          variante="secundario"
          className="max-sm:px-5 max-sm:py-3 max-sm:text-[14px]"
        >
          {hero.ctaSecundario}
        </Boton>
      </div>
      <MicroLinea />
      <RielActos p={p} estatico={estatico} />
    </div>
  );
}

/** Escenario del alzado con todos los rótulos superpuestos. */
function Escenario({
  p,
  estatico,
}: {
  p: MotionValue<number>;
  estatico: boolean;
}) {
  return (
    <div
      className={
        estatico
          ? "relative"
          : "relative flex h-full min-h-0 items-center justify-center lg:-mr-[max(2rem,calc((100vw_-_1120px)/2+2rem))] lg:justify-end"
      }
    >
      <div
        className={
          estatico
            ? "relative mx-auto aspect-[1000/1180] w-full max-w-[560px]"
            : "relative aspect-[1000/1180] h-full w-auto max-w-full"
        }
      >
        <EscenaEsquina p={p} estatico={estatico} />

        <ChipFlotante
          p={p}
          estatico={estatico}
          oculto
          desdeInicio
          entrada={VENTANAS.ite.entrada}
          salida={VENTANAS.ite.salida}
          posicion={POSICIONES.ite}
        >
          <span className="block rounded-md border border-tinta/25 bg-superficie px-3 py-2 shadow-[0_2px_10px_rgba(24,33,28,.1)]">
            <span className="block font-mono text-[11px] font-bold tracking-[0.14em] whitespace-nowrap text-tinta uppercase">
              {hero.alzado.cotaIte}
            </span>
            <span className="mt-0.5 block font-mono text-[9px] tracking-[0.1em] whitespace-nowrap text-gris uppercase">
              {hero.alzado.cotaIteDetalle}
            </span>
          </span>
        </ChipFlotante>

        {hero.alzado.anotaciones.map((texto, i) => (
          <ChipFlotante
            key={texto}
            p={p}
            estatico={estatico}
            entrada={VENTANAS.anotacion(i).entrada}
            salida={estatico ? undefined : VENTANAS.anotacion(i).salida}
            posicion={POSICIONES.anotaciones[i]}
          >
            <ContenidoChip indice={`0${i + 1}`} texto={texto} />
          </ChipFlotante>
        ))}

      </div>

      <TarjetaContador p={p} estatico={estatico} />
    </div>
  );
}

export function Hero() {
  const sinMovimiento = useReducedMotion();
  /* En pantallas pequeñas la historia pierde sus piezas (chips y riel van
     ocultos) y cuesta tres pantallas de scroll: mejor la lámina estática.
     Arrancamos en estático y la historia se activa solo en escritorio. */
  const [pantallaPequena, setPantallaPequena] = useState(true);
  useEffect(() => {
    const consulta = window.matchMedia("(min-width: 640px)");
    const aplicar = () => setPantallaPequena(!consulta.matches);
    aplicar();
    consulta.addEventListener("change", aplicar);
    return () => consulta.removeEventListener("change", aplicar);
  }, []);
  const refContenedor = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: refContenedor,
    offset: ["start start", "end end"],
  });
  const p = useSpring(scrollYProgress, {
    stiffness: 140,
    damping: 26,
    restDelta: 0.001,
  });
  const opIndicacion = useTransform(p, [0.01, 0.06], [1, 0]);

  /* Versión estática: sin scroll-story, directamente el resultado. */
  if (sinMovimiento || pantallaPequena) {
    return (
      <header id="inicio" className="papel-plano bg-lavado">
        <div className="mx-auto grid max-w-[1120px] items-center gap-x-8 gap-y-10 px-5 pt-14 pb-16 sm:px-8 lg:grid-cols-[minmax(0,42fr)_minmax(0,58fr)] lg:pt-20">
          <ColumnaTexto p={p} estatico />
          <Escenario p={p} estatico />
        </div>
      </header>
    );
  }

  return (
    <header
      id="inicio"
      ref={refContenedor}
      className="relative h-[420svh]"
      aria-label="Presentación de Cimenta"
    >
      <div className="papel-plano sticky top-0 h-svh overflow-hidden bg-lavado">
        <div className="mx-auto grid h-full w-full max-w-[1120px] grid-rows-[auto_minmax(150px,1fr)] gap-x-8 gap-y-2 px-5 pt-[84px] pb-6 sm:px-8 lg:grid-cols-[minmax(0,42fr)_minmax(0,58fr)] lg:grid-rows-1 lg:pt-[84px]">
          <ColumnaTexto p={p} estatico={false} />
          <Escenario p={p} estatico={false} />
        </div>

        <m.p
          aria-hidden="true"
          className="absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-2.5 font-mono text-[9.5px] tracking-[0.16em] whitespace-nowrap text-gris uppercase"
          style={{ opacity: opIndicacion }}
        >
          <span className="inline-block h-6 w-px bg-verde" />
          {hero.indicacionScroll}
        </m.p>
      </div>
    </header>
  );
}
