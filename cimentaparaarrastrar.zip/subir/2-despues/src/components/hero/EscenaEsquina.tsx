"use client";

import { m, useTransform, type MotionValue } from "framer-motion";
import { hero } from "@/content";

/**
 * Escena firma del hero: edificio madrileño de esquina en perspectiva
 * de dos puntos, dibujado por código, sangrando por el borde izquierdo
 * de la lámina, con la marginalia de expediente (cota larga, mini-alzado,
 * marca de malla, cota vertical y cajetín) respirando a la derecha.
 * Al cargar se traza a sí mismo línea a línea; con el scroll vive los
 * tres actos (grietas → andamio y malla → renovado).
 */

const MONO = 'ui-monospace, "SF Mono", Menlo, Consolas, monospace';

/* ————— geometría de la perspectiva ————— */
const VPL = { x: -2050, y: 585 };
const VPR = { x: 2900, y: 585 };
const ESQ = { x: 400, t: 205, b: 1120 };

type Lado = "L" | "R";
function pt(lado: Lado, s: number, v: number) {
  const vp = lado === "L" ? VPL : VPR;
  const x = ESQ.x + s * (vp.x - ESQ.x);
  const yT = ESQ.t + s * (vp.y - ESQ.t);
  const yB = ESQ.b + s * (vp.y - ESQ.b);
  return { x, y: yT + v * (yB - yT) };
}
const n = (v: number) => v.toFixed(1);
function linea(lado: Lado, s1: number, v1: number, s2: number, v2: number) {
  const a = pt(lado, s1, v1);
  const b = pt(lado, s2, v2);
  return `M${n(a.x)} ${n(a.y)} L${n(b.x)} ${n(b.y)}`;
}
function cuadro(lado: Lado, s1: number, s2: number, v1: number, v2: number) {
  const a = pt(lado, s1, v1);
  const b = pt(lado, s2, v1);
  const c = pt(lado, s2, v2);
  const d = pt(lado, s1, v2);
  return `M${n(a.x)} ${n(a.y)} L${n(b.x)} ${n(b.y)} L${n(c.x)} ${n(c.y)} L${n(d.x)} ${n(d.y)} Z`;
}

/* crujías (con foreshortening) y forjados */
const CRUJIAS_L: [number, number][] = [[0.022, 0.058], [0.082, 0.114], [0.136, 0.164], [0.184, 0.209], [0.228, 0.249]];
const CRUJIAS_R: [number, number][] = [[0.03, 0.062], [0.09, 0.118]];
const PLANTAS_V = [0.055, 0.285, 0.515, 0.745];
const V_RIDGE = -0.115;
const FIN_L = 0.3;
const FIN_R = 0.145;

/* polígono de la fachada grande (izquierda), para recortar la malla */
const POLI_MALLA = (() => {
  const a = pt("L", 0, -0.015);
  const b = pt("L", 0.26, -0.015);
  const c = pt("L", 0.26, 1.005);
  const d = pt("L", 0, 1.005);
  return `M${n(a.x)} ${n(a.y)} L${n(b.x)} ${n(b.y)} L${n(c.x)} ${n(c.y)} L${n(d.x)} ${n(d.y)} Z`;
})();

/* ————— capa del edificio (dos variantes) ————— */
function Edificio({ limpia, trazado }: { limpia: boolean; trazado: boolean }) {
  const prin = limpia ? 0.8 : 0.5;
  const sec = limpia ? 0.42 : 0.26;
  const verde = "#25714f";
  const clase = (retraso: number) =>
    trazado ? { className: "tz", style: { animationDelay: `${retraso}s` } as React.CSSProperties, pathLength: 1 } : {};

  const caminos: React.ReactNode[] = [];
  let clave = 0;
  const add = (d: string, op: number, w: number, retraso: number, stroke = "#18211c") =>
    caminos.push(
      <path key={clave++} d={d} fill="none" stroke={stroke} strokeOpacity={op} strokeWidth={w} {...clase(retraso)} />,
    );

  /* arista de esquina y aleros */
  add(`M${ESQ.x} ${ESQ.t} L${ESQ.x} ${ESQ.b}`, prin, 1.7, 0.12);
  (["L", "R"] as Lado[]).forEach((lado) => {
    const fin = lado === "L" ? FIN_L : FIN_R;
    add(linea(lado, 0, 0, fin, 0), prin, 1.4, 0.06);
    add(linea(lado, 0, 0.03, fin, 0.03), sec, 1, 0.18);
    if (limpia) add(linea(lado, 0, 0.045, fin, 0.045), 0.5, 1, 0.18, "#7ec9a3");
  });

  /* forjados y línea de zócalo */
  (["L", "R"] as Lado[]).forEach((lado) => {
    const fin = lado === "L" ? FIN_L : FIN_R;
    PLANTAS_V.slice(1).forEach((v) => add(linea(lado, 0, v, fin, v), sec * 0.85, 1, 0.32));
    add(linea(lado, 0, 0.972, fin, 0.972), sec, 1, 0.32);
  });

  /* cubierta: caballetes, limahoyas, cursos de teja y chimenea */
  add(linea("L", 0.025, V_RIDGE, 0.27, V_RIDGE), prin, 1.3, 0);
  add(linea("R", 0.03, V_RIDGE, 0.125, V_RIDGE), prin, 1.3, 0);
  add(`M${n(pt("L", 0.025, V_RIDGE).x)} ${n(pt("L", 0.025, V_RIDGE).y)} L${ESQ.x} ${ESQ.t}`, prin, 1.2, 0.03);
  add(`M${n(pt("R", 0.03, V_RIDGE).x)} ${n(pt("R", 0.03, V_RIDGE).y)} L${ESQ.x} ${ESQ.t}`, prin, 1.2, 0.03);
  [-0.045, -0.08].forEach((v) => {
    add(linea("L", 0.012, v, 0.285, v), sec * 0.6, 0.9, 0.22);
    add(linea("R", 0.015, v, 0.138, v), sec * 0.6, 0.9, 0.22);
  });
  const ch = pt("L", 0.245, V_RIDGE);
  add(`M${n(ch.x)} ${n(ch.y)} L${n(ch.x)} ${n(ch.y - 26)} L${n(ch.x + 20)} ${n(ch.y - 26)} L${n(ch.x + 20)} ${n(ch.y + 4)}`, sec, 1, 0.1);
  add(`M${n(ch.x - 3)} ${n(ch.y - 26)} L${n(ch.x + 23)} ${n(ch.y - 26)}`, sec, 1, 0.12);

  /* buhardillas asentadas en el plano de cubierta */
  const buhardilla = (lado: Lado, s1: number, s2: number, retraso: number) => {
    const sm = (s1 + s2) / 2;
    add(cuadro(lado, s1, s2, -0.075, -0.028), prin * 0.95, 1, retraso);
    const a = pt(lado, s1, -0.075);
    const b = pt(lado, s2, -0.075);
    const apice = pt(lado, sm, -0.102);
    add(`M${n(a.x)} ${n(a.y)} L${n(apice.x)} ${n(apice.y)} L${n(b.x)} ${n(b.y)}`, prin * 0.95, 1, retraso + 0.04);
    add(cuadro(lado, s1 + (s2 - s1) * 0.28, s1 + (s2 - s1) * 0.72, -0.066, -0.034), sec, 0.9, retraso + 0.08);
  };
  [[0.03, 0.055], [0.09, 0.112], [0.145, 0.164], [0.196, 0.213]].forEach(([a, b], i) => buhardilla("L", a, b, 0.26 + i * 0.05));
  [[0.038, 0.062], [0.095, 0.116]].forEach(([a, b], i) => buhardilla("R", a, b, 0.3 + i * 0.05));

  /* ventanas y balcones */
  const huecos = (lado: Lado, crujias: [number, number][]) => {
    crujias.forEach(([s1, s2], columna) => {
      PLANTAS_V.forEach((vt, planta) => {
        const retraso = 0.5 + planta * 0.09 + columna * 0.05;
        add(cuadro(lado, s1, s2, vt + 0.05, vt + 0.2), prin, 1, retraso);
        add(linea(lado, (s1 + s2) / 2, vt + 0.05, (s1 + s2) / 2, vt + 0.2), sec * 0.8, 0.9, retraso + 0.1);
        const bs1 = s1 - 0.007;
        const bs2 = s2 + 0.007;
        add(cuadro(lado, bs1, bs2, vt + 0.125, vt + 0.208), limpia ? 0.7 : sec, 1, retraso + 0.12, limpia ? verde : "#18211c");
        [0.25, 0.5, 0.75].forEach((f) =>
          add(linea(lado, bs1 + (bs2 - bs1) * f, vt + 0.125, bs1 + (bs2 - bs1) * f, vt + 0.208), limpia ? 0.45 : sec * 0.7, 0.8, retraso + 0.16, limpia ? verde : "#18211c"),
        );
        add(linea(lado, bs1 - 0.004, vt + 0.212, bs2 + 0.004, vt + 0.212), prin, 1.3, retraso + 0.1);
      });
      if (columna > 0) add(cuadro(lado, s1, s2, 0.79, 0.9), sec, 1, 0.92);
    });
  };
  huecos("L", CRUJIAS_L);
  huecos("R", CRUJIAS_R);

  /* portal en la fachada grande */
  add(cuadro("L", 0.024, 0.056, 0.792, 0.972), prin, 1.2, 0.98);
  add(linea("L", 0.04, 0.792, 0.04, 0.972), limpia ? 0.7 : sec, 1, 1.02, limpia ? verde : "#18211c");

  /* suelo */
  const gI = pt("L", 0.32, 1.002);
  const gD = pt("R", 0.17, 1.002);
  add(`M${n(gI.x)} ${n(gI.y)} L${ESQ.x} ${ESQ.b} L${n(gD.x)} ${n(gD.y)}`, 0.45, 1.2, 1.06);

  return <g>{caminos}</g>;
}

/* grietas del acto 1 */
function Grietas() {
  const j = (lado: Lado, puntos: [number, number][]) =>
    "M" + puntos.map(([s, v]) => `${n(pt(lado, s, v).x)} ${n(pt(lado, s, v).y)}`).join(" L");
  return (
    <g stroke="#18211c" strokeOpacity="0.75" strokeWidth="1.5" fill="none" strokeLinejoin="round">
      <path d={j("L", [[0.008, 0.09], [0.026, 0.2], [0.011, 0.32], [0.03, 0.44], [0.016, 0.55]])} />
      <path d={j("L", [[0.026, 0.2], [0.045, 0.245]])} />
      <path d={j("R", [[0.02, 0.5], [0.045, 0.6], [0.028, 0.72]])} />
      <path d={j("L", [[0.155, 0.28], [0.172, 0.33], [0.158, 0.38]])} />
      <path d={cuadro("L", 0.1, 0.13, 0.56, 0.615)} fill="url(#descascarillado-e)" stroke="#18211c" strokeOpacity="0.3" strokeWidth="1" />
    </g>
  );
}

/* ————— escena completa ————— */
export function EscenaEsquina({ p, estatico }: { p: MotionValue<number>; estatico: boolean }) {
  const opGrietas = useTransform(p, [0.28, 0.4], [1, 0]);
  const opIte = useTransform(p, [0.26, 0.33], [1, 0]);
  const opAndamio = useTransform(p, [0.74, 0.82], [1, 0]);
  const escalaMalla = useTransform(p, [0.46, 0.62], [0, 1]);
  const opMalla = useTransform(p, [0.44, 0.48, 0.72, 0.78], [0, 0.92, 0.92, 0]);
  const yMalla = useTransform(p, [0.72, 0.78], [0, 40]);
  const opApagada = useTransform(p, [0.68, 0.8], [1, 0]);
  const opLimpia = useTransform(p, [0.7, 0.84], [0, 1]);
  const opRef = [
    useTransform(p, [0.5, 0.51, 0.71, 0.755], [0, 1, 1, 0]),
    useTransform(p, [0.555, 0.565, 0.71, 0.755], [0, 1, 1, 0]),
    useTransform(p, [0.61, 0.62, 0.71, 0.755], [0, 1, 1, 0]),
  ];
  const fijar = (mv: MotionValue<number>, fijo: number) => (estatico ? fijo : mv);

  /* andamio sobre la fachada grande */
  const montantes = [0.004, 0.06, 0.117, 0.17, 0.22, 0.262];
  const plataformas = [-0.02, 0.15, 0.32, 0.49, 0.66, 0.83, 1.0];
  const useLargoTrazo = (i: number, desde: number) =>
    useTransform(p, [desde + i * 0.013, desde + 0.1 + i * 0.013], [0.001, 1]);
  /* montantes y plataformas son constantes de módulo: la lista de hooks es estable entre renders */
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const trazosMontantes = montantes.map((s, i) => ({ d: linea("L", s, -0.03, s, 1.01), largo: useLargoTrazo(i, 0.26) }));
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const trazosPlataformas = plataformas.map((v, i) => ({ d: linea("L", 0, v, 0.265, v), largo: useLargoTrazo(i, 0.33) }));

  /* puntos de referencia de las anotaciones */
  const REFS = [pt("L", 0.04, 0.18), pt("L", 0.135, 0.42), pt("L", 0.085, 0.68)];
  const ITE = pt("L", 0.011, 0.32);

  return (
    <svg
      viewBox="0 0 1000 1180"
      className={`h-full w-full ${estatico ? "" : "dibujo-heroe"}`}
      role="img"
      aria-label={hero.alzado.tituloAccesible}
    >
      <defs>
        <pattern id="trama-malla-e" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#2e8a61" strokeWidth="1" opacity="0.55" />
        </pattern>
        <pattern id="descascarillado-e" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="5" stroke="#18211c" strokeWidth="0.7" opacity="0.22" />
        </pattern>
        <pattern id="trama-marca-e" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="9" stroke="rgba(255,255,255,.52)" strokeWidth="2.4" />
        </pattern>
        <clipPath id="recorte-malla-e"><path d={POLI_MALLA} /></clipPath>
        <clipPath id="recorte-marca-e"><rect x="742" y="298" width="68" height="68" rx="16" /></clipPath>
      </defs>

      {/* ——— marginalia de la lámina ——— */}
      <g stroke="#5b6862" strokeWidth="0.9" fill="none" aria-hidden="true">
        <line x1="34" y1="52" x2="966" y2="52" strokeOpacity="0.5" />
        <line x1="34" y1="45" x2="34" y2="59" strokeOpacity="0.7" />
        <line x1="966" y1="45" x2="966" y2="59" strokeOpacity="0.7" />
        <line x1="30" y1="56" x2="38" y2="48" strokeOpacity="0.8" />
        <line x1="962" y1="56" x2="970" y2="48" strokeOpacity="0.8" />
      </g>
      <text x="640" y="40" fontFamily={MONO} fontSize="11" letterSpacing="2.2" fill="#5b6862" aria-hidden="true">
        {hero.alzado.expediente.toUpperCase()}
      </text>

      {/* mini-alzado de estudio, arriba a la derecha */}
      <g className="hidden lg:block" aria-hidden="true">
        <g stroke="#18211c" strokeOpacity="0.35" fill="none" strokeWidth="1">
          <rect x="775" y="128" width="150" height="118" />
          <line x1="768" y1="128" x2="932" y2="128" strokeWidth="1.3" />
          {[0, 1].map((f) =>
            [0, 1, 2].map((c) => (
              <rect key={`${f}${c}`} x={791 + c * 48} y={143 + f * 38} width="26" height="24" strokeOpacity="0.28" />
            )),
          )}
          <rect x="835" y="216" width="30" height="30" strokeOpacity="0.4" />
          <line x1="757" y1="246" x2="940" y2="246" strokeOpacity="0.5" />
        </g>
        <text x="775" y="268" fontFamily={MONO} fontSize="8.5" letterSpacing="1.6" fill="#5b6862" fillOpacity="0.8">
          ALZADO DE ESTUDIO · E 1:200
        </text>
      </g>

      {/* marca de malla flotante */}
      <g aria-hidden="true">
        <rect x="742" y="298" width="68" height="68" rx="16" fill="#25714f" />
        <g clipPath="url(#recorte-marca-e)"><rect x="736" y="292" width="80" height="80" fill="url(#trama-marca-e)" /></g>
      </g>

      {/* cota vertical derecha */}
      <g stroke="#5b6862" strokeWidth="0.9" fill="none" aria-hidden="true">
        <line x1="930" y1="430" x2="930" y2="1000" strokeOpacity="0.5" />
        <line x1="924" y1="430" x2="936" y2="430" strokeOpacity="0.7" />
        <line x1="924" y1="1000" x2="936" y2="1000" strokeOpacity="0.7" />
        <line x1="926" y1="434" x2="934" y2="426" strokeOpacity="0.8" />
        <line x1="926" y1="1004" x2="934" y2="996" strokeOpacity="0.8" />
      </g>
      <text
        transform="translate(946 715) rotate(90)"
        textAnchor="middle"
        fontFamily={MONO}
        fontSize="9"
        letterSpacing="2"
        fill="#5b6862"
        fillOpacity="0.8"
        aria-hidden="true"
      >
        {hero.alzado.coordenadas.toUpperCase()}
      </text>

      {/* cajetín */}
      <g className="hidden sm:block" aria-hidden="true">
        <rect x="640" y="1072" width="346" height="86" fill="#ffffff" fillOpacity="0.9" stroke="#5b6862" strokeOpacity="0.5" strokeWidth="1" />
        <line x1="640" y1="1100" x2="986" y2="1100" stroke="#5b6862" strokeOpacity="0.35" strokeWidth="0.8" />
        <line x1="640" y1="1129" x2="986" y2="1129" stroke="#5b6862" strokeOpacity="0.35" strokeWidth="0.8" />
        <g fontFamily={MONO} fill="#18211c">
          <text x="652" y="1091" fontSize="9.5" letterSpacing="1.1" fontWeight="bold" fillOpacity="0.85">CIMENTA · CONSULTORES EN REHABILITACIÓN</text>
          <text x="652" y="1119" fontSize="9" letterSpacing="1.3" fillOpacity="0.65">{hero.alzado.expediente.toUpperCase()} · PERSPECTIVA · E 1:75</text>
          <text x="652" y="1148" fontSize="9" letterSpacing="1.3" fillOpacity="0.65">{hero.alzado.coordenadas.toUpperCase()}</text>
        </g>
      </g>

      {/* rayado de suelo a la izquierda */}
      <g stroke="#18211c" strokeOpacity="0.28" aria-hidden="true">
        {[40, 105, 170, 235, 300].map((x) => (
          <line key={x} x1={x} y1="1132" x2={x - 16} y2="1152" strokeWidth="0.9" />
        ))}
        <line x1="16" y1="1126" x2="330" y2="1126" strokeWidth="1" strokeOpacity="0.4" />
      </g>

      {/* masas del edificio: la lámina deja de ser solo línea */}
      <g aria-hidden="true">
        <path d={cuadro("L", 0, FIN_L, 0, 1.002)} fill="#ffffff" fillOpacity="0.92" />
        <path d={cuadro("R", 0, FIN_R, 0, 1.002)} fill="#ffffff" fillOpacity="0.92" />
        <path
          d={`M${n(pt("L", 0, 0).x)} ${n(pt("L", 0, 0).y)} L${n(pt("L", 0.025, V_RIDGE).x)} ${n(pt("L", 0.025, V_RIDGE).y)} L${n(pt("L", 0.27, V_RIDGE).x)} ${n(pt("L", 0.27, V_RIDGE).y)} L${n(pt("L", FIN_L, 0).x)} ${n(pt("L", FIN_L, 0).y)} Z`}
          fill="#e9f1ea"
          fillOpacity="0.9"
        />
        <path
          d={`M${n(pt("R", 0, 0).x)} ${n(pt("R", 0, 0).y)} L${n(pt("R", 0.03, V_RIDGE).x)} ${n(pt("R", 0.03, V_RIDGE).y)} L${n(pt("R", 0.125, V_RIDGE).x)} ${n(pt("R", 0.125, V_RIDGE).y)} L${n(pt("R", FIN_R, 0).x)} ${n(pt("R", FIN_R, 0).y)} Z`}
          fill="#e9f1ea"
          fillOpacity="0.9"
        />
      </g>

      {/* ——— edificio: capa deteriorada y capa renovada ——— */}
      <m.g style={{ opacity: fijar(opApagada, 0) }}>
        <Edificio limpia={false} trazado={!estatico} />
      </m.g>
      <m.g style={{ opacity: fijar(opLimpia, 1) }}>
        <Edificio limpia trazado={false} />
      </m.g>

      {/* grietas y diagnóstico */}
      <m.g style={{ opacity: fijar(opGrietas, 0) }} aria-hidden="true">
        <Grietas />
      </m.g>
      <m.g style={{ opacity: fijar(opIte, 0) }} aria-hidden="true">
        <circle cx={ITE.x} cy={ITE.y} r="3" fill="#18211c" />
        <circle cx={ITE.x} cy={ITE.y} r="8" fill="none" stroke="#18211c" strokeOpacity="0.3" />
        {!estatico && (
          <m.circle
            cx={ITE.x}
            cy={ITE.y}
            r="8"
            fill="none"
            stroke="#18211c"
            strokeOpacity="0.4"
            style={{ transformBox: "fill-box", transformOrigin: "50% 50%" }}
            animate={{ scale: [1, 2], opacity: [0.5, 0] }}
            transition={{ duration: 2.6, repeat: Infinity, ease: "easeOut" }}
          />
        )}
      </m.g>

      {/* andamio y malla en la fachada grande */}
      <m.g style={{ opacity: fijar(opAndamio, 0) }} aria-hidden="true">
        {trazosMontantes.map((t, i) => (
          <m.path key={`m${i}`} d={t.d} fill="none" stroke="#25714f" strokeWidth="1.7" strokeOpacity="0.9" style={estatico ? undefined : { pathLength: t.largo }} />
        ))}
        {trazosPlataformas.map((t, i) => (
          <m.path key={`p${i}`} d={t.d} fill="none" stroke="#25714f" strokeWidth="1.2" strokeOpacity="0.7" style={estatico ? undefined : { pathLength: t.largo }} />
        ))}
      </m.g>
      <m.g style={{ opacity: fijar(opMalla, 0), y: fijar(yMalla, 0) }} aria-hidden="true">
        <g clipPath="url(#recorte-malla-e)">
          <m.g style={estatico ? { opacity: 0 } : { scaleY: escalaMalla, transformOrigin: "50% 0%", transformBox: "fill-box" }}>
            <rect x="-260" y="140" width="680" height="1000" fill="rgba(126,201,163,0.13)" />
            <rect x="-260" y="140" width="680" height="1000" fill="url(#trama-malla-e)" />
          </m.g>
        </g>
        <path d={POLI_MALLA} fill="none" stroke="#2e8a61" strokeOpacity="0.4" strokeWidth="1" />
      </m.g>

      {/* referencias de las anotaciones */}
      {REFS.map((punto, i) => (
        <m.g key={i} style={{ opacity: fijar(opRef[i], 1) }} aria-hidden="true">
          <circle cx={punto.x} cy={punto.y} r="3" fill="#25714f" />
          <circle cx={punto.x} cy={punto.y} r="8.5" fill="none" stroke="#7ec9a3" strokeOpacity="0.8" />
        </m.g>
      ))}
    </svg>
  );
}
