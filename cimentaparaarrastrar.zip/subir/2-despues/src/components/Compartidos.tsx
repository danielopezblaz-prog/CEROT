"use client";

import { m } from "framer-motion";
import type { ReactNode } from "react";
import { marca } from "@/content";

/** Cejilla de sección: etiqueta monospace con guion de cota. */
export function Cejilla({
  children,
  clara = false,
}: {
  children: ReactNode;
  clara?: boolean;
}) {
  return (
    <p
      className={`etiqueta-cota mb-3 flex items-center gap-3 ${
        clara ? "text-malla" : "text-verde"
      }`}
    >
      <span
        aria-hidden="true"
        className={`inline-block h-px w-8 ${clara ? "bg-malla" : "bg-verde"}`}
      />
      {children}
    </p>
  );
}

/** Botón/enlace primario o secundario con pulsación a escala 0.98. */
export function Boton({
  href,
  children,
  variante = "primario",
  className = "",
}: {
  href: string;
  children: ReactNode;
  variante?: "primario" | "secundario" | "malla";
  className?: string;
}) {
  const estilos = {
    primario:
      "bg-verde text-white hover:bg-verde-oscuro shadow-[0_1px_2px_rgba(24,33,28,.12)]",
    secundario:
      "bg-transparent text-tinta border border-linea-fuerte hover:border-tinta/40 hover:bg-superficie",
    malla: "bg-malla text-tinta font-bold hover:bg-[#8fd4b0]",
  }[variante];

  return (
    <m.a
      href={href}
      whileTap={{ scale: 0.98 }}
      className={`inline-block rounded-full px-7 py-3.5 text-center text-[15px] font-semibold transition-colors duration-200 ${estilos} ${className}`}
    >
      {children}
    </m.a>
  );
}

/** Marca de la casa: cuadrado verde con trama de malla. */
export function MarcaLogo({ tamano = 38 }: { tamano?: number }) {
  return (
    <span
      aria-hidden="true"
      className="trama-malla-clara relative inline-block shrink-0 overflow-hidden rounded-lg bg-verde"
      style={{ width: tamano, height: tamano }}
    />
  );
}

/** Logotipo completo: marca + nombre + claim. */
export function Logotipo({ claro = false }: { claro?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <MarcaLogo />
      <span className="leading-none">
        <span
          className={`block text-[21px] font-extrabold tracking-display ${
            claro ? "text-white" : "text-tinta"
          }`}
        >
          Cimenta
        </span>
        <span
          className={`mt-1 block font-mono text-[9px] uppercase tracking-[0.16em] ${
            claro ? "text-white/60" : "text-gris"
          }`}
        >
          {marca.claim}
        </span>
      </span>
    </span>
  );
}
