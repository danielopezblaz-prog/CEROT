"use client";

import { preguntas } from "@/content";
import { conNegritas } from "@/lib/texto";
import { Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";

/** Acordeón accesible con <details>/<summary> nativos. */
export function Preguntas() {
  return (
    <section id="preguntas" className="mx-auto max-w-[1120px] px-5 pb-12 sm:px-8 sm:pb-20 md:pb-28">
      <Reveal>
        <Cejilla>{preguntas.cejilla}</Cejilla>
        <h2 className="max-w-[22ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display">
          {preguntas.titulo}
        </h2>
      </Reveal>

      <Reveal retraso={0.06}>
        <div className="mt-8 max-w-[820px]">
          {preguntas.lista.map((elemento) => (
            <details key={elemento.pregunta} className="group border-b border-linea">
              <summary className="sin-marcador flex cursor-pointer items-center justify-between gap-4 rounded-md py-5 pr-1 text-[15.5px] font-semibold transition-colors hover:text-verde">
                {elemento.pregunta}
                <span
                  aria-hidden="true"
                  className="font-mono text-[19px] leading-none text-verde transition-transform duration-300 group-open:rotate-45"
                >
                  +
                </span>
              </summary>
              <p className="max-w-[62ch] pb-6 text-[15px] leading-relaxed text-gris">
                {conNegritas(elemento.respuesta)}
                {"ruta" in elemento && elemento.ruta && (
                  <>
                    {" "}
                    <a
                      href={elemento.ruta}
                      className="font-semibold text-verde underline underline-offset-2 hover:text-verde-oscuro"
                    >
                      {elemento.enlace}
                    </a>
                  </>
                )}
              </p>
            </details>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
