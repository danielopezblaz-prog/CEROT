import Link from "next/link";
import { hayDireccion, hayTelefono, marca, nav, pie } from "@/content";
import { PAGINAS } from "@/content-paginas";
import { Logotipo } from "./Compartidos";

/**
 * `base` prefija las anclas de sección igual que en Nav: vacío en la home,
 * "/" en las páginas de aterrizaje.
 */
export function PieDePagina({ base = "" }: { base?: string }) {
  return (
    <footer className="mx-auto max-w-[1120px] px-5 pt-6 pb-10 sm:px-8 sm:pt-14">
      <div className="flex flex-col justify-between gap-8 border-t border-linea pt-8 sm:flex-row sm:items-start sm:pt-10">
        <div>
          <Logotipo />
          <p className="mt-3 max-w-[36ch] text-[13px] text-gris">
            {pie.descripcion}
          </p>

          {/* Datos de contacto: cada uno aparece solo si existe de verdad.
              Deben escribirse igual que en el Perfil de Empresa en Google. */}
          <address className="mt-2 grid gap-1 not-italic">
            <a
              href={`mailto:${marca.email}`}
              className="inline-block w-fit rounded-md text-[13px] font-semibold text-verde hover:text-verde-oscuro"
            >
              {marca.email}
            </a>
            {hayTelefono() && (
              <a
                href={`tel:${marca.telefonoE164 || marca.telefono}`}
                className="inline-block w-fit rounded-md text-[13px] font-semibold text-verde hover:text-verde-oscuro"
              >
                {marca.telefono}
              </a>
            )}
            {hayDireccion() ? (
              <span className="text-[13px] text-gris">
                {marca.direccion.calle}
                {marca.direccion.codigoPostal
                  ? ` · ${marca.direccion.codigoPostal}`
                  : ""}{" "}
                {marca.direccion.localidad}
              </span>
            ) : (
              <span className="text-[13px] text-gris">{pie.areaServicio}</span>
            )}
          </address>
        </div>

        <nav aria-label="Pie de página" className="flex flex-wrap gap-x-12 gap-y-6">
          <ul className="grid content-start gap-2">
            {nav.enlaces.map((enlace) => (
              <li key={enlace.ancla}>
                <a
                  href={`${base}${enlace.ancla}`}
                  className="rounded-md text-[13.5px] text-gris transition-colors hover:text-tinta"
                >
                  {enlace.texto}
                </a>
              </li>
            ))}
          </ul>
          <ul className="grid content-start gap-2">
            {PAGINAS.map((pagina) => (
              <li key={pagina.ruta}>
                <Link
                  href={pagina.ruta}
                  className="rounded-md text-[13.5px] text-gris transition-colors hover:text-tinta"
                >
                  {pagina.nombre}
                </Link>
              </li>
            ))}
          </ul>
          <ul className="grid content-start gap-2">
            {pie.enlacesLegales.map((enlace) => (
              <li key={enlace.ruta}>
                <Link
                  href={enlace.ruta}
                  className="rounded-md text-[13.5px] text-gris transition-colors hover:text-tinta"
                >
                  {enlace.texto}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      <div className="mt-10 flex flex-wrap items-center justify-between gap-3 border-t border-linea pt-5">
        <p className="font-mono text-[10px] tracking-[0.08em] text-gris">
          {pie.derechos}
        </p>
        <a
          href={base || "#inicio"}
          className="etiqueta-cota rounded-md text-[9.5px] text-gris transition-colors hover:text-verde"
        >
          {pie.volverArriba} ↑
        </a>
      </div>
    </footer>
  );
}
