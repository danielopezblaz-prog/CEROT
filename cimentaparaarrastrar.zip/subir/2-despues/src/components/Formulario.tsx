"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { m } from "framer-motion";
import { formulario, marca } from "@/content";
import { EVENTOS, evento } from "@/lib/analitica";
import { numeroES } from "@/lib/texto";
import { Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";

type Estado = "rellenando" | "enviando" | "exito" | "error";
type Simulacion = {
  viviendas: number;
  obra: string;
  importe: number;
  ayuda: number;
  cuota: number;
};

function resumenSimulacion(sim: Simulacion) {
  return `${sim.viviendas} viv · ${sim.obra} · ${numeroES(sim.importe)} €/viv · ayuda ${sim.ayuda} % · cuota ~${sim.cuota} €/mes`;
}

type Datos = {
  rol: string;
  direccion: string;
  nombre: string;
  contacto: string;
};
type Errores = Partial<
  Record<"nombre" | "direccion" | "contacto" | "consentimiento", string>
>;

function MensajeError({
  campo,
  errores,
}: {
  campo: keyof Errores;
  errores: Errores;
}) {
  if (!errores[campo]) return null;
  return (
    <p
      id={`error-${campo}`}
      className="mt-1.5 flex items-start gap-1.5 text-[12px] leading-snug font-medium text-malla"
    >
      <span aria-hidden="true" className="font-mono">▲</span>
      {errores[campo]}
    </p>
  );
}

/** Bloque numerado de la ficha, como una casilla de formulario impreso. */
function Bloque({
  numero,
  titulo,
  ultimo = false,
  children,
}: {
  numero: string;
  titulo: string;
  ultimo?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={`py-5 ${ultimo ? "" : "border-b border-dashed border-white/10"}`}>
      <div className="flex items-baseline gap-3.5">
        <span
          aria-hidden="true"
          className="w-[30px] shrink-0 font-mono text-[14px] leading-none font-bold text-malla/60 tabular-nums sm:text-[15px]"
        >
          {numero}
        </span>
        <p className="font-mono text-[10px] font-semibold tracking-[0.16em] text-white/60 uppercase">
          {titulo}
        </p>
      </div>
      <div className="mt-3.5 grid gap-4 sm:pl-[44px]">{children}</div>
    </div>
  );
}

/** Origen de la visita: URL, referrer y parámetros UTM si los hay. */
function leerOrigen() {
  try {
    const parametros = new URLSearchParams(window.location.search);
    return {
      url: window.location.href,
      referrer: document.referrer,
      utmSource: parametros.get("utm_source") ?? "",
      utmMedium: parametros.get("utm_medium") ?? "",
      utmCampaign: parametros.get("utm_campaign") ?? "",
      utmTerm: parametros.get("utm_term") ?? "",
      utmContent: parametros.get("utm_content") ?? "",
    };
  } catch {
    return {};
  }
}

const ES_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const ES_TELEFONO = /^\+?[\d\s().-]{9,}$/;

const claseCampo =
  "w-full rounded-xl border border-white/15 bg-white/[.07] px-3.5 py-3.5 text-[16px] text-white placeholder:text-white/35 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-malla";
const claseEtiqueta =
  "mb-1.5 block font-mono text-[9.5px] uppercase tracking-[0.14em] text-white/60";

export function Formulario() {
  const router = useRouter();
  const [datos, setDatos] = useState<Datos>({
    rol: "",
    direccion: "",
    nombre: "",
    contacto: "",
  });
  const [errores, setErrores] = useState<Errores>({});
  const [estado, setEstado] = useState<Estado>("rellenando");
  const [senuelo, setSenuelo] = useState("");
  const [consentimiento, setConsentimiento] = useState(false);
  const [sim, setSim] = useState<Simulacion | null>(null);
  const [resalte, setResalte] = useState(0);

  /* la simulación llega del simulador y viaja entera con la solicitud */
  useEffect(() => {
    const acoger = (nueva: Simulacion) => setSim(nueva);
    try {
      const guardada = sessionStorage.getItem("cimenta-simulacion");
      if (guardada) acoger(JSON.parse(guardada) as Simulacion);
    } catch {
      /* sin almacenamiento: solo eventos en vivo */
    }
    const alSimular = (evento: Event) =>
      acoger((evento as CustomEvent<Simulacion>).detail);
    window.addEventListener("cimenta:simulacion", alSimular);
    return () => window.removeEventListener("cimenta:simulacion", alSimular);
  }, []);

  /* cualquier CTA hacia #contacto hace brillar la tarjeta al aterrizar */
  useEffect(() => {
    const alPulsar = (evento: MouseEvent) => {
      const enlace = (evento.target as HTMLElement).closest?.(
        'a[href="#contacto"]',
      );
      if (enlace) setResalte((n) => n + 1);
    };
    document.addEventListener("click", alPulsar);
    return () => document.removeEventListener("click", alPulsar);
  }, []);

  function quitarSimulacion() {
    setSim(null);
    try {
      sessionStorage.removeItem("cimenta-simulacion");
    } catch {
      /* nada que limpiar */
    }
  }

  const cambiar =
    (campo: keyof Datos) => (evento: React.ChangeEvent<HTMLInputElement>) =>
      setDatos((d) => ({ ...d, [campo]: evento.target.value }));

  /* el papel es opcional: tocar el chip activo lo deselecciona */
  function alternarRol(nombre: string) {
    setDatos((d) => ({ ...d, rol: d.rol === nombre ? "" : nombre }));
  }

  function validar(): boolean {
    const nuevos: Errores = {};
    if (!datos.direccion.trim()) nuevos.direccion = formulario.errores.direccion;
    if (!datos.nombre.trim()) nuevos.nombre = formulario.errores.nombre;
    const contacto = datos.contacto.trim();
    if (!ES_EMAIL.test(contacto) && !ES_TELEFONO.test(contacto)) {
      nuevos.contacto = formulario.errores.contacto;
    }
    if (!consentimiento) {
      nuevos.consentimiento = formulario.errores.consentimiento;
    }
    setErrores(nuevos);
    const primero = Object.keys(nuevos)[0];
    if (primero) {
      document.getElementById(`campo-${primero}`)?.focus({ preventScroll: true });
      return false;
    }
    return true;
  }

  async function enviar() {
    if (!validar()) return;
    setEstado("enviando");
    try {
      const respuesta = await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre: datos.nombre.trim(),
          rol: datos.rol,
          direccion: datos.direccion.trim(),
          viviendas: sim ? String(sim.viviendas) : "",
          contacto: datos.contacto.trim(),
          simulacion: sim ? resumenSimulacion(sim) : "",
          consentimiento,
          origen: leerOrigen(),
          referencia: senuelo,
        }),
      });
      if (!respuesta.ok) throw new Error("respuesta no válida");
      setEstado("exito");
      /* La conversión, antes de navegar. Si no hay analítica, no hace nada. */
      evento(EVENTOS.solicitudEnviada, { origen: window.location.pathname });
      /* Página de gracias con URL propia: destino estable para medir
         conversiones y, de paso, recargar ya no reenvía la solicitud.
         Si la navegación falla, la tarjeta de éxito ya está en pantalla. */
      router.push("/solicitud-recibida");
    } catch {
      setEstado("error");
    }
  }

  function reiniciar() {
    setDatos({ rol: "", direccion: "", nombre: "", contacto: "" });
    setErrores({});
    setEstado("rellenando");
  }

  return (
    <section id="contacto" className="sobre-tinta trama-malla bg-tinta">
      <div className="mx-auto grid max-w-[1120px] gap-8 px-5 py-16 sm:px-8 md:py-28 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)] lg:grid-rows-[auto_1fr] lg:gap-x-14 lg:gap-y-8">
        <Reveal className="lg:col-start-1 lg:row-start-1">
          <Cejilla clara>{formulario.cejilla}</Cejilla>
          <h2 className="max-w-[20ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display text-white">
            {formulario.titulo}
          </h2>
          <p className="mt-4 max-w-[48ch] text-[15px] text-white/70">
            {formulario.intro}
          </p>
        </Reveal>

        {/* en móvil la ficha va justo tras el titular; los argumentos, después */}
        <Reveal className="order-2 lg:order-none lg:col-start-1 lg:row-start-2 lg:self-start" retraso={0.05}>
          <div className="rounded-3xl border border-white/10 bg-white/[.04] p-5">
            <p className="etiqueta-cota text-malla">
              {formulario.queRecibiras.titulo}
            </p>
            <ul className="mt-3 grid gap-2.5">
              {formulario.queRecibiras.puntos.map((punto) => (
                <li key={punto} className="flex items-start gap-2.5 text-[14px] text-white/80">
                  <svg viewBox="0 0 16 16" className="mt-1 h-3.5 w-3.5 shrink-0" aria-hidden="true">
                    <path d="M2.5 8.5 L6.5 12.5 L13.5 4" stroke="#7ec9a3" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  {punto}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <Reveal className="order-1 lg:order-none lg:col-start-2 lg:row-span-2 lg:row-start-1" retraso={0.08}>
          <div aria-live="polite">
            {estado === "exito" ? (
              <div
                key={`exito-${resalte}`}
                className={`flex h-full flex-col items-start justify-center rounded-3xl border-2 border-dashed border-malla/60 p-8 sm:p-10 ${
                  resalte > 0 ? "brillo-llegada" : ""
                }`}
              >
                <p className="etiqueta-cota inline-block -rotate-2 rounded-md border-2 border-malla px-3 py-2 font-bold text-malla">
                  {formulario.exito.sello}
                </p>
                <h3 className="mt-6 text-[24px] leading-tight font-extrabold tracking-display text-white">
                  {formulario.exito.titulo}
                </h3>
                <p className="mt-3 max-w-[44ch] text-[14.5px] text-white/70">
                  {formulario.exito.texto}
                </p>
                <button
                  type="button"
                  onClick={reiniciar}
                  className="mt-7 rounded-lg border border-white/25 px-4 py-2.5 text-[13.5px] font-semibold text-white transition-colors hover:border-malla hover:text-malla"
                >
                  {formulario.exito.boton}
                </button>
              </div>
            ) : (
              <div
                key={`tarjeta-${resalte}`}
                className={`rounded-3xl border border-white/10 bg-white/[.04] p-5 sm:p-7 ${
                  resalte > 0 ? "brillo-llegada" : ""
                }`}
              >
                {/* la simulación que trae la persona, si ha usado el simulador */}
                {sim && (
                  <div className="mb-4 flex items-start justify-between gap-3 rounded-lg border border-malla/40 bg-malla/10 px-3 py-2.5">
                    <p className="font-mono text-[9.5px] leading-relaxed tracking-[0.1em] text-malla uppercase">
                      {formulario.simulacion.etiqueta} · {resumenSimulacion(sim)}
                    </p>
                    <button
                      type="button"
                      onClick={quitarSimulacion}
                      aria-label={formulario.simulacion.quitar}
                      className="text-[16px] leading-none text-white/50 transition-colors hover:text-white"
                    >
                      ×
                    </button>
                  </div>
                )}

                {/* cabecera de la ficha: se ve entera, se ve corta */}
                <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4">
                  <p className="font-mono text-[10px] tracking-[0.16em] whitespace-nowrap text-white/60 uppercase">
                    {formulario.ficha.titulo}
                  </p>
                  <p className="rounded-full border border-white/15 px-3 py-1 font-mono text-[9.5px] tracking-[0.14em] text-white/50 uppercase">
                    {formulario.ficha.duracion}
                  </p>
                </div>

                <form
                  noValidate
                  onSubmit={(evento) => {
                    evento.preventDefault();
                    void enviar();
                  }}
                >
                  <Bloque
                    numero={formulario.bloques.edificio.numero}
                    titulo={formulario.bloques.edificio.titulo}
                  >
                    <div>
                      <label htmlFor="campo-direccion" className={claseEtiqueta}>
                        {formulario.bloques.edificio.direccion.etiqueta}
                      </label>
                      <input
                        id="campo-direccion"
                        type="text"
                        autoComplete="street-address"
                        placeholder={formulario.bloques.edificio.direccion.ayuda}
                        className={claseCampo}
                        value={datos.direccion}
                        onChange={cambiar("direccion")}
                        aria-invalid={Boolean(errores.direccion)}
                        aria-describedby={errores.direccion ? "error-direccion" : undefined}
                      />
                      <MensajeError campo="direccion" errores={errores} />
                    </div>
                  </Bloque>

                  <Bloque
                    numero={formulario.bloques.persona.numero}
                    titulo={formulario.bloques.persona.titulo}
                  >
                    <div>
                      <label htmlFor="campo-nombre" className={claseEtiqueta}>
                        {formulario.bloques.persona.nombre.etiqueta}
                      </label>
                      <input
                        id="campo-nombre"
                        type="text"
                        autoComplete="name"
                        placeholder={formulario.bloques.persona.nombre.ayuda}
                        className={claseCampo}
                        value={datos.nombre}
                        onChange={cambiar("nombre")}
                        aria-invalid={Boolean(errores.nombre)}
                        aria-describedby={errores.nombre ? "error-nombre" : undefined}
                      />
                      <MensajeError campo="nombre" errores={errores} />
                    </div>
                    <div>
                      <p className={claseEtiqueta} id="etiqueta-rol">
                        {formulario.bloques.persona.rol.etiqueta}
                      </p>
                      <div
                        role="group"
                        aria-labelledby="etiqueta-rol"
                        className="flex flex-wrap gap-2"
                      >
                        {formulario.bloques.persona.rol.opciones.map((opcion) => {
                          const activa = datos.rol === opcion;
                          return (
                            <m.button
                              key={opcion}
                              type="button"
                              aria-pressed={activa}
                              whileTap={{ scale: 0.96 }}
                              onClick={() => alternarRol(opcion)}
                              className={`rounded-full border px-3.5 py-2 text-[13px] font-semibold transition-colors ${
                                activa
                                  ? "border-malla bg-malla text-tinta"
                                  : "border-white/20 bg-white/[.05] text-white/75 hover:border-malla/70 hover:text-white"
                              }`}
                            >
                              {opcion}
                            </m.button>
                          );
                        })}
                      </div>
                    </div>
                  </Bloque>

                  <Bloque
                    numero={formulario.bloques.respuesta.numero}
                    titulo={formulario.bloques.respuesta.titulo}
                    ultimo
                  >
                    <div>
                      <label htmlFor="campo-contacto" className={claseEtiqueta}>
                        {formulario.bloques.respuesta.contacto.etiqueta}
                      </label>
                      <input
                        id="campo-contacto"
                        type="text"
                        placeholder={formulario.bloques.respuesta.contacto.ayuda}
                        className={claseCampo}
                        value={datos.contacto}
                        onChange={cambiar("contacto")}
                        aria-invalid={Boolean(errores.contacto)}
                        aria-describedby={errores.contacto ? "error-contacto" : undefined}
                      />
                      <MensajeError campo="contacto" errores={errores} />
                    </div>
                  </Bloque>

                  {/* señuelo antispam: oculto para personas */}
                  <div className="hidden" aria-hidden="true">
                    <label htmlFor="campo-referencia">Referencia</label>
                    <input
                      id="campo-referencia"
                      type="text"
                      tabIndex={-1}
                      autoComplete="off"
                      value={senuelo}
                      onChange={(evento) => setSenuelo(evento.target.value)}
                    />
                  </div>

                  {/* consentimiento RGPD, registrado con fecha en el servidor */}
                  <div className="mt-1">
                    <label
                      htmlFor="campo-consentimiento"
                      className="flex cursor-pointer items-start gap-3 text-[13px] leading-relaxed text-white/75"
                    >
                      <input
                        id="campo-consentimiento"
                        type="checkbox"
                        checked={consentimiento}
                        onChange={(evento) => setConsentimiento(evento.target.checked)}
                        aria-invalid={Boolean(errores.consentimiento)}
                        aria-describedby={
                          errores.consentimiento ? "error-consentimiento" : undefined
                        }
                        className="mt-0.5 h-4 w-4 shrink-0 accent-malla"
                      />
                      <span>
                        {formulario.consentimiento.antes}{" "}
                        <a
                          href="/privacidad"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-semibold text-malla underline underline-offset-2"
                        >
                          {formulario.consentimiento.enlace}
                        </a>{" "}
                        {formulario.consentimiento.despues}
                      </span>
                    </label>
                    <MensajeError campo="consentimiento" errores={errores} />
                  </div>

                  {estado === "error" && (
                    <div role="alert" className="mt-4 rounded-xl border border-malla/50 bg-white/[.05] px-4 py-3">
                      <p className="text-[14px] font-semibold text-white">
                        {formulario.error.titulo}
                      </p>
                      <p className="mt-0.5 text-[13px] text-white/70">
                        {formulario.error.texto}{" "}
                        <a href={`mailto:${marca.email}`} className="font-semibold text-malla underline underline-offset-2">
                          {marca.email}
                        </a>
                      </p>
                    </div>
                  )}

                  <m.button
                    type="submit"
                    whileTap={{ scale: 0.98 }}
                    disabled={estado === "enviando"}
                    className="mt-6 w-full rounded-full bg-malla px-7 py-4 text-[15.5px] font-bold text-tinta transition-colors hover:bg-[#8fd4b0] disabled:opacity-60"
                  >
                    {estado === "enviando"
                      ? formulario.botones.enviando
                      : formulario.botones.enviar}
                  </m.button>
                  <p className="mt-4 font-mono text-[9.5px] leading-relaxed tracking-[0.08em] text-white/45">
                    {formulario.nota}
                  </p>
                </form>
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
