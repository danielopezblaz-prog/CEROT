import type { ArteServicio as Clave } from "@/content";

/**
 * Ilustraciones en estilo de plano para las cuatro tarjetas de servicio.
 * Línea fina de tinta, acentos en verde y trama de malla — hechas a mano.
 */

const TINTA = "#18211c";
const VERDE = "#25714f";
const MALLA = "#7ec9a3";
const GRIS = "#5b6862";

function Subvenciones() {
  return (
    <>
      {/* expediente */}
      <g stroke={TINTA} strokeOpacity="0.55" fill="none">
        <path d="M14 10 H52 L62 20 V74 H14 Z" />
        <path d="M52 10 V20 H62" />
        <line x1="22" y1="30" x2="54" y2="30" strokeOpacity="0.3" />
        <line x1="22" y1="40" x2="54" y2="40" strokeOpacity="0.3" />
        <line x1="22" y1="50" x2="44" y2="50" strokeOpacity="0.3" />
        <line x1="22" y1="60" x2="48" y2="60" strokeOpacity="0.3" />
      </g>
      {/* sello de concesión */}
      <g stroke={VERDE} fill="none">
        <circle cx="97" cy="34" r="17" strokeDasharray="3 3" strokeWidth="1.4" />
        <text
          x="97"
          y="39"
          textAnchor="middle"
          fontSize="14"
          fontFamily="ui-monospace, Menlo, monospace"
          fill={VERDE}
          stroke="none"
          fontWeight="bold"
        >
          €
        </text>
      </g>
      {/* ingreso confirmado */}
      <path d="M88 66 L94 72 L106 58" stroke={VERDE} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="66" y1="66" x2="84" y2="66" stroke={GRIS} strokeWidth="0.9" strokeDasharray="2 3" />
      <circle cx="66" cy="66" r="2" fill={VERDE} />
    </>
  );
}

function Presupuestos() {
  return (
    <>
      {/* comparativa partida a partida */}
      <g stroke={TINTA} strokeOpacity="0.55" fill="none">
        <rect x="10" y="12" width="70" height="62" />
        <line x1="10" y1="26" x2="80" y2="26" strokeOpacity="0.35" />
        <line x1="10" y1="42" x2="80" y2="42" strokeOpacity="0.35" />
        <line x1="10" y1="58" x2="80" y2="58" strokeOpacity="0.35" />
        <line x1="46" y1="12" x2="46" y2="74" strokeOpacity="0.35" />
      </g>
      <rect x="10.5" y="42.5" width="69" height="15" fill="rgba(126,201,163,.2)" />
      <path d="M14 50 L18 54 L26 46" stroke={VERDE} strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {/* barras de coste con cota */}
      <g>
        <rect x="94" y="34" width="10" height="40" fill="rgba(24,33,28,.14)" />
        <rect x="110" y="48" width="10" height="26" fill={MALLA} opacity="0.75" />
        <line x1="90" y1="74" x2="126" y2="74" stroke={TINTA} strokeOpacity="0.5" />
        <line x1="120" y1="30" x2="120" y2="42" stroke={GRIS} strokeWidth="0.9" />
        <line x1="94" y1="30" x2="120" y2="30" stroke={GRIS} strokeWidth="0.9" strokeDasharray="2 2" />
        <path d="M115 44 L120 48 L125 44" stroke={VERDE} strokeWidth="1.4" fill="none" />
      </g>
    </>
  );
}

function Junta() {
  return (
    <>
      {/* mesa de la junta */}
      <ellipse cx="66" cy="52" rx="38" ry="15" stroke={TINTA} strokeOpacity="0.55" fill="none" />
      {/* los números encima de la mesa */}
      <rect x="56" y="45" width="20" height="13" stroke={VERDE} fill="rgba(126,201,163,.18)" />
      <line x1="60" y1="50" x2="72" y2="50" stroke={VERDE} strokeWidth="0.9" />
      <line x1="60" y1="54" x2="68" y2="54" stroke={VERDE} strokeWidth="0.9" />
      {/* vecinos alrededor */}
      <g stroke={TINTA} strokeOpacity="0.55" fill="none">
        <circle cx="30" cy="30" r="6" />
        <circle cx="66" cy="22" r="6" />
        <circle cx="102" cy="30" r="6" />
        <circle cx="22" cy="62" r="6" />
        <circle cx="110" cy="62" r="6" />
      </g>
      {/* intervención clara */}
      <g stroke={GRIS} strokeWidth="0.9" fill="none">
        <line x1="66" y1="28" x2="66" y2="38" />
        <circle cx="66" cy="40" r="1.6" fill={VERDE} stroke="none" />
      </g>
    </>
  );
}

function Empresas() {
  return (
    <>
      {/* tres ofertas a concurso */}
      <g stroke={TINTA} strokeOpacity="0.5" fill="none">
        <rect x="10" y="24" width="30" height="42" />
        <line x1="16" y1="34" x2="34" y2="34" strokeOpacity="0.35" />
        <line x1="16" y1="42" x2="30" y2="42" strokeOpacity="0.35" />
        <rect x="92" y="24" width="30" height="42" />
        <line x1="98" y1="34" x2="116" y2="34" strokeOpacity="0.35" />
        <line x1="98" y1="42" x2="112" y2="42" strokeOpacity="0.35" />
      </g>
      <g stroke={VERDE} fill="none">
        <rect x="50" y="16" width="32" height="50" strokeWidth="1.4" fill="rgba(126,201,163,.12)" />
        <line x1="56" y1="27" x2="76" y2="27" strokeOpacity="0.7" />
        <line x1="56" y1="35" x2="72" y2="35" strokeOpacity="0.7" />
        <circle cx="66" cy="52" r="7" />
        <path d="M62.5 52 L65 54.5 L70 49" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      {/* cota de comparación */}
      <g stroke={GRIS} strokeWidth="0.9" fill="none">
        <path d="M10 74 V78 H122 V74" />
        <line x1="66" y1="78" x2="66" y2="82" />
      </g>
    </>
  );
}

const ARTES: Record<Clave, () => React.ReactNode> = {
  subvenciones: Subvenciones,
  presupuestos: Presupuestos,
  junta: Junta,
  empresas: Empresas,
};

export function ArteServicio({ clave }: { clave: Clave }) {
  const Arte = ARTES[clave];
  return (
    <svg viewBox="0 0 132 88" className="h-[72px] w-auto" aria-hidden="true">
      <Arte />
    </svg>
  );
}
