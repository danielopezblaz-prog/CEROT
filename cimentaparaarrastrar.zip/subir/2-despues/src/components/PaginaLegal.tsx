import Link from "next/link";
import { paginasLegales, pie } from "@/content";
import { Logotipo } from "./Compartidos";

type Datos = {
  titulo: string;
  actualizado: string;
  secciones: { titulo: string; parrafos: string[] }[];
};

export function PaginaLegal({ datos }: { datos: Datos }) {
  return (
    <>
      <nav aria-label="Principal" className="border-b border-linea bg-papel">
        <div className="mx-auto flex max-w-[820px] items-center justify-between gap-4 px-5 py-3 sm:px-8">
          <Link href="/" aria-label="Cimenta, ir a la página principal" className="rounded-md">
            <Logotipo />
          </Link>
          <Link
            href="/"
            className="rounded-md text-[13.5px] font-semibold text-verde transition-colors hover:text-verde-oscuro"
          >
            ← {paginasLegales.volver}
          </Link>
        </div>
      </nav>

      <main className="mx-auto max-w-[820px] px-5 py-14 sm:px-8">
        <p className="etiqueta-cota text-verde">{datos.actualizado}</p>
        <h1 className="mt-2 text-[clamp(28px,5vw,40px)] leading-[1.1] font-extrabold tracking-display">
          {datos.titulo}
        </h1>
        <div className="mt-8 grid gap-8">
          {datos.secciones.map((seccion) => (
            <section key={seccion.titulo}>
              <h2 className="text-[18px] font-bold tracking-display">
                {seccion.titulo}
              </h2>
              {seccion.parrafos.map((parrafo) => (
                <p key={parrafo} className="mt-2 max-w-[70ch] text-[15px] leading-relaxed text-gris">
                  {parrafo}
                </p>
              ))}
            </section>
          ))}
        </div>
      </main>

      <footer className="mx-auto max-w-[820px] px-5 pb-10 sm:px-8">
        <p className="border-t border-linea pt-5 font-mono text-[10px] tracking-[0.08em] text-gris">
          {pie.derechos}
        </p>
      </footer>
    </>
  );
}
