"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, m, useReducedMotion } from "framer-motion";
import { avisos } from "@/content";

const INTERVALO_MS = 5000;

/**
 * Barra superior de avisos: las ayudas vigentes y los planes, rotando.
 * Cada mensaje enlaza a su sección; se desplaza con el scroll (no fija).
 */
export function BarraAvisos() {
  const sinMovimiento = useReducedMotion();
  const [indice, setIndice] = useState(0);

  useEffect(() => {
    const temporizador = window.setInterval(
      () => setIndice((i) => (i + 1) % avisos.mensajes.length),
      INTERVALO_MS,
    );
    return () => window.clearInterval(temporizador);
  }, []);

  const aviso = avisos.mensajes[indice];

  return (
    <div className="trama-malla bg-tinta">
      <div className="mx-auto flex max-w-[1120px] items-center justify-center gap-3 overflow-hidden px-5 py-2 sm:px-8">
        <span className="etiqueta-cota hidden shrink-0 rounded-full border border-malla/40 px-2.5 py-1 text-[8.5px] text-malla sm:inline-block">
          {avisos.etiqueta}
        </span>
        <AnimatePresence mode="wait" initial={false}>
          <m.a
            key={indice}
            href={aviso.ancla}
            initial={sinMovimiento ? false : { opacity: 0, y: 9 }}
            animate={{ opacity: 1, y: 0 }}
            exit={sinMovimiento ? undefined : { opacity: 0, y: -9 }}
            transition={{ duration: 0.28, ease: "easeOut" }}
            className="line-clamp-2 text-center font-mono text-[9px] tracking-[0.08em] text-white/85 uppercase transition-colors hover:text-malla sm:line-clamp-none sm:truncate sm:text-left sm:text-[9.5px] sm:tracking-[0.12em]"
          >
            {aviso.texto}{" "}
            <span aria-hidden="true" className="text-malla">
              →
            </span>
          </m.a>
        </AnimatePresence>
      </div>
    </div>
  );
}
