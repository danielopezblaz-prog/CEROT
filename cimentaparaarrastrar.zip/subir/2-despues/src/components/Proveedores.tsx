"use client";

import { LazyMotion, MotionConfig, domAnimation } from "framer-motion";
import type { ReactNode } from "react";

/**
 * Configuración global de movimiento:
 * — LazyMotion con el paquete `domAnimation` (componentes `m.*`):
 *   runtime de animación más ligero para hidratar antes.
 * — springs suaves por defecto (rigidez 120, amortiguación 20).
 * — con `prefers-reduced-motion`, Framer desactiva las animaciones
 *   de transformación automáticamente; los componentes con piezas
 *   grandes (hero, simulador) tienen además su propia vía estática.
 */
export function Proveedores({ children }: { children: ReactNode }) {
  return (
    <LazyMotion features={domAnimation} strict>
      <MotionConfig
        reducedMotion="user"
        transition={{ type: "spring", stiffness: 120, damping: 20 }}
      >
        {children}
      </MotionConfig>
    </LazyMotion>
  );
}
