"use client";

import { transparencia } from "@/content";
import { Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";

export function Transparencia() {
  return (
    <section aria-label="Transparencia" className="mx-auto max-w-[1120px] px-5 pt-20 sm:px-8 md:pt-28">
      <div className="trama-malla rounded-3xl bg-lavado p-6 sm:p-10">
        <Reveal>
          <Cejilla>{transparencia.cejilla}</Cejilla>
          <h2 className="max-w-[22ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display">
            {transparencia.titulo}
          </h2>
          <p className="mt-4 max-w-[58ch] text-gris">{transparencia.intro}</p>
        </Reveal>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {transparencia.compromisos.map((compromiso, i) => (
            <Reveal key={compromiso.titulo} retraso={(i % 2) * 0.07}>
              <div className="h-full rounded-xl border border-linea border-l-[3px] border-l-verde bg-superficie px-5 py-4">
                <h3 className="text-[15.5px] font-bold">{compromiso.titulo}</h3>
                <p className="mt-1 text-[13.5px] leading-relaxed text-gris">
                  {compromiso.texto}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
