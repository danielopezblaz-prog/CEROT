"use client";

import { m, useReducedMotion } from "framer-motion";
import { servicios } from "@/content";
import { conNegritas } from "@/lib/texto";
import { Cejilla } from "./Compartidos";
import { Reveal } from "./Reveal";
import { ArteServicio } from "./ArteServicio";

export function Servicios() {
  const sinMovimiento = useReducedMotion();

  return (
    <section id="servicios" className="mx-auto max-w-[1120px] px-5 py-20 sm:px-8 md:py-28">
      <Reveal>
        <Cejilla>{servicios.cejilla}</Cejilla>
        <h2 className="max-w-[22ch] text-[clamp(26px,4.5vw,38px)] leading-[1.12] font-extrabold tracking-display">
          {servicios.titulo}
        </h2>
        <p className="mt-4 max-w-[56ch] text-gris">{conNegritas(servicios.intro)}</p>
      </Reveal>

      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {servicios.tarjetas.map((tarjeta, i) => (
          <Reveal
            key={tarjeta.numero}
            retraso={(i % 2) * 0.08}
            className={
              /* La última ocupa el ancho completo solo si el número de
                 tarjetas es impar; si no, dejaría un hueco en la rejilla. */
              servicios.tarjetas.length % 2 === 1 &&
              i === servicios.tarjetas.length - 1
                ? "md:col-span-2"
                : ""
            }
          >
            <m.article
              whileHover={sinMovimiento ? undefined : { y: -4 }}
              transition={{ type: "spring", stiffness: 260, damping: 22 }}
              className="group flex h-full flex-col rounded-3xl border border-linea bg-superficie p-6 transition-shadow duration-300 hover:shadow-[0_24px_60px_rgba(24,33,28,.10)] sm:p-7"
            >
              <div className="flex items-start justify-between gap-4">
                <span className="font-mono text-[11px] font-semibold tracking-[0.16em] text-verde">
                  {tarjeta.numero}
                </span>
                <ArteServicio clave={tarjeta.arte} />
              </div>
              <h3 className="mt-3 text-[19px] font-extrabold tracking-display">
                {tarjeta.titulo}
              </h3>
              <p className="mt-2.5 flex-1 text-[15px] leading-relaxed text-gris">
                {conNegritas(tarjeta.texto)}
              </p>
              <span className="etiqueta-cota mt-5 inline-block self-start rounded-full bg-malla-suave px-3 py-1.5 text-[9.5px] text-verde">
                {tarjeta.etiqueta}
              </span>
            </m.article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
