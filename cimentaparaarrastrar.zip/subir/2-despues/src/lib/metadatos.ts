import type { Metadata } from "next";
import { marca } from "@/content";
import type { Pagina } from "@/content-paginas";

/**
 * Metadatos de una página de aterrizaje. La canónica es lo importante:
 * sin ella, los parámetros UTM de las campañas generan URLs duplicadas
 * a ojos de Google y la página compite consigo misma.
 */
export function metadatosDe(pagina: Pagina): Metadata {
  const url = `${marca.dominio}${pagina.ruta}`;
  return {
    title: pagina.titulo,
    description: pagina.descripcion,
    alternates: { canonical: pagina.ruta },
    openGraph: {
      type: "article",
      locale: "es_ES",
      url,
      siteName: marca.nombre,
      title: pagina.titulo,
      description: pagina.descripcion,
      images: [
        {
          url: "/og.png",
          type: "image/png",
          width: 1200,
          height: 630,
          alt: `${marca.nombre} — ${marca.claim}`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: pagina.titulo,
      description: pagina.descripcion,
      images: ["/og.png"],
    },
    robots: { index: true, follow: true },
  };
}
