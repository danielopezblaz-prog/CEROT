import type { ReactNode } from "react";

/**
 * Convierte los fragmentos entre dobles asteriscos de content.ts
 * (**así**) en <strong> con color de tinta, para destacar dentro
 * de párrafos grises.
 */
export function conNegritas(texto: string): ReactNode[] {
  return texto.split("**").map((parte, indice) =>
    indice % 2 === 1 ? (
      <strong key={indice} className="font-semibold text-tinta">
        {parte}
      </strong>
    ) : (
      parte
    ),
  );
}

/** Igual que conNegritas, pero para fondos oscuros (texto en blanco). */
export function conNegritasClaras(texto: string): ReactNode[] {
  return texto.split("**").map((parte, indice) =>
    indice % 2 === 1 ? (
      <strong key={indice} className="font-semibold text-white">
        {parte}
      </strong>
    ) : (
      parte
    ),
  );
}

/** Quita las marcas de negrita para usos sin HTML (JSON-LD, atributos). */
export function sinMarcas(texto: string): string {
  return texto.split("**").join("");
}

/** Formatea un número en estilo español: 14.500 */
export function numeroES(valor: number): string {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(
    valor,
  );
}
