/**
 * Eventos de conversión hacia la analítica sin cookies configurada.
 *
 * Regla de oro: **medir nunca puede romper el formulario**. Si no hay
 * analítica instalada, si el script no ha cargado o si falla, esto es un
 * no-op silencioso y la solicitud sigue su camino.
 *
 * La medición seria de campañas no vive aquí, vive en el CRM: cada lead
 * guarda sus UTM y el panel los agrupa por campaña. Eso mide el expediente
 * firmado, no el clic, y no depende del consentimiento de nadie.
 */

type Propiedades = Record<string, string | number | boolean>;

declare global {
  interface Window {
    plausible?: {
      (evento: string, opciones?: { props?: Propiedades }): void;
      q?: unknown[];
    };
    umami?: { track: (evento: string, datos?: Propiedades) => void };
  }
}

export function evento(nombre: string, propiedades?: Propiedades): void {
  if (typeof window === "undefined") return;
  try {
    window.plausible?.(nombre, propiedades ? { props: propiedades } : undefined);
    window.umami?.track(nombre, propiedades);
  } catch {
    /* la medición es opcional; el formulario no */
  }
}

/** Nombres de evento, en un solo sitio para que no se escriban a mano. */
export const EVENTOS = {
  solicitudEnviada: "Solicitud enviada",
} as const;
