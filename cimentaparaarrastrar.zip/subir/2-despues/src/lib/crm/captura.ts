import { and, eq, isNull, or } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import { ESTADO_INICIAL } from "@/db/catalogo";
import { enviarAviso } from "./correo";

const ES_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const ES_TELEFONO = /^\+?[\d\s().-]{9,}$/;

export function limpiar(valor: unknown, maximo = 300): string {
  if (typeof valor !== "string") return "";
  return valor.replace(/\s+/g, " ").trim().slice(0, maximo);
}

/**
 * El formulario pide "email o teléfono" en un solo campo: aquí se
 * separa y normaliza para poder buscar duplicados con fiabilidad.
 */
export function normalizarContacto(bruto: string): {
  email: string | null;
  telefono: string | null;
} {
  const texto = limpiar(bruto, 160);
  if (ES_EMAIL.test(texto)) {
    return { email: texto.toLowerCase(), telefono: null };
  }
  if (ES_TELEFONO.test(texto)) {
    return { email: null, telefono: normalizarTelefono(texto) };
  }
  return { email: null, telefono: null };
}

export function normalizarTelefono(bruto: string): string {
  const digitos = bruto.replace(/[^\d+]/g, "");
  const sinPrefijo = digitos.startsWith("+34")
    ? digitos.slice(3)
    : digitos.startsWith("0034")
      ? digitos.slice(4)
      : digitos.startsWith("34") && digitos.length === 11
        ? digitos.slice(2)
        : digitos.replace(/^\+/, "");
  return sinPrefijo;
}

export type CargaLeadWeb = {
  nombre: string;
  rol?: string;
  direccion?: string;
  viviendas?: string;
  contacto: string;
  simulacion?: string;
  consentimiento?: boolean;
  origen?: {
    url?: string;
    referrer?: string;
    utmSource?: string;
    utmMedium?: string;
    utmCampaign?: string;
    utmTerm?: string;
    utmContent?: string;
  };
};

export type ResultadoCaptura =
  | { ok: true; leadId: number; duplicado: boolean }
  | { ok: false; error: string };

/**
 * Crea el lead que llega del formulario público: valida, normaliza,
 * marca posibles duplicados (sin fusionar ni borrar) y deja el alta
 * registrada en el historial. Lanza excepción solo si la base de
 * datos falla — la ruta pública captura ese caso y conserva los datos.
 */
export function crearLeadDesdeWeb(carga: CargaLeadWeb): ResultadoCaptura {
  const nombre = limpiar(carga.nombre, 160);
  const direccion = limpiar(carga.direccion, 240);
  const contactoOriginal = limpiar(carga.contacto, 160);

  if (!nombre || !contactoOriginal) {
    return { ok: false, error: "Faltan datos obligatorios de la solicitud" };
  }

  const { email, telefono } = normalizarContacto(contactoOriginal);
  if (!email && !telefono) {
    return { ok: false, error: "El contacto no parece un email ni un teléfono" };
  }

  const viviendasTexto = limpiar(carga.viviendas, 6);
  const viviendas =
    viviendasTexto && /^\d+$/.test(viviendasTexto) ? Number(viviendasTexto) : null;

  const db = bd();

  const condiciones = [];
  if (email) condiciones.push(eq(esquema.leads.email, email));
  if (telefono) condiciones.push(eq(esquema.leads.telefono, telefono));
  const existente = db
    .select({ id: esquema.leads.id })
    .from(esquema.leads)
    .where(and(isNull(esquema.leads.eliminadoEn), or(...condiciones)))
    .get();

  const origen = carga.origen ?? {};
  const lead = db
    .insert(esquema.leads)
    .values({
      nombre,
      rolContacto: limpiar(carga.rol, 80) || null,
      direccion: direccion || null,
      viviendas,
      email,
      telefono,
      contactoOriginal,
      simulacion: limpiar(carga.simulacion, 240) || null,
      consentimientoEn: carga.consentimiento ? new Date() : null,
      estado: ESTADO_INICIAL,
      fuente: "web",
      formularioOrigen: "pre-informe",
      urlOrigen: limpiar(origen.url, 300) || null,
      referrer: limpiar(origen.referrer, 300) || null,
      utmSource: limpiar(origen.utmSource, 120) || null,
      utmMedium: limpiar(origen.utmMedium, 120) || null,
      utmCampaign: limpiar(origen.utmCampaign, 120) || null,
      utmTerm: limpiar(origen.utmTerm, 120) || null,
      utmContent: limpiar(origen.utmContent, 120) || null,
      posibleDuplicado: Boolean(existente),
      duplicadoDe: existente?.id ?? null,
    })
    .returning()
    .get();

  db.insert(esquema.leadHistorial)
    .values({
      leadId: lead.id,
      usuarioId: null,
      tipo: "creacion",
      estadoNuevo: ESTADO_INICIAL,
      comentario: existente
        ? `Lead recibido desde la web · posible duplicado del lead #${existente.id}`
        : "Lead recibido desde el formulario de la web",
    })
    .run();

  return { ok: true, leadId: lead.id, duplicado: Boolean(existente) };
}

/** Aviso interno de nuevo lead (o de fallo de guardado). */
export async function avisarNuevoLead(carga: CargaLeadWeb, leadId: number | null) {
  const lineas = [
    leadId ? `Nuevo lead #${leadId}` : "⚠️ LEAD SIN GUARDAR (fallo de base de datos)",
    `Nombre: ${limpiar(carga.nombre, 160)}`,
    `Rol: ${limpiar(carga.rol, 80) || "—"}`,
    `Edificio: ${limpiar(carga.direccion, 240) || "—"}`,
    `Viviendas: ${limpiar(carga.viviendas, 6) || "—"}`,
    `Contacto: ${limpiar(carga.contacto, 160)}`,
    `Simulación: ${limpiar(carga.simulacion, 240) || "no usó el simulador"}`,
  ];
  await enviarAviso(
    leadId ? `Pre-informe: ${limpiar(carga.direccion, 120) || limpiar(carga.nombre, 80)}` : "URGENTE: lead sin guardar",
    lineas.join("\n"),
  );
}
