import bcrypt from "bcryptjs";
import { asc, eq } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import { esRolUsuario } from "@/db/catalogo";
import type { Usuario } from "@/db/esquema";

const ES_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function listarUsuarios() {
  return bd().select().from(esquema.usuarios).orderBy(asc(esquema.usuarios.nombre)).all();
}

function anotarActividad(quien: Usuario, accion: string, detalle: string) {
  bd().insert(esquema.actividad).values({ usuarioId: quien.id, accion, detalle }).run();
}

export function crearUsuario(
  admin: Usuario,
  datos: { nombre: string; email: string; contrasena: string; rol: string },
): { ok: boolean; error?: string } {
  const nombre = datos.nombre.trim().slice(0, 120);
  const email = datos.email.trim().toLowerCase();
  if (!nombre) return { ok: false, error: "El nombre es obligatorio" };
  if (!ES_EMAIL.test(email)) return { ok: false, error: "El email no es válido" };
  if (datos.contrasena.length < 10) {
    return { ok: false, error: "La contraseña necesita al menos 10 caracteres" };
  }
  if (!esRolUsuario(datos.rol)) return { ok: false, error: "Rol desconocido" };

  const existente = bd()
    .select({ id: esquema.usuarios.id })
    .from(esquema.usuarios)
    .where(eq(esquema.usuarios.email, email))
    .get();
  if (existente) return { ok: false, error: "Ya existe un usuario con ese email" };

  bd()
    .insert(esquema.usuarios)
    .values({ nombre, email, hashContrasena: bcrypt.hashSync(datos.contrasena, 12), rol: datos.rol })
    .run();
  anotarActividad(admin, "usuario_creado", `${nombre} <${email}> · ${datos.rol}`);
  return { ok: true };
}

export function actualizarUsuario(
  admin: Usuario,
  id: number,
  datos: { nombre?: string; rol?: string; activo?: boolean; contrasena?: string },
): { ok: boolean; error?: string } {
  const usuario = bd().select().from(esquema.usuarios).where(eq(esquema.usuarios.id, id)).get();
  if (!usuario) return { ok: false, error: "El usuario no existe" };

  /* el admin no puede dejarse a sí mismo sin acceso ni sin rol de admin */
  if (id === admin.id && (datos.activo === false || (datos.rol && datos.rol !== "admin"))) {
    return { ok: false, error: "No puedes quitarte el acceso ni el rol de administración" };
  }

  const cambios: Record<string, unknown> = { actualizadoEn: new Date() };
  if (datos.nombre?.trim()) cambios.nombre = datos.nombre.trim().slice(0, 120);
  if (datos.rol) {
    if (!esRolUsuario(datos.rol)) return { ok: false, error: "Rol desconocido" };
    cambios.rol = datos.rol;
  }
  if (typeof datos.activo === "boolean") cambios.activo = datos.activo;
  if (datos.contrasena) {
    if (datos.contrasena.length < 10) {
      return { ok: false, error: "La contraseña necesita al menos 10 caracteres" };
    }
    cambios.hashContrasena = bcrypt.hashSync(datos.contrasena, 12);
  }

  bd().update(esquema.usuarios).set(cambios).where(eq(esquema.usuarios.id, id)).run();
  anotarActividad(
    admin,
    "usuario_actualizado",
    `#${id} ${usuario.email}${typeof datos.activo === "boolean" ? (datos.activo ? " · activado" : " · desactivado") : ""}`,
  );
  return { ok: true };
}

export function cambiarMiContrasena(
  usuario: Usuario,
  actual: string,
  nueva: string,
): { ok: boolean; error?: string } {
  if (!bcrypt.compareSync(actual, usuario.hashContrasena)) {
    return { ok: false, error: "La contraseña actual no es correcta" };
  }
  if (nueva.length < 10) {
    return { ok: false, error: "La nueva contraseña necesita al menos 10 caracteres" };
  }
  bd()
    .update(esquema.usuarios)
    .set({ hashContrasena: bcrypt.hashSync(nueva, 12), actualizadoEn: new Date() })
    .where(eq(esquema.usuarios.id, usuario.id))
    .run();
  return { ok: true };
}

export function actualizarMiNombre(usuario: Usuario, nombre: string) {
  const limpio = nombre.trim().slice(0, 120);
  if (!limpio) return { ok: false as const, error: "El nombre no puede quedar vacío" };
  bd()
    .update(esquema.usuarios)
    .set({ nombre: limpio, actualizadoEn: new Date() })
    .where(eq(esquema.usuarios.id, usuario.id))
    .run();
  return { ok: true as const };
}
