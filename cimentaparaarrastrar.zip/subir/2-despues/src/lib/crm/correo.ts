/**
 * Avisos por email vía Resend (API HTTP, sin dependencia extra).
 * Sin RESEND_API_KEY configurada, el aviso se escribe como log
 * estructurado: nada se envía y nada se pierde.
 */

export async function enviarAviso(asunto: string, texto: string): Promise<void> {
  const clave = process.env.RESEND_API_KEY;
  const destinatario = process.env.CRM_EMAIL_AVISOS;
  const remitente = process.env.CRM_EMAIL_REMITENTE ?? "CRM Cimenta <onboarding@resend.dev>";

  if (!clave || !destinatario) {
    console.log(
      JSON.stringify({
        nivel: "aviso",
        origen: "crm-correo",
        mensaje: "RESEND_API_KEY o CRM_EMAIL_AVISOS sin configurar: aviso solo en log",
        asunto,
        texto,
      }),
    );
    return;
  }

  try {
    const respuesta = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${clave}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from: remitente, to: [destinatario], subject: asunto, text: texto }),
    });
    if (!respuesta.ok) {
      console.error(
        JSON.stringify({
          nivel: "error",
          origen: "crm-correo",
          mensaje: `Resend respondió ${respuesta.status}`,
          asunto,
        }),
      );
    }
  } catch (error) {
    console.error(
      JSON.stringify({
        nivel: "error",
        origen: "crm-correo",
        mensaje: "Fallo de red enviando el aviso",
        asunto,
        detalle: String(error),
      }),
    );
  }
}
