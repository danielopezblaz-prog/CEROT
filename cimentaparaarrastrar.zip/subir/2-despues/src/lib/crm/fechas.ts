const FORMATO_FECHA = new Intl.DateTimeFormat("es-ES", {
  day: "2-digit",
  month: "short",
  year: "numeric",
});
const FORMATO_CORTO = new Intl.DateTimeFormat("es-ES", { day: "2-digit", month: "short" });
const FORMATO_HORA = new Intl.DateTimeFormat("es-ES", { hour: "2-digit", minute: "2-digit" });

export function fechaLarga(fecha: Date | null | undefined): string {
  return fecha ? FORMATO_FECHA.format(fecha) : "—";
}

export function fechaCorta(fecha: Date | null | undefined): string {
  return fecha ? FORMATO_CORTO.format(fecha) : "—";
}

export function fechaYHora(fecha: Date | null | undefined): string {
  return fecha ? `${FORMATO_FECHA.format(fecha)} · ${FORMATO_HORA.format(fecha)}` : "—";
}

export function estaVencida(fecha: Date | null | undefined): boolean {
  return Boolean(fecha && fecha.getTime() < Date.now());
}

export function esHoy(fecha: Date | null | undefined): boolean {
  if (!fecha) return false;
  const hoy = new Date();
  return (
    fecha.getFullYear() === hoy.getFullYear() &&
    fecha.getMonth() === hoy.getMonth() &&
    fecha.getDate() === hoy.getDate()
  );
}

export function euros(cantidad: number | null | undefined): string {
  if (cantidad === null || cantidad === undefined) return "—";
  return `${new Intl.NumberFormat("es-ES").format(cantidad)} €`;
}
