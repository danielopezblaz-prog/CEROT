import { beforeAll, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import type { Usuario } from "@/db/esquema";
import { cambiarEstadoTarea, crearTarea, listarTareas } from "./tareas";

let usuario: Usuario;
let leadId: number;

beforeAll(() => {
  const db = bd();
  usuario = db
    .insert(esquema.usuarios)
    .values({ nombre: "Tareas", email: "tareas@t.dev", hashContrasena: "x" })
    .returning()
    .get();
  leadId = db
    .insert(esquema.leads)
    .values({ nombre: "Lead con tareas" })
    .returning()
    .get().id;
});

describe("tareas y seguimientos", () => {
  it("crear una tarea adelanta el próximo seguimiento del lead", () => {
    const manana = new Date(Date.now() + 86400000);
    const resultado = crearTarea(leadId, usuario, {
      titulo: "Llamar mañana",
      tipo: "llamada",
      venceEn: manana,
    });
    expect(resultado.ok).toBe(true);
    const lead = bd().select().from(esquema.leads).where(eq(esquema.leads.id, leadId)).get();
    /* SQLite guarda los timestamps en segundos: tolerancia de 1 s */
    expect(
      Math.abs((lead?.proximoSeguimientoEn?.getTime() ?? 0) - manana.getTime()),
    ).toBeLessThan(1000);
  });

  it("los ámbitos hoy/vencidas/próximas separan por fecha", () => {
    crearTarea(leadId, usuario, {
      titulo: "Vencida",
      tipo: "seguimiento",
      venceEn: new Date(Date.now() - 2 * 86400000),
    });
    const hoy = new Date();
    hoy.setHours(12, 0, 0, 0);
    crearTarea(leadId, usuario, { titulo: "De hoy", tipo: "email", venceEn: hoy });

    expect(listarTareas("vencidas").some((t) => t.tarea.titulo === "Vencida")).toBe(true);
    expect(listarTareas("hoy").some((t) => t.tarea.titulo === "De hoy")).toBe(true);
    expect(listarTareas("proximas").some((t) => t.tarea.titulo === "Llamar mañana")).toBe(true);
  });

  it("completar una tarea de contacto escribe historial y último contacto", () => {
    const tarea = bd()
      .select()
      .from(esquema.tareas)
      .where(eq(esquema.tareas.titulo, "Llamar mañana"))
      .get()!;
    const resultado = cambiarEstadoTarea(tarea.id, "completada", usuario);
    expect(resultado.ok).toBe(true);

    const historial = bd()
      .select()
      .from(esquema.leadHistorial)
      .where(eq(esquema.leadHistorial.leadId, leadId))
      .all();
    expect(historial.some((h) => h.tipo === "tarea_completada")).toBe(true);

    const lead = bd().select().from(esquema.leads).where(eq(esquema.leads.id, leadId)).get();
    expect(lead?.ultimoContactoEn).toBeInstanceOf(Date);
  });
});
