import { describe, expect, it } from "vitest";
import { escaparCsv, generarCsv } from "./csv";
import type { Lead } from "@/db/esquema";

const base: Partial<Lead> = {
  id: 1,
  nombre: 'Comunidad "La Luz"; fase 2',
  email: "luz@ejemplo.es",
  estado: "junta",
  prioridad: "alta",
  fuente: "web",
  creadoEn: new Date("2026-07-01T10:00:00"),
};

describe("exportación CSV", () => {
  it("escapa comillas, separadores y saltos de línea", () => {
    expect(escaparCsv("simple")).toBe("simple");
    expect(escaparCsv('con "comillas"; y punto y coma')).toBe(
      '"con ""comillas""; y punto y coma"',
    );
    expect(escaparCsv("línea\nrota")).toBe('"línea\nrota"');
  });

  it("respeta la selección de columnas y traduce estado y fuente", () => {
    const csv = generarCsv([base as Lead & { comercial?: string | null }], [
      "nombre",
      "estado",
      "fuente",
    ]);
    const lineas = csv.trim().split("\r\n");
    expect(lineas[0]).toBe("Nombre;Estado;Fuente");
    expect(lineas[1]).toContain('"Comunidad ""La Luz""; fase 2"');
    expect(lineas[1]).toContain("En junta");
    expect(lineas[1]).toContain("Web — formulario");
  });

  it("empieza con BOM para que Excel abra los acentos", () => {
    const csv = generarCsv([], ["nombre"]);
    expect(csv.charCodeAt(0)).toBe(0xfeff);
  });
});
