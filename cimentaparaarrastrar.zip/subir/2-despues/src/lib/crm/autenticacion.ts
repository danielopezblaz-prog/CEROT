"use server";

import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { bd, esquema } from "@/db/indice";
import { esRolUsuario } from "@/db/catalogo";
import { intentar } from "./limitador";
import { borrarCookieSesion, crearCookieSesion } from "./sesion";

const MAX_INTENTOS = 5;
const VENTANA_MS = 15 * 60 * 1000;

export type ResultadoAcceso = { error: string } | undefined;

/**
 * Comprueba email + contraseña contra la base de datos.
 * Devuelve el usuario si las credenciales son válidas y está activo.
 */
export async function verificarCredenciales(email: string, contrasena: string) {
  const usuario = bd()
    .select()
    .from(esquema.usuarios)
    .where(eq(esquema.usuarios.email, email.trim().toLowerCase()))
    .get();
  /* comparación siempre, exista o no el usuario, para no filtrar tiempos */
  const hash = usuario?.hashContrasena ?? "$2a$10$invalidoinvalidoinvalidoinvalidoinvalidoinvalidoinvalid";
  const coincide = bcrypt.compareSync(contrasena, hash);
  if (!usuario || !coincide || !usuario.activo || !esRolUsuario(usuario.rol)) {
    return null;
  }
  return usuario;
}

export async function iniciarSesion(
  _anterior: ResultadoAcceso,
  formulario: FormData,
): Promise<ResultadoAcceso> {
  const email = String(formulario.get("email") ?? "").trim().toLowerCase();
  const contrasena = String(formulario.get("contrasena") ?? "");
  if (!email || !contrasena) {
    return { error: "Escribe tu email y tu contraseña." };
  }

  const cabeceras = await headers();
  const ip =
    cabeceras.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "desconocida";
  const limite = intentar(`acceso:${ip}:${email}`, MAX_INTENTOS, VENTANA_MS);
  if (!limite.permitido) {
    return {
      error: `Demasiados intentos. Vuelve a probar en ${Math.ceil(limite.reintentaEnS / 60)} min.`,
    };
  }

  const usuario = await verificarCredenciales(email, contrasena);
  if (!usuario) {
    return { error: "Credenciales no válidas o usuario desactivado." };
  }

  await crearCookieSesion({
    id: usuario.id,
    rol: usuario.rol as "admin" | "comercial",
    nombre: usuario.nombre,
  });
  bd()
    .insert(esquema.actividad)
    .values({ usuarioId: usuario.id, accion: "acceso", detalle: `IP ${ip}` })
    .run();

  redirect("/crm");
}

export async function cerrarSesion() {
  await borrarCookieSesion();
  redirect("/crm/acceder");
}
