import { and, count, eq, gte, isNull, lt, lte, sql, sum } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import { ESTADOS_LEAD, FUENTES } from "@/db/catalogo";

export type ClaveRango = "hoy" | "7d" | "30d" | "mes" | "mes_anterior" | "anio" | "personalizado";

export type Rango = { clave: ClaveRango; inicio: Date; fin: Date };

export function resolverRango(
  parametros: Record<string, string | string[] | undefined>,
): Rango {
  const uno = (clave: string) =>
    typeof parametros[clave] === "string" ? (parametros[clave] as string) : "";
  const clave = (uno("rango") || "30d") as ClaveRango;
  const ahora = new Date();
  const inicioHoy = new Date(ahora);
  inicioHoy.setHours(0, 0, 0, 0);

  const dia = 86400000;
  switch (clave) {
    case "hoy":
      return { clave, inicio: inicioHoy, fin: ahora };
    case "7d":
      return { clave, inicio: new Date(inicioHoy.getTime() - 6 * dia), fin: ahora };
    case "mes": {
      const inicio = new Date(ahora.getFullYear(), ahora.getMonth(), 1);
      return { clave, inicio, fin: ahora };
    }
    case "mes_anterior": {
      const inicio = new Date(ahora.getFullYear(), ahora.getMonth() - 1, 1);
      const fin = new Date(ahora.getFullYear(), ahora.getMonth(), 1);
      return { clave, inicio, fin };
    }
    case "anio": {
      const inicio = new Date(ahora.getFullYear(), 0, 1);
      return { clave, inicio, fin: ahora };
    }
    case "personalizado": {
      const desde = new Date(`${uno("desde") || "1970-01-01"}T00:00:00`);
      const hasta = uno("hasta") ? new Date(`${uno("hasta")}T23:59:59`) : ahora;
      if (!Number.isNaN(desde.getTime()) && !Number.isNaN(hasta.getTime())) {
        return { clave, inicio: desde, fin: hasta };
      }
      return { clave: "30d", inicio: new Date(inicioHoy.getTime() - 29 * dia), fin: ahora };
    }
    default:
      return { clave: "30d", inicio: new Date(inicioHoy.getTime() - 29 * dia), fin: ahora };
  }
}

const vivos = () => isNull(esquema.leads.eliminadoEn);
const enRango = (rango: Rango) =>
  and(gte(esquema.leads.creadoEn, rango.inicio), lte(esquema.leads.creadoEn, rango.fin));

function contar(condicion: ReturnType<typeof and>) {
  return bd().select({ n: count() }).from(esquema.leads).where(condicion).get()?.n ?? 0;
}

export function kpis(rango: Rango) {
  const ahora = new Date();
  const inicioHoy = new Date(ahora);
  inicioHoy.setHours(0, 0, 0, 0);
  const inicioSemana = new Date(inicioHoy.getTime() - 6 * 86400000);
  const inicioMes = new Date(ahora.getFullYear(), ahora.getMonth(), 1);

  const abiertos = and(
    vivos(),
    sql`${esquema.leads.estado} not in ('ganado','perdido','no_valido')`,
  );

  const cerradosRango = contar(
    and(vivos(), enRango(rango), sql`${esquema.leads.estado} in ('ganado','perdido','no_valido')`),
  );
  const ganadosRango = contar(and(vivos(), enRango(rango), eq(esquema.leads.estado, "ganado")));

  return {
    hoy: contar(and(vivos(), gte(esquema.leads.creadoEn, inicioHoy))),
    semana: contar(and(vivos(), gte(esquema.leads.creadoEn, inicioSemana))),
    mes: contar(and(vivos(), gte(esquema.leads.creadoEn, inicioMes))),
    sinContactar: contar(
      and(vivos(), eq(esquema.leads.estado, "nuevo"), isNull(esquema.leads.ultimoContactoEn)),
    ),
    sinAsignar: contar(and(abiertos, isNull(esquema.leads.comercialId))),
    seguimientosVencidos: contar(
      and(abiertos, lt(esquema.leads.proximoSeguimientoEn, ahora)),
    ),
    nuevosRango: contar(and(vivos(), enRango(rango))),
    ganadosRango,
    perdidosRango: cerradosRango - ganadosRango,
    conversionRango: cerradosRango > 0 ? Math.round((ganadosRango / cerradosRango) * 100) : null,
    valorPipeline:
      Number(
        bd()
          .select({ suma: sum(esquema.leads.valorEstimado) })
          .from(esquema.leads)
          .where(abiertos)
          .get()?.suma ?? 0,
      ) || 0,
  };
}

/** Leads por día dentro del rango (huecos rellenados a cero). */
export function seriePorDia(rango: Rango): { dia: Date; total: number }[] {
  const filas = bd()
    .select({
      dia: sql<string>`strftime('%Y-%m-%d', ${esquema.leads.creadoEn}, 'unixepoch')`,
      total: count(),
    })
    .from(esquema.leads)
    .where(and(vivos(), enRango(rango)))
    .groupBy(sql`strftime('%Y-%m-%d', ${esquema.leads.creadoEn}, 'unixepoch')`)
    .all();

  const mapa = new Map(filas.map((fila) => [fila.dia, fila.total]));
  const serie: { dia: Date; total: number }[] = [];
  const cursor = new Date(rango.inicio);
  cursor.setHours(12, 0, 0, 0);
  const tope = 370;
  while (cursor <= rango.fin && serie.length < tope) {
    const clave = cursor.toISOString().slice(0, 10);
    serie.push({ dia: new Date(cursor), total: mapa.get(clave) ?? 0 });
    cursor.setDate(cursor.getDate() + 1);
  }
  return serie;
}

export function porEstado(rango: Rango) {
  const filas = bd()
    .select({ estado: esquema.leads.estado, total: count() })
    .from(esquema.leads)
    .where(and(vivos(), enRango(rango)))
    .groupBy(esquema.leads.estado)
    .all();
  const mapa = new Map(filas.map((fila) => [fila.estado, fila.total]));
  return ESTADOS_LEAD.map((estado) => ({
    clave: estado.clave,
    nombre: estado.nombre,
    color: estado.color,
    total: mapa.get(estado.clave) ?? 0,
  }));
}

export function porFuente(rango: Rango) {
  const filas = bd()
    .select({ fuente: esquema.leads.fuente, total: count() })
    .from(esquema.leads)
    .where(and(vivos(), enRango(rango)))
    .groupBy(esquema.leads.fuente)
    .all();
  return filas
    .map((fila) => ({
      nombre: FUENTES.find((fuente) => fuente.clave === fila.fuente)?.nombre ?? fila.fuente,
      total: fila.total,
    }))
    .sort((a, b) => b.total - a.total);
}

/**
 * Atribución de campañas desde los UTM que guarda cada lead.
 *
 * Es la medición que de verdad importa y la que no necesita ni un píxel
 * en el navegador: cruzando el gasto de cada campaña con esta tabla se
 * sabe cuánto ha costado cada mandato firmado. No mide clics — mide
 * expedientes, que es lo único que factura.
 */
export function porCampana(rango: Rango) {
  const fuente = sql<string>`coalesce(nullif(trim(${esquema.leads.utmSource}), ''), '(directo o sin etiquetar)')`;
  const campana = sql<string>`coalesce(nullif(trim(${esquema.leads.utmCampaign}), ''), '—')`;

  const filas = bd()
    .select({
      fuente,
      campana,
      medio: sql<string>`coalesce(nullif(trim(${esquema.leads.utmMedium}), ''), '—')`,
      total: count(),
      ganados: sql<number>`sum(case when ${esquema.leads.estado} = 'ganado' then 1 else 0 end)`,
      cerrados: sql<number>`sum(case when ${esquema.leads.estado} in ('ganado','perdido','no_valido') then 1 else 0 end)`,
    })
    .from(esquema.leads)
    .where(and(vivos(), enRango(rango)))
    .groupBy(fuente, campana)
    .all();

  return filas
    .map((fila) => {
      const ganados = Number(fila.ganados ?? 0);
      const cerrados = Number(fila.cerrados ?? 0);
      return {
        fuente: fila.fuente,
        campana: fila.campana,
        medio: fila.medio,
        total: fila.total,
        ganados,
        /* Sobre cerrados, no sobre el total: los abiertos aún no han votado. */
        conversion: cerrados > 0 ? Math.round((ganados / cerrados) * 100) : null,
      };
    })
    .sort((a, b) => b.ganados - a.ganados || b.total - a.total);
}

export function conversionPorComercial(rango: Rango) {
  const filas = bd()
    .select({
      nombre: esquema.usuarios.nombre,
      total: count(),
      ganados: sql<number>`sum(case when ${esquema.leads.estado} = 'ganado' then 1 else 0 end)`,
    })
    .from(esquema.leads)
    .innerJoin(esquema.usuarios, eq(esquema.leads.comercialId, esquema.usuarios.id))
    .where(and(vivos(), enRango(rango)))
    .groupBy(esquema.usuarios.nombre)
    .all();
  return filas
    .map((fila) => ({
      nombre: fila.nombre,
      total: fila.total,
      ganados: Number(fila.ganados ?? 0),
      pct: fila.total > 0 ? Math.round((Number(fila.ganados ?? 0) / fila.total) * 100) : 0,
    }))
    .sort((a, b) => b.pct - a.pct);
}
