import { beforeAll, describe, expect, it } from "vitest";
import bcrypt from "bcryptjs";
import { bd, esquema } from "@/db/indice";
import { firmarSesion, verificarSesion } from "./token";
import { verificarCredenciales } from "./autenticacion";
import { intentar, reiniciarLimitador } from "./limitador";

describe("token de sesión", () => {
  it("firma y verifica una sesión válida", async () => {
    const token = await firmarSesion({ id: 7, rol: "admin", nombre: "Ana" });
    const sesion = await verificarSesion(token);
    expect(sesion).toEqual({ id: 7, rol: "admin", nombre: "Ana" });
  });

  it("rechaza tokens manipulados o basura", async () => {
    const token = await firmarSesion({ id: 7, rol: "admin", nombre: "Ana" });
    expect(await verificarSesion(token.slice(0, -3) + "aaa")).toBeNull();
    expect(await verificarSesion("no-es-un-token")).toBeNull();
  });
});

describe("credenciales", () => {
  beforeAll(() => {
    bd()
      .insert(esquema.usuarios)
      .values([
        {
          nombre: "Activa",
          email: "activa@cimenta.dev",
          hashContrasena: bcrypt.hashSync("contrasena-larga", 10),
          rol: "comercial",
        },
        {
          nombre: "Baja",
          email: "baja@cimenta.dev",
          hashContrasena: bcrypt.hashSync("contrasena-larga", 10),
          rol: "comercial",
          activo: false,
        },
      ])
      .run();
  });

  it("acepta usuario activo con contraseña correcta", async () => {
    const usuario = await verificarCredenciales("Activa@cimenta.dev ", "contrasena-larga");
    expect(usuario?.email).toBe("activa@cimenta.dev");
  });

  it("rechaza contraseña incorrecta y usuarios desactivados", async () => {
    expect(await verificarCredenciales("activa@cimenta.dev", "otra")).toBeNull();
    expect(await verificarCredenciales("baja@cimenta.dev", "contrasena-larga")).toBeNull();
    expect(await verificarCredenciales("nadie@cimenta.dev", "contrasena-larga")).toBeNull();
  });
});

describe("limitador", () => {
  it("corta tras el máximo de intentos y se recupera al vaciar", () => {
    reiniciarLimitador();
    for (let intento = 0; intento < 5; intento += 1) {
      expect(intentar("prueba", 5, 60_000).permitido).toBe(true);
    }
    const bloqueado = intentar("prueba", 5, 60_000);
    expect(bloqueado.permitido).toBe(false);
    expect(bloqueado.reintentaEnS).toBeGreaterThan(0);
    reiniciarLimitador();
    expect(intentar("prueba", 5, 60_000).permitido).toBe(true);
  });
});
