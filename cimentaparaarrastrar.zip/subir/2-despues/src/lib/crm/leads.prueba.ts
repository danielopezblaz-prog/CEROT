import { beforeAll, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import type { Usuario } from "@/db/esquema";
import {
  asignarComercial,
  cambiarEstadoLead,
  eliminarLead,
  listarLeads,
} from "./leads";

let admin: Usuario;
let comercial: Usuario;

beforeAll(() => {
  const db = bd();
  admin = db
    .insert(esquema.usuarios)
    .values({ nombre: "Admin", email: "a@t.dev", hashContrasena: "x", rol: "admin" })
    .returning()
    .get();
  comercial = db
    .insert(esquema.usuarios)
    .values({ nombre: "Comer", email: "c@t.dev", hashContrasena: "x", rol: "comercial" })
    .returning()
    .get();

  db.insert(esquema.leads)
    .values([
      { nombre: "Ana Alcalá", direccion: "C/ Alcalá 1", email: "ana@t.dev", estado: "nuevo", comercialId: comercial.id },
      { nombre: "Berta Bravo", telefono: "611111111", estado: "contactado", comercialId: admin.id },
      {
        nombre: "Carlos Cadí",
        estado: "visita",
        comercialId: null,
        proximoSeguimientoEn: new Date(Date.now() - 3 * 86400000),
      },
      { nombre: "Diana Delicias", estado: "ganado", comercialId: comercial.id },
    ])
    .run();
});

describe("listado con filtros en servidor", () => {
  it("busca por nombre y por email", () => {
    expect(listarLeads({ q: "alcalá" }, admin).total).toBe(1);
    expect(listarLeads({ q: "ana@t.dev" }, admin).total).toBe(1);
    expect(listarLeads({ q: "nadie" }, admin).total).toBe(0);
  });

  it("filtra por estado, por comercial y por especiales", () => {
    expect(listarLeads({ estado: "contactado" }, admin).total).toBe(1);
    expect(listarLeads({ comercial: String(comercial.id) }, admin).total).toBe(2);
    expect(listarLeads({ especial: "mios" }, comercial).total).toBe(2);
    expect(listarLeads({ especial: "sin_asignar" }, admin).total).toBe(1);
    expect(listarLeads({ especial: "seguimiento_vencido" }, admin).total).toBe(1);
  });

  it("pagina y ordena en el servidor", () => {
    const resultado = listarLeads({ orden: "nombre" }, admin);
    expect(resultado.filas[0].lead.nombre.startsWith("Ana")).toBe(true);
    expect(resultado.pagina).toBe(1);
  });
});

describe("acciones sobre el lead", () => {
  it("el cambio de estado queda en el historial con estados anterior y nuevo", () => {
    const lead = bd()
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.nombre, "Ana Alcalá"))
      .get()!;
    const resultado = cambiarEstadoLead(lead.id, "contactado", comercial);
    expect(resultado.ok).toBe(true);

    const historial = bd()
      .select()
      .from(esquema.leadHistorial)
      .where(eq(esquema.leadHistorial.leadId, lead.id))
      .all();
    const cambio = historial.find((h) => h.tipo === "estado");
    expect(cambio?.estadoAnterior).toBe("nuevo");
    expect(cambio?.estadoNuevo).toBe("contactado");
    expect(cambio?.usuarioId).toBe(comercial.id);
  });

  it("perder exige quedarse con el motivo", () => {
    const lead = bd()
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.nombre, "Berta Bravo"))
      .get()!;
    cambiarEstadoLead(lead.id, "perdido", admin, { motivoPerdida: "Eligieron otra vía" });
    const actualizado = bd()
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.id, lead.id))
      .get();
    expect(actualizado?.motivoPerdida).toBe("Eligieron otra vía");
  });

  it("asignar comercial registra el relevo y valida usuarios", () => {
    const lead = bd()
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.nombre, "Carlos Cadí"))
      .get()!;
    expect(asignarComercial(lead.id, comercial.id, admin).ok).toBe(true);
    expect(asignarComercial(lead.id, 9999, admin).ok).toBe(false);
  });

  it("eliminar es lógico y saca el lead del listado", () => {
    const lead = bd()
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.nombre, "Diana Delicias"))
      .get()!;
    const antes = listarLeads({}, admin).total;
    eliminarLead(lead.id, admin);
    expect(listarLeads({}, admin).total).toBe(antes - 1);
    const crudo = bd().select().from(esquema.leads).where(eq(esquema.leads.id, lead.id)).get();
    expect(crudo?.eliminadoEn).toBeInstanceOf(Date);
  });
});
