import { desc, eq } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";

export type EventoCronologia = {
  id: string;
  tipo: string;
  fecha: Date;
  usuario: string | null;
  estadoAnterior?: string | null;
  estadoNuevo?: string | null;
  texto: string | null;
};

/** Cronología completa del lead: alta, estados, relevos, notas y tareas. */
export function cronologiaDeLead(leadId: number): EventoCronologia[] {
  const db = bd();

  const historial = db
    .select({ fila: esquema.leadHistorial, usuario: esquema.usuarios.nombre })
    .from(esquema.leadHistorial)
    .leftJoin(esquema.usuarios, eq(esquema.leadHistorial.usuarioId, esquema.usuarios.id))
    .where(eq(esquema.leadHistorial.leadId, leadId))
    .orderBy(desc(esquema.leadHistorial.creadoEn))
    .all();

  const notas = db
    .select({ fila: esquema.leadNotas, usuario: esquema.usuarios.nombre })
    .from(esquema.leadNotas)
    .leftJoin(esquema.usuarios, eq(esquema.leadNotas.usuarioId, esquema.usuarios.id))
    .where(eq(esquema.leadNotas.leadId, leadId))
    .all();

  const eventos: EventoCronologia[] = [];

  for (const { fila, usuario } of historial) {
    if (fila.tipo === "nota") continue; /* la nota completa entra por su tabla */
    eventos.push({
      id: `h-${fila.id}`,
      tipo: fila.tipo,
      fecha: fila.creadoEn,
      usuario: usuario ?? null,
      estadoAnterior: fila.estadoAnterior,
      estadoNuevo: fila.estadoNuevo,
      texto: fila.comentario,
    });
  }
  for (const { fila, usuario } of notas) {
    eventos.push({
      id: `n-${fila.id}`,
      tipo: "nota",
      fecha: fila.creadoEn,
      usuario: usuario ?? null,
      texto: fila.texto,
    });
  }

  return eventos.sort((a, b) => b.fecha.getTime() - a.fecha.getTime());
}
