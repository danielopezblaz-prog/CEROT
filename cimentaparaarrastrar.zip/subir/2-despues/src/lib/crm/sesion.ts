import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import type { Usuario } from "@/db/esquema";
import {
  COOKIE_SESION,
  DURACION_SESION_S,
  firmarSesion,
  verificarSesion,
  type SesionCrm,
} from "./token";

export { COOKIE_SESION, verificarSesion, type SesionCrm };

export async function crearCookieSesion(sesion: SesionCrm) {
  const almacen = await cookies();
  almacen.set(COOKIE_SESION, await firmarSesion(sesion), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: DURACION_SESION_S,
  });
}

export async function borrarCookieSesion() {
  const almacen = await cookies();
  almacen.set(COOKIE_SESION, "", { httpOnly: true, path: "/", maxAge: 0 });
}

export async function leerSesion(): Promise<SesionCrm | null> {
  const almacen = await cookies();
  const token = almacen.get(COOKIE_SESION)?.value;
  if (!token) return null;
  return verificarSesion(token);
}

/**
 * Usuario autenticado y ACTIVO, verificado contra la base de datos.
 * La cookie solo abre la puerta: la autoridad definitiva es esta consulta.
 */
export async function usuarioActual(): Promise<Usuario | null> {
  const sesion = await leerSesion();
  if (!sesion) return null;
  const usuario = bd()
    .select()
    .from(esquema.usuarios)
    .where(eq(esquema.usuarios.id, sesion.id))
    .get();
  if (!usuario || !usuario.activo) return null;
  return usuario;
}

export async function exigirUsuario(): Promise<Usuario> {
  const usuario = await usuarioActual();
  if (!usuario) redirect("/crm/acceder");
  return usuario;
}

export async function exigirAdmin(): Promise<Usuario> {
  const usuario = await exigirUsuario();
  if (usuario.rol !== "admin") redirect("/crm");
  return usuario;
}
