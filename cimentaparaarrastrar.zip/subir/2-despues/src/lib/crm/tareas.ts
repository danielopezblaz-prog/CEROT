import { and, asc, eq, gte, isNull, lt, or } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import {
  esEstadoTarea,
  esTipoTarea,
  TIPOS_TAREA_CONTACTO,
  type ClaveEstadoTarea,
  type ClaveTipoTarea,
} from "@/db/catalogo";
import type { Usuario } from "@/db/esquema";

export function crearTarea(
  leadId: number,
  creador: Usuario,
  datos: { titulo: string; tipo: string; venceEn: Date; responsableId?: number },
): { ok: boolean; error?: string } {
  const titulo = datos.titulo.trim().slice(0, 200);
  if (!titulo) return { ok: false, error: "La tarea necesita un título" };
  if (!esTipoTarea(datos.tipo)) return { ok: false, error: "Tipo de tarea desconocido" };
  if (Number.isNaN(datos.venceEn.getTime())) return { ok: false, error: "Fecha no válida" };

  const db = bd();
  const responsableId = datos.responsableId ?? creador.id;
  db.insert(esquema.tareas)
    .values({ leadId, usuarioId: responsableId, titulo, tipo: datos.tipo, venceEn: datos.venceEn })
    .run();
  db.insert(esquema.leadHistorial)
    .values({
      leadId,
      usuarioId: creador.id,
      tipo: "tarea_creada",
      comentario: `${titulo} · vence ${datos.venceEn.toLocaleDateString("es-ES")}`,
    })
    .run();
  /* la próxima tarea pendiente marca el próximo seguimiento del lead */
  const lead = db.select().from(esquema.leads).where(eq(esquema.leads.id, leadId)).get();
  if (lead && (!lead.proximoSeguimientoEn || datos.venceEn < lead.proximoSeguimientoEn)) {
    db.update(esquema.leads)
      .set({ proximoSeguimientoEn: datos.venceEn, actualizadoEn: new Date() })
      .where(eq(esquema.leads.id, leadId))
      .run();
  }
  return { ok: true };
}

export function cambiarEstadoTarea(
  tareaId: number,
  estado: ClaveEstadoTarea,
  usuario: Usuario,
): { ok: boolean; error?: string } {
  if (!esEstadoTarea(estado)) return { ok: false, error: "Estado de tarea desconocido" };
  const db = bd();
  const tarea = db.select().from(esquema.tareas).where(eq(esquema.tareas.id, tareaId)).get();
  if (!tarea) return { ok: false, error: "La tarea no existe" };

  const completada = estado === "completada";
  db.update(esquema.tareas)
    .set({
      estado,
      completadaEn: completada ? new Date() : null,
      actualizadoEn: new Date(),
    })
    .where(eq(esquema.tareas.id, tareaId))
    .run();

  if (completada) {
    db.insert(esquema.leadHistorial)
      .values({
        leadId: tarea.leadId,
        usuarioId: usuario.id,
        tipo: "tarea_completada",
        comentario: tarea.titulo,
      })
      .run();
    /* una tarea de contacto real actualiza el último contacto del lead */
    if (TIPOS_TAREA_CONTACTO.includes(tarea.tipo as ClaveTipoTarea)) {
      db.update(esquema.leads)
        .set({ ultimoContactoEn: new Date(), actualizadoEn: new Date() })
        .where(eq(esquema.leads.id, tarea.leadId))
        .run();
    }
  }
  return { ok: true };
}

export type AmbitoTareas = "hoy" | "vencidas" | "proximas";

/** Tareas pendientes/en progreso por ámbito temporal, con su lead. */
export function listarTareas(ambito: AmbitoTareas, responsableId?: number) {
  const db = bd();
  const inicioHoy = new Date();
  inicioHoy.setHours(0, 0, 0, 0);
  const finHoy = new Date(inicioHoy);
  finHoy.setDate(finHoy.getDate() + 1);

  const abiertas = or(
    eq(esquema.tareas.estado, "pendiente"),
    eq(esquema.tareas.estado, "en_progreso"),
  );
  const porFecha =
    ambito === "hoy"
      ? and(gte(esquema.tareas.venceEn, inicioHoy), lt(esquema.tareas.venceEn, finHoy))
      : ambito === "vencidas"
        ? lt(esquema.tareas.venceEn, inicioHoy)
        : gte(esquema.tareas.venceEn, finHoy);

  const condiciones = [abiertas, porFecha, isNull(esquema.leads.eliminadoEn)];
  if (responsableId) condiciones.push(eq(esquema.tareas.usuarioId, responsableId));

  return db
    .select({
      tarea: esquema.tareas,
      lead: { id: esquema.leads.id, nombre: esquema.leads.nombre, estado: esquema.leads.estado },
      responsable: esquema.usuarios.nombre,
    })
    .from(esquema.tareas)
    .innerJoin(esquema.leads, eq(esquema.tareas.leadId, esquema.leads.id))
    .leftJoin(esquema.usuarios, eq(esquema.tareas.usuarioId, esquema.usuarios.id))
    .where(and(...condiciones))
    .orderBy(asc(esquema.tareas.venceEn))
    .all();
}

export function tareasDeLead(leadId: number) {
  return bd()
    .select({ tarea: esquema.tareas, responsable: esquema.usuarios.nombre })
    .from(esquema.tareas)
    .leftJoin(esquema.usuarios, eq(esquema.tareas.usuarioId, esquema.usuarios.id))
    .where(eq(esquema.tareas.leadId, leadId))
    .orderBy(asc(esquema.tareas.venceEn))
    .all();
}
