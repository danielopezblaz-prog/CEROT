import { beforeAll, describe, expect, it } from "vitest";
import { bd, esquema } from "@/db/indice";
import { porCampana, resolverRango } from "./metricas";

const rango = () => resolverRango({ rango: "30d" });
const buscar = (fuente: string, campana: string) =>
  porCampana(rango()).find(
    (fila) => fila.fuente === fuente && fila.campana === campana,
  );

beforeAll(() => {
  bd()
    .insert(esquema.leads)
    .values([
      /* Campaña que ha cerrado: 1 mandato, 1 perdido, 1 todavía abierto. */
      {
        nombre: "Ganado",
        estado: "ganado",
        utmSource: "google",
        utmMedium: "cpc",
        utmCampaign: "convocatoria-2026",
      },
      {
        nombre: "Perdido",
        estado: "perdido",
        utmSource: "google",
        utmMedium: "cpc",
        utmCampaign: "convocatoria-2026",
      },
      {
        nombre: "Abierto",
        estado: "visita",
        utmSource: "google",
        utmMedium: "cpc",
        utmCampaign: "convocatoria-2026",
      },
      /* Campaña sin ningún cierre aún. */
      {
        nombre: "Solo abierto",
        estado: "nuevo",
        utmSource: "meta",
        utmMedium: "social",
        utmCampaign: "fachada",
      },
      /* Tráfico sin etiquetar: null y cadena vacía deben agruparse juntos. */
      { nombre: "Sin utm nulo", estado: "nuevo" },
      { nombre: "Sin utm vacío", estado: "nuevo", utmSource: "", utmCampaign: "" },
      /* Un lead borrado no cuenta en ninguna métrica. */
      {
        nombre: "Borrado",
        estado: "ganado",
        utmSource: "google",
        utmCampaign: "convocatoria-2026",
        eliminadoEn: new Date(),
      },
    ])
    .run();
});

describe("atribución por campaña", () => {
  it("agrupa por origen y campaña sin contar los eliminados", () => {
    const fila = buscar("google", "convocatoria-2026");
    expect(fila?.total).toBe(3);
    expect(fila?.ganados).toBe(1);
    expect(fila?.medio).toBe("cpc");
  });

  it("calcula la conversión sobre los cerrados, no sobre el total", () => {
    /* 1 ganado y 1 perdido cerrados: 50 %. El abierto no cuenta todavía. */
    expect(buscar("google", "convocatoria-2026")?.conversion).toBe(50);
  });

  it("deja la conversión en blanco si aún no ha cerrado nada", () => {
    const fila = buscar("meta", "fachada");
    expect(fila?.total).toBe(1);
    expect(fila?.conversion).toBeNull();
  });

  it("junta el tráfico sin etiquetar aunque venga como nulo o vacío", () => {
    const fila = buscar("(directo o sin etiquetar)", "—");
    expect(fila?.total).toBe(2);
  });

  it("ordena poniendo delante las campañas que más mandatos firman", () => {
    const filas = porCampana(rango());
    expect(filas[0].fuente).toBe("google");
    expect(filas[0].ganados).toBe(1);
  });
});
