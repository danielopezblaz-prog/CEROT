import { SignJWT, jwtVerify } from "jose";
import { esRolUsuario, type ClaveRolUsuario } from "@/db/catalogo";

/**
 * Firma y verificación del token de sesión. Módulo apto para el edge
 * runtime del middleware: sin base de datos ni APIs de Node.
 */

export const COOKIE_SESION = "cimenta_sesion";
export const DURACION_SESION_S = 7 * 24 * 60 * 60;

export type SesionCrm = {
  id: number;
  rol: ClaveRolUsuario;
  nombre: string;
};

export function secretoSesion(): Uint8Array {
  const configurado = process.env.SESSION_SECRET;
  if (configurado && configurado.length >= 16) {
    return new TextEncoder().encode(configurado);
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error("SESSION_SECRET es obligatorio en producción (mínimo 16 caracteres).");
  }
  console.warn("⚠️  SESSION_SECRET sin definir: usando secreto de desarrollo.");
  return new TextEncoder().encode("cimenta-crm-secreto-solo-desarrollo");
}

export async function firmarSesion(sesion: SesionCrm): Promise<string> {
  return new SignJWT({ rol: sesion.rol, nombre: sesion.nombre })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(sesion.id))
    .setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + DURACION_SESION_S)
    .sign(secretoSesion());
}

export async function verificarSesion(token: string): Promise<SesionCrm | null> {
  try {
    const { payload } = await jwtVerify(token, secretoSesion());
    const id = Number(payload.sub);
    const rol = typeof payload.rol === "string" ? payload.rol : "";
    if (!Number.isInteger(id) || id <= 0 || !esRolUsuario(rol)) return null;
    return {
      id,
      rol,
      nombre: typeof payload.nombre === "string" ? payload.nombre : "",
    };
  } catch {
    return null;
  }
}
