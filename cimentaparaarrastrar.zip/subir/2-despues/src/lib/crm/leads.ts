import {
  and,
  asc,
  count,
  desc,
  eq,
  gte,
  isNull,
  like,
  lt,
  lte,
  or,
  sql,
  type SQL,
} from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import {
  esEstadoLead,
  esFuente,
  esPrioridad,
  estadoLead,
  type ClaveEstadoLead,
} from "@/db/catalogo";
import type { Usuario } from "@/db/esquema";

export const LEADS_POR_PAGINA = 25;

export type FiltrosLeads = {
  q?: string;
  estado?: string;
  comercial?: string;
  fuente?: string;
  prioridad?: string;
  desde?: string;
  hasta?: string;
  especial?: string;
  orden?: string;
  pagina?: number;
};

/** Convierte los searchParams crudos en filtros saneados. */
export function filtrosDesdeParametros(
  parametros: Record<string, string | string[] | undefined>,
): FiltrosLeads {
  const uno = (clave: string) => {
    const valor = parametros[clave];
    return typeof valor === "string" ? valor.trim() : undefined;
  };
  const pagina = Number(uno("pagina") ?? "1");
  return {
    q: uno("q")?.slice(0, 120),
    estado: uno("estado"),
    comercial: uno("comercial"),
    fuente: uno("fuente"),
    prioridad: uno("prioridad"),
    desde: uno("desde"),
    hasta: uno("hasta"),
    especial: uno("especial"),
    orden: uno("orden"),
    pagina: Number.isInteger(pagina) && pagina >= 1 ? pagina : 1,
  };
}

function condicionesDe(filtros: FiltrosLeads, usuario: Usuario): SQL[] {
  const condiciones: SQL[] = [isNull(esquema.leads.eliminadoEn)];

  if (filtros.q) {
    const patron = `%${filtros.q.replace(/[%_]/g, "")}%`;
    const busqueda = or(
      like(esquema.leads.nombre, patron),
      like(esquema.leads.empresa, patron),
      like(esquema.leads.email, patron),
      like(esquema.leads.telefono, patron),
      like(esquema.leads.direccion, patron),
    );
    if (busqueda) condiciones.push(busqueda);
  }
  if (filtros.estado && esEstadoLead(filtros.estado)) {
    condiciones.push(eq(esquema.leads.estado, filtros.estado));
  }
  if (filtros.prioridad && esPrioridad(filtros.prioridad)) {
    condiciones.push(eq(esquema.leads.prioridad, filtros.prioridad));
  }
  if (filtros.fuente && esFuente(filtros.fuente)) {
    condiciones.push(eq(esquema.leads.fuente, filtros.fuente));
  }
  if (filtros.comercial) {
    const id = Number(filtros.comercial);
    if (Number.isInteger(id) && id > 0) {
      condiciones.push(eq(esquema.leads.comercialId, id));
    }
  }
  if (filtros.desde) {
    const fecha = new Date(`${filtros.desde}T00:00:00`);
    if (!Number.isNaN(fecha.getTime())) condiciones.push(gte(esquema.leads.creadoEn, fecha));
  }
  if (filtros.hasta) {
    const fecha = new Date(`${filtros.hasta}T23:59:59`);
    if (!Number.isNaN(fecha.getTime())) condiciones.push(lte(esquema.leads.creadoEn, fecha));
  }
  if (filtros.especial === "mios") {
    condiciones.push(eq(esquema.leads.comercialId, usuario.id));
  }
  if (filtros.especial === "sin_contactar") {
    condiciones.push(isNull(esquema.leads.ultimoContactoEn));
    condiciones.push(eq(esquema.leads.estado, "nuevo"));
  }
  if (filtros.especial === "sin_asignar") {
    condiciones.push(isNull(esquema.leads.comercialId));
  }
  if (filtros.especial === "seguimiento_vencido") {
    condiciones.push(lt(esquema.leads.proximoSeguimientoEn, new Date()));
  }
  if (filtros.especial === "duplicados") {
    condiciones.push(eq(esquema.leads.posibleDuplicado, true));
  }
  return condiciones;
}

function ordenDe(filtros: FiltrosLeads) {
  switch (filtros.orden) {
    case "antiguos":
      return [asc(esquema.leads.creadoEn)];
    case "nombre":
      return [asc(esquema.leads.nombre)];
    case "valor":
      return [desc(sql`coalesce(${esquema.leads.valorEstimado}, 0)`)];
    case "seguimiento":
      return [
        asc(sql`${esquema.leads.proximoSeguimientoEn} is null`),
        asc(esquema.leads.proximoSeguimientoEn),
      ];
    default:
      return [desc(esquema.leads.creadoEn)];
  }
}

/** Listado paginado resuelto por completo en el servidor. */
export function listarLeads(filtros: FiltrosLeads, usuario: Usuario) {
  const db = bd();
  const condiciones = condicionesDe(filtros, usuario);
  const donde = and(...condiciones);

  const total = db
    .select({ n: count() })
    .from(esquema.leads)
    .where(donde)
    .get()?.n ?? 0;

  const paginas = Math.max(1, Math.ceil(total / LEADS_POR_PAGINA));
  const pagina = Math.min(filtros.pagina ?? 1, paginas);

  const filas = db
    .select({
      lead: esquema.leads,
      comercial: esquema.usuarios.nombre,
    })
    .from(esquema.leads)
    .leftJoin(esquema.usuarios, eq(esquema.leads.comercialId, esquema.usuarios.id))
    .where(donde)
    .orderBy(...ordenDe(filtros))
    .limit(LEADS_POR_PAGINA)
    .offset((pagina - 1) * LEADS_POR_PAGINA)
    .all();

  return { filas, total, paginas, pagina };
}

export function obtenerLead(id: number) {
  return bd()
    .select({ lead: esquema.leads, comercial: esquema.usuarios.nombre })
    .from(esquema.leads)
    .leftJoin(esquema.usuarios, eq(esquema.leads.comercialId, esquema.usuarios.id))
    .where(and(eq(esquema.leads.id, id), isNull(esquema.leads.eliminadoEn)))
    .get();
}

export function listarComerciales() {
  return bd()
    .select({
      id: esquema.usuarios.id,
      nombre: esquema.usuarios.nombre,
      rol: esquema.usuarios.rol,
    })
    .from(esquema.usuarios)
    .where(eq(esquema.usuarios.activo, true))
    .orderBy(asc(esquema.usuarios.nombre))
    .all();
}

function tocar(leadId: number) {
  bd()
    .update(esquema.leads)
    .set({ actualizadoEn: new Date() })
    .where(eq(esquema.leads.id, leadId))
    .run();
}

/** Cambia el estado y lo deja escrito en el historial. */
export function cambiarEstadoLead(
  leadId: number,
  estadoNuevo: ClaveEstadoLead,
  usuario: Usuario,
  opciones: { comentario?: string; motivoPerdida?: string } = {},
): { ok: boolean; error?: string } {
  const db = bd();
  const lead = db
    .select()
    .from(esquema.leads)
    .where(and(eq(esquema.leads.id, leadId), isNull(esquema.leads.eliminadoEn)))
    .get();
  if (!lead) return { ok: false, error: "El lead no existe" };
  if (!estadoLead(estadoNuevo)) return { ok: false, error: "Estado desconocido" };
  if (lead.estado === estadoNuevo) return { ok: true };

  const esPerdida = estadoNuevo === "perdido" || estadoNuevo === "no_valido";
  db.update(esquema.leads)
    .set({
      estado: estadoNuevo,
      motivoPerdida: esPerdida
        ? (opciones.motivoPerdida?.trim().slice(0, 300) ?? lead.motivoPerdida)
        : null,
      actualizadoEn: new Date(),
    })
    .where(eq(esquema.leads.id, leadId))
    .run();

  db.insert(esquema.leadHistorial)
    .values({
      leadId,
      usuarioId: usuario.id,
      tipo: "estado",
      estadoAnterior: lead.estado,
      estadoNuevo,
      comentario:
        opciones.comentario?.trim().slice(0, 300) ||
        (esPerdida ? opciones.motivoPerdida?.trim().slice(0, 300) : undefined) ||
        null,
    })
    .run();

  return { ok: true };
}

export function asignarComercial(
  leadId: number,
  comercialId: number | null,
  usuario: Usuario,
): { ok: boolean; error?: string } {
  const db = bd();
  const lead = db
    .select()
    .from(esquema.leads)
    .where(and(eq(esquema.leads.id, leadId), isNull(esquema.leads.eliminadoEn)))
    .get();
  if (!lead) return { ok: false, error: "El lead no existe" };
  if (lead.comercialId === comercialId) return { ok: true };

  let nombreNuevo = "sin asignar";
  if (comercialId !== null) {
    const comercial = db
      .select()
      .from(esquema.usuarios)
      .where(and(eq(esquema.usuarios.id, comercialId), eq(esquema.usuarios.activo, true)))
      .get();
    if (!comercial) return { ok: false, error: "Comercial no válido" };
    nombreNuevo = comercial.nombre;
  }

  db.update(esquema.leads)
    .set({ comercialId, actualizadoEn: new Date() })
    .where(eq(esquema.leads.id, leadId))
    .run();
  db.insert(esquema.leadHistorial)
    .values({
      leadId,
      usuarioId: usuario.id,
      tipo: "asignacion",
      comentario: `Responsable: ${nombreNuevo}`,
    })
    .run();
  return { ok: true };
}

/** Borrado lógico; la autorización de admin se exige en la acción. */
export function eliminarLead(leadId: number, usuario: Usuario) {
  bd()
    .update(esquema.leads)
    .set({ eliminadoEn: new Date() })
    .where(eq(esquema.leads.id, leadId))
    .run();
  bd()
    .insert(esquema.actividad)
    .values({ usuarioId: usuario.id, accion: "lead_eliminado", detalle: `Lead #${leadId}` })
    .run();
}

export function anotarLead(leadId: number, usuario: Usuario, texto: string) {
  const limpio = texto.trim().slice(0, 2000);
  if (!limpio) return { ok: false as const, error: "La nota está vacía" };
  bd().insert(esquema.leadNotas).values({ leadId, usuarioId: usuario.id, texto: limpio }).run();
  bd()
    .insert(esquema.leadHistorial)
    .values({ leadId, usuarioId: usuario.id, tipo: "nota", comentario: limpio.slice(0, 140) })
    .run();
  tocar(leadId);
  return { ok: true as const };
}

export function actualizarCampos(
  leadId: number,
  usuario: Usuario,
  cambios: Partial<{
    prioridad: string;
    valorEstimado: number | null;
    proximoSeguimientoEn: Date | null;
    empresa: string | null;
    ciudad: string | null;
    tipoObra: string | null;
    fechaJunta: Date | null;
    administradorFincas: string | null;
    planAyudas: string | null;
  }>,
) {
  const db = bd();
  const conjunto: Record<string, unknown> = { actualizadoEn: new Date() };
  if (cambios.prioridad && esPrioridad(cambios.prioridad)) conjunto.prioridad = cambios.prioridad;
  if ("valorEstimado" in cambios) conjunto.valorEstimado = cambios.valorEstimado;
  if ("proximoSeguimientoEn" in cambios) conjunto.proximoSeguimientoEn = cambios.proximoSeguimientoEn;
  if ("empresa" in cambios) conjunto.empresa = cambios.empresa;
  if ("ciudad" in cambios) conjunto.ciudad = cambios.ciudad;
  if ("tipoObra" in cambios) conjunto.tipoObra = cambios.tipoObra;
  if ("fechaJunta" in cambios) conjunto.fechaJunta = cambios.fechaJunta;
  if ("administradorFincas" in cambios) conjunto.administradorFincas = cambios.administradorFincas;
  if ("planAyudas" in cambios) conjunto.planAyudas = cambios.planAyudas;

  db.update(esquema.leads).set(conjunto).where(eq(esquema.leads.id, leadId)).run();
  db.insert(esquema.leadHistorial)
    .values({ leadId, usuarioId: usuario.id, tipo: "edicion", comentario: "Datos del lead actualizados" })
    .run();
}
