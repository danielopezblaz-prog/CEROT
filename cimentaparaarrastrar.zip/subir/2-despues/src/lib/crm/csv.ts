import { estadoLead, FUENTES } from "@/db/catalogo";
import { fechaYHora } from "./fechas";
import type { Lead } from "@/db/esquema";

export const COLUMNAS_CSV = [
  { clave: "id", nombre: "ID" },
  { clave: "nombre", nombre: "Nombre" },
  { clave: "rolContacto", nombre: "Rol" },
  { clave: "empresa", nombre: "Empresa" },
  { clave: "email", nombre: "Email" },
  { clave: "telefono", nombre: "Teléfono" },
  { clave: "direccion", nombre: "Dirección" },
  { clave: "viviendas", nombre: "Viviendas" },
  { clave: "estado", nombre: "Estado" },
  { clave: "prioridad", nombre: "Prioridad" },
  { clave: "valorEstimado", nombre: "Valor estimado" },
  { clave: "comercial", nombre: "Comercial" },
  { clave: "fuente", nombre: "Fuente" },
  /* Los tres UTM juntos: es lo que permite cruzar gasto de campaña
     con mandatos firmados en una hoja de cálculo. */
  { clave: "utmSource", nombre: "Origen (UTM)" },
  { clave: "utmMedium", nombre: "Medio (UTM)" },
  { clave: "utmCampaign", nombre: "Campaña" },
  { clave: "simulacion", nombre: "Simulación" },
  { clave: "motivoPerdida", nombre: "Motivo de pérdida" },
  { clave: "creadoEn", nombre: "Entrada" },
  { clave: "ultimoContactoEn", nombre: "Último contacto" },
  { clave: "proximoSeguimientoEn", nombre: "Próximo seguimiento" },
] as const;

export type ClaveColumnaCsv = (typeof COLUMNAS_CSV)[number]["clave"];

export function escaparCsv(valor: string): string {
  if (/[";\n\r]/.test(valor)) {
    return `"${valor.replace(/"/g, '""')}"`;
  }
  return valor;
}

function valorDe(
  lead: Lead & { comercial?: string | null },
  clave: ClaveColumnaCsv,
): string {
  switch (clave) {
    case "estado":
      return estadoLead(lead.estado)?.nombre ?? lead.estado;
    case "fuente":
      return FUENTES.find((fuente) => fuente.clave === lead.fuente)?.nombre ?? lead.fuente;
    case "comercial":
      return lead.comercial ?? "";
    case "creadoEn":
    case "ultimoContactoEn":
    case "proximoSeguimientoEn": {
      const fecha = lead[clave];
      return fecha ? fechaYHora(fecha) : "";
    }
    default: {
      const bruto = lead[clave as keyof Lead];
      return bruto === null || bruto === undefined ? "" : String(bruto);
    }
  }
}

/** CSV con separador ; (Excel es-ES) y BOM para que abra con acentos. */
export function generarCsv(
  filas: (Lead & { comercial?: string | null })[],
  columnas: ClaveColumnaCsv[],
): string {
  const elegidas = COLUMNAS_CSV.filter((columna) => columnas.includes(columna.clave));
  const cabecera = elegidas.map((columna) => escaparCsv(columna.nombre)).join(";");
  const cuerpo = filas
    .map((fila) => elegidas.map((columna) => escaparCsv(valorDe(fila, columna.clave))).join(";"))
    .join("\r\n");
  return `﻿${cabecera}\r\n${cuerpo}\r\n`;
}
