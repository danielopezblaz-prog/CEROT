/**
 * Limitador de peticiones en memoria (ventana deslizante). Suficiente
 * para el volumen del negocio; en despliegues con varias instancias
 * cada una aplica su propio límite (documentado en el README).
 */

type Registro = { marcas: number[] };

const cubos = new Map<string, Registro>();

export function intentar(
  clave: string,
  maximo: number,
  ventanaMs: number,
): { permitido: boolean; reintentaEnS: number } {
  const ahora = Date.now();
  const registro = cubos.get(clave) ?? { marcas: [] };
  registro.marcas = registro.marcas.filter((marca) => ahora - marca < ventanaMs);

  if (registro.marcas.length >= maximo) {
    const masAntigua = registro.marcas[0];
    return {
      permitido: false,
      reintentaEnS: Math.max(1, Math.ceil((ventanaMs - (ahora - masAntigua)) / 1000)),
    };
  }

  registro.marcas.push(ahora);
  cubos.set(clave, registro);

  /* limpieza perezosa para no crecer sin límite */
  if (cubos.size > 5000) {
    for (const [claveCubo, registroCubo] of cubos) {
      if (registroCubo.marcas.every((marca) => ahora - marca > ventanaMs)) {
        cubos.delete(claveCubo);
      }
    }
  }

  return { permitido: true, reintentaEnS: 0 };
}

/** Solo para pruebas: vacía el estado del limitador. */
export function reiniciarLimitador() {
  cubos.clear();
}
