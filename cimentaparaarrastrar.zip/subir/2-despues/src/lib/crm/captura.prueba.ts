import { beforeEach, describe, expect, it } from "vitest";
import { desc, eq } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import { crearLeadDesdeWeb, normalizarContacto, normalizarTelefono } from "./captura";
import { reiniciarLimitador } from "./limitador";
import { POST } from "@/app/api/lead/route";

function peticion(cuerpo: unknown, ip = "203.0.113.10") {
  return new Request("http://localhost/api/lead", {
    method: "POST",
    headers: { "content-type": "application/json", "x-forwarded-for": ip },
    body: JSON.stringify(cuerpo),
  });
}

const db = bd();
const contarLeads = () => db.select({ id: esquema.leads.id }).from(esquema.leads).all().length;

beforeEach(() => reiniciarLimitador());

describe("normalización de contacto", () => {
  it("separa email y teléfono desde el campo único", () => {
    expect(normalizarContacto(" Maria.Gomez@Ejemplo.ES ")).toEqual({
      email: "maria.gomez@ejemplo.es",
      telefono: null,
    });
    expect(normalizarContacto("+34 699 88 77 66")).toEqual({
      email: null,
      telefono: "699887766",
    });
    expect(normalizarContacto("hola")).toEqual({ email: null, telefono: null });
  });

  it("normaliza prefijos y separadores de teléfono", () => {
    expect(normalizarTelefono("+34 699-88-77-66")).toBe("699887766");
    expect(normalizarTelefono("699 88 77 66")).toBe("699887766");
    expect(normalizarTelefono("0034699887766")).toBe("699887766");
  });
});

describe("creación de leads", () => {
  it("crea el lead en estado nuevo con historial de sistema", () => {
    const resultado = crearLeadDesdeWeb({
      nombre: "Prueba Uno",
      rol: "Presidente/a de la comunidad",
      direccion: "C/ Mayor 1, Madrid",
      viviendas: "24",
      contacto: "prueba1@ejemplo.es",
      consentimiento: true,
      origen: { url: "https://cimenta.es/?utm_source=google", utmSource: "google" },
    });
    expect(resultado.ok).toBe(true);
    if (!resultado.ok) return;

    const lead = db
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.id, resultado.leadId))
      .get();
    expect(lead?.estado).toBe("nuevo");
    expect(lead?.email).toBe("prueba1@ejemplo.es");
    expect(lead?.viviendas).toBe(24);
    expect(lead?.consentimientoEn).toBeInstanceOf(Date);
    expect(lead?.utmSource).toBe("google");
    expect(lead?.posibleDuplicado).toBe(false);

    const historial = db
      .select()
      .from(esquema.leadHistorial)
      .where(eq(esquema.leadHistorial.leadId, resultado.leadId))
      .all();
    expect(historial).toHaveLength(1);
    expect(historial[0].tipo).toBe("creacion");
    expect(historial[0].usuarioId).toBeNull();
  });

  it("marca posibles duplicados por email y por teléfono normalizado", () => {
    const primero = crearLeadDesdeWeb({ nombre: "Dup", contacto: "dup@ejemplo.es" });
    expect(primero.ok && !primero.duplicado).toBe(true);
    const porEmail = crearLeadDesdeWeb({ nombre: "Dup 2", contacto: "DUP@ejemplo.es" });
    expect(porEmail.ok && porEmail.duplicado).toBe(true);

    crearLeadDesdeWeb({ nombre: "Tel", contacto: "+34 611 22 33 44" });
    const porTelefono = crearLeadDesdeWeb({ nombre: "Tel 2", contacto: "611223344" });
    expect(porTelefono.ok && porTelefono.duplicado).toBe(true);
    if (!porTelefono.ok) return;
    const lead = db
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.id, porTelefono.leadId))
      .get();
    expect(lead?.posibleDuplicado).toBe(true);
    expect(lead?.duplicadoDe).not.toBeNull();
  });

  it("rechaza contactos que no son ni email ni teléfono", () => {
    const resultado = crearLeadDesdeWeb({ nombre: "Mal", contacto: "esto no vale" });
    expect(resultado.ok).toBe(false);
  });
});

describe("endpoint público /api/lead", () => {
  it("guarda el lead y responde ok manteniendo el contrato", async () => {
    const antes = contarLeads();
    const respuesta = await POST(
      peticion({
        nombre: "Visitante Web",
        rol: "Vecino/a",
        direccion: "C/ Alcalá 100",
        viviendas: "16",
        contacto: "visitante@ejemplo.es",
        simulacion: "16 viv · Fachada · 6.000 €/viv",
        consentimiento: true,
        referencia: "",
        origen: { url: "https://cimenta.es/#contacto" },
      }),
    );
    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual({ ok: true });
    expect(contarLeads()).toBe(antes + 1);

    const lead = db.select().from(esquema.leads).orderBy(desc(esquema.leads.id)).get();
    expect(lead?.nombre).toBe("Visitante Web");
    expect(lead?.simulacion).toContain("Fachada");
  });

  it("el señuelo antispam responde ok sin crear nada", async () => {
    const antes = contarLeads();
    const respuesta = await POST(
      peticion({ nombre: "Bot", contacto: "bot@spam.com", referencia: "relleno" }),
    );
    expect((await respuesta.json()).ok).toBe(true);
    expect(contarLeads()).toBe(antes);
  });

  it("frena el doble envío inmediato del mismo contacto", async () => {
    const antes = contarLeads();
    await POST(peticion({ nombre: "Doble", contacto: "doble@ejemplo.es" }, "203.0.113.20"));
    await POST(peticion({ nombre: "Doble", contacto: "doble@ejemplo.es" }, "203.0.113.20"));
    await POST(peticion({ nombre: "Doble", contacto: "doble@ejemplo.es" }, "203.0.113.20"));
    expect(contarLeads()).toBe(antes + 2); /* la tercera cae por el freno de 30 s */
  });

  it("valida el cuerpo: contacto obligatorio", async () => {
    const respuesta = await POST(peticion({ nombre: "Sin contacto", contacto: "" }));
    expect(respuesta.status).toBe(400);
  });
});
