import { and, asc, eq, gte, isNull, like, lte, or, type SQL } from "drizzle-orm";
import { bd, esquema } from "@/db/indice";
import { ESTADOS_LEAD } from "@/db/catalogo";

export type FiltrosPipeline = {
  q?: string;
  comercial?: string;
  fuente?: string;
  desde?: string;
  hasta?: string;
};

export type TarjetaPipeline = {
  id: number;
  nombre: string;
  direccion: string | null;
  valorEstimado: number | null;
  comercial: string | null;
  prioridad: string;
  seguimientoVencido: boolean;
  posibleDuplicado: boolean;
};

export type ColumnaPipeline = {
  estado: (typeof ESTADOS_LEAD)[number];
  tarjetas: TarjetaPipeline[];
  total: number;
  valor: number;
};

export function tableroPipeline(filtros: FiltrosPipeline): ColumnaPipeline[] {
  const condiciones: SQL[] = [isNull(esquema.leads.eliminadoEn)];

  if (filtros.q) {
    const patron = `%${filtros.q.replace(/[%_]/g, "")}%`;
    const busqueda = or(
      like(esquema.leads.nombre, patron),
      like(esquema.leads.email, patron),
      like(esquema.leads.telefono, patron),
      like(esquema.leads.direccion, patron),
    );
    if (busqueda) condiciones.push(busqueda);
  }
  if (filtros.comercial) {
    const id = Number(filtros.comercial);
    if (Number.isInteger(id) && id > 0) condiciones.push(eq(esquema.leads.comercialId, id));
  }
  if (filtros.fuente) condiciones.push(eq(esquema.leads.fuente, filtros.fuente));
  if (filtros.desde) {
    const fecha = new Date(`${filtros.desde}T00:00:00`);
    if (!Number.isNaN(fecha.getTime())) condiciones.push(gte(esquema.leads.creadoEn, fecha));
  }
  if (filtros.hasta) {
    const fecha = new Date(`${filtros.hasta}T23:59:59`);
    if (!Number.isNaN(fecha.getTime())) condiciones.push(lte(esquema.leads.creadoEn, fecha));
  }

  const filas = bd()
    .select({
      id: esquema.leads.id,
      nombre: esquema.leads.nombre,
      direccion: esquema.leads.direccion,
      valorEstimado: esquema.leads.valorEstimado,
      estado: esquema.leads.estado,
      prioridad: esquema.leads.prioridad,
      proximoSeguimientoEn: esquema.leads.proximoSeguimientoEn,
      posibleDuplicado: esquema.leads.posibleDuplicado,
      comercial: esquema.usuarios.nombre,
    })
    .from(esquema.leads)
    .leftJoin(esquema.usuarios, eq(esquema.leads.comercialId, esquema.usuarios.id))
    .where(and(...condiciones))
    .orderBy(asc(esquema.leads.creadoEn))
    .all();

  const ahora = Date.now();
  return ESTADOS_LEAD.map((estado) => {
    const deEstado = filas.filter((fila) => fila.estado === estado.clave);
    return {
      estado,
      total: deEstado.length,
      valor: deEstado.reduce((suma, fila) => suma + (fila.valorEstimado ?? 0), 0),
      tarjetas: deEstado.map((fila) => ({
        id: fila.id,
        nombre: fila.nombre,
        direccion: fila.direccion,
        valorEstimado: fila.valorEstimado,
        comercial: fila.comercial,
        prioridad: fila.prioridad,
        seguimientoVencido: Boolean(
          fila.proximoSeguimientoEn && fila.proximoSeguimientoEn.getTime() < ahora,
        ),
        posibleDuplicado: fila.posibleDuplicado,
      })),
    };
  });
}
