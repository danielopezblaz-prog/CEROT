import { beforeAll, describe, expect, it } from "vitest";
import bcrypt from "bcryptjs";
import { bd, esquema } from "@/db/indice";
import type { Usuario } from "@/db/esquema";
import {
  actualizarUsuario,
  cambiarMiContrasena,
  crearUsuario,
  listarUsuarios,
} from "./usuarios";

let admin: Usuario;

beforeAll(() => {
  admin = bd()
    .insert(esquema.usuarios)
    .values({
      nombre: "Jefa",
      email: "jefa@t.dev",
      hashContrasena: bcrypt.hashSync("clave-muy-larga", 10),
      rol: "admin",
    })
    .returning()
    .get();
});

describe("gestión de usuarios", () => {
  it("crea usuarios validando email, contraseña y duplicados", () => {
    expect(crearUsuario(admin, { nombre: "Nueva", email: "malo", contrasena: "1234567890", rol: "comercial" }).ok).toBe(false);
    expect(crearUsuario(admin, { nombre: "Nueva", email: "nueva@t.dev", contrasena: "corta", rol: "comercial" }).ok).toBe(false);
    expect(crearUsuario(admin, { nombre: "Nueva", email: "nueva@t.dev", contrasena: "1234567890", rol: "comercial" }).ok).toBe(true);
    expect(crearUsuario(admin, { nombre: "Repetida", email: "NUEVA@t.dev", contrasena: "1234567890", rol: "comercial" }).ok).toBe(false);
  });

  it("desactiva sin borrar y protege al propio admin", () => {
    const nueva = listarUsuarios().find((usuario) => usuario.email === "nueva@t.dev")!;
    expect(actualizarUsuario(admin, nueva.id, { activo: false }).ok).toBe(true);
    expect(listarUsuarios().some((usuario) => usuario.email === "nueva@t.dev")).toBe(true);
    expect(actualizarUsuario(admin, admin.id, { activo: false }).ok).toBe(false);
    expect(actualizarUsuario(admin, admin.id, { rol: "comercial" }).ok).toBe(false);
  });

  it("cambia la contraseña propia verificando la actual", () => {
    expect(cambiarMiContrasena(admin, "equivocada", "otra-clave-larga").ok).toBe(false);
    expect(cambiarMiContrasena(admin, "clave-muy-larga", "otra-clave-larga").ok).toBe(true);
  });
});
