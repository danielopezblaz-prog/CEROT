/**
 * ————————————————————————————————————————————————————————————————
 *  CONTENIDO DE LA WEB DE CIMENTA
 *  Todo el copy de la página vive aquí. Edita este archivo para
 *  cambiar textos sin tocar ningún componente.
 *
 *  Convención: los fragmentos entre dobles asteriscos (**así**)
 *  se pintan en negrita/tinta dentro de párrafos grises.
 * ————————————————————————————————————————————————————————————————
 */

export const marca = {
  nombre: "Cimenta",
  claim: "Consultores en rehabilitación",
  ciudad: "Madrid",
  email: "hola@cimenta.es",
  /** Dominio canónico usado en metadatos, sitemap y JSON-LD. */
  dominio: "https://cimenta.es",

  /**
   * Teléfono y dirección públicos.
   *
   * Están vacíos a propósito: sin ellos no hay Perfil de Empresa en Google
   * y una junta desconfía, pero publicar datos inventados es peor. Todo lo
   * que los consume —pie de página, ficha de contacto, JSON-LD— se oculta
   * solo mientras falten, así que basta rellenarlos aquí para que aparezcan
   * en todas partes a la vez.
   *
   * Cuando existan deben coincidir **carácter por carácter** con los del
   * Perfil de Empresa en Google: el mismo formato en los dos sitios es lo
   * que Google usa para reconocer que hablan del mismo negocio.
   */
  telefono: "",
  /** El mismo número en formato internacional, para el enlace y el JSON-LD. */
  telefonoE164: "",
  direccion: {
    calle: "",
    codigoPostal: "",
    localidad: "Madrid",
    region: "Comunidad de Madrid",
    pais: "ES",
    /**
     * Negocio de área de servicio: se presta el servicio en el edificio del
     * cliente, no se le atiende en una oficina. Con `true` la calle no se
     * publica (igual que en el Perfil de Empresa), pero sigue haciendo falta
     * una dirección real para verificar el perfil.
     */
    areaDeServicio: true,
  },
  /** Distritos y municipios donde se presta el servicio (SEO local y JSON-LD). */
  areaServicio: [
    "Madrid",
    "Alcalá de Henares",
    "Alcobendas",
    "Getafe",
    "Leganés",
    "Móstoles",
    "Pozuelo de Alarcón",
  ],
};

/** ¿Hay teléfono publicable? Evita repetir la comprobación en cada vista. */
export const hayTelefono = () => marca.telefono.trim().length > 0;

/** ¿Hay dirección postal publicable (no solo área de servicio)? */
export const hayDireccion = () =>
  !marca.direccion.areaDeServicio && marca.direccion.calle.trim().length > 0;

export const metadatos = {
  titulo: "Cimenta — Subvenciones de rehabilitación para comunidades en Madrid",
  descripcion:
    "Consultoría independiente en ayudas a la rehabilitación para comunidades de propietarios en Madrid: qué subvenciones os corresponden, tramitación completa y presupuestos comparados entre empresas solventes. Cobramos cuando cobráis la ayuda.",
};

export const nav = {
  enlaces: [
    { texto: "Servicios", ancla: "#servicios" },
    { texto: "Cómo funciona", ancla: "#como-funciona" },
    { texto: "Planes", ancla: "#planes" },
    { texto: "Simulador", ancla: "#simulador" },
    { texto: "Preguntas", ancla: "#preguntas" },
  ],
  cta: "Pedir pre-informe",
  saltar: "Saltar al contenido",
};

export const hero = {
  cejilla: "De derrama a cuota · Madrid",
  titularLinea1: "Tu edificio necesita obras.",
  titularLinea2: "Nosotros las hacemos posibles.",
  subtitulo:
    "Qué ayudas le corresponden a tu edificio, cómo se piden y qué empresa hace la obra al mejor precio. **Convertimos la derrama que temes en una cuota que puedes pagar.**",
  ctaPrimario: "Pedir pre-informe gratuito",
  ctaSecundario: "Ver cómo funciona",
  micro: "Sin compromiso · **Cobramos por éxito, cuando la ayuda llega**",
  indicacionScroll: "Desliza para ver el proceso",
  /** Los tres actos de la pieza de scroll. */
  actos: [
    { numero: "01", nombre: "El problema" },
    { numero: "02", nombre: "El proceso" },
    { numero: "03", nombre: "El resultado" },
  ],
  alzado: {
    tituloAccesible:
      "Alzado de un edificio madrileño que se rehabilita en tres actos: primero con grietas e ITE desfavorable, después cubierto por el andamio y la malla verde mientras se tramita la subvención, y al final limpio y renovado.",
    cotaIte: "ITE desfavorable",
    cotaIteDetalle: "Informe de inspección · Fachada",
    anotaciones: [
      "Subvención tramitada",
      "2-3 empresas comparadas",
      "Técnico seleccionado",
    ],
    cotaVertical: "Alzado principal · E 1:50",
    cotaHorizontal: "Fachada 9,80 m",
    expediente: "Expediente 2026-041",
    coordenadas: "Madrid · 40,4168° N · 3,7038° O",
  },
  contador: {
    titulo: "Lo que cambia para cada vecino",
    principal: {
      prefijo: "hasta",
      valor: 80,
      sufijo: "%",
      etiqueta: "de la obra cubierta por las ayudas",
    },
    secundario: {
      prefijo: "desde",
      valor: 20,
      sufijo: "%",
      etiqueta: "restante en cuota mensual, sin derrama de golpe",
    },
    nota: "Tramo máximo de eficiencia (ahorro >60 %) · hay tramos del 40 y del 65 %",
  },
};

export const franja = [
  {
    titulo: "Cobramos cuando tú cobras",
    texto:
      "Nuestros honorarios van por hitos y el pago final está ligado al cobro de la subvención.",
  },
  {
    titulo: "No vendemos obra",
    texto:
      "No somos constructora ni estudio: comparamos ofertas con un solo interés, el de tu comunidad.",
  },
  {
    titulo: "Con tu administrador, no contra él",
    texto:
      "Él sigue llevando la comunidad. Nosotros llevamos el expediente de las ayudas.",
  },
];

export type ArteServicio =
  | "subvenciones"
  | "presupuestos"
  | "junta"
  | "empresas";

export const servicios = {
  cejilla: "Servicios",
  titulo: "Los cimientos del servicio",
  intro:
    "Cuatro piezas, un objetivo: que tu comunidad apruebe la obra con seguridad y **pague lo menos posible por ella**.",
  tarjetas: [
    {
      numero: "01",
      titulo: "Qué ayudas os corresponden",
      texto:
        "Identificamos todas las que tu edificio puede pedir —estatales, autonómicas, municipales y certificados de ahorro energético—, con su convocatoria, su tramo y su tope. Preparamos el expediente completo y lo defendemos hasta el ingreso. **Si no hay ayuda, apenas hay honorarios.**",
      etiqueta: "Cobro por éxito",
      arte: "subvenciones" as ArteServicio,
    },
    {
      numero: "02",
      titulo: "Presupuestos preliminares",
      texto:
        "Antes de decidir nada, un pre-informe con el coste orientativo de la obra, la ayuda estimada y **lo que pagaría cada vecino al mes**. Después, comparamos las ofertas de las empresas partida a partida.",
      etiqueta: "Pre-informe gratuito",
      arte: "presupuestos" as ArteServicio,
    },
    {
      numero: "03",
      titulo: "Información para decidir",
      texto:
        "Vamos a tu junta y explicamos con números lo que hay: qué ayudas existen, qué plazos corren y qué opciones tenéis. **Sin jerga y sin compromiso**, para que la comunidad vote sabiendo lo que vota.",
      etiqueta: "Presentación en junta",
      arte: "junta" as ArteServicio,
    },
    {
      numero: "04",
      titulo: "Conexión con empresas",
      texto:
        "Sacamos tu obra a concurso entre **2-3 empresas solventes** —incluida vuestra empresa de confianza, si la tenéis— con un pliego comparable, y os entregamos un cuadro comparativo con criterio técnico para que la junta adjudique con tranquilidad. Las empresas compiten por tu obra, no al revés.",
      etiqueta: "Licitación comparada",
      arte: "empresas" as ArteServicio,
    },
  ],
};

export const avisos = {
  etiqueta: "Ayudas vigentes",
  mensajes: [
    {
      texto:
        "Plan Estatal de Vivienda 2026-2030: hasta el 80 % de la obra en eficiencia energética",
      ancla: "#planes",
    },
    {
      texto:
        "Plan Rehabilita Madrid: hasta 9.000 € por vivienda — la convocatoria de 2026 cierra el 30 de septiembre",
      ancla: "/plan-rehabilita-madrid",
    },
    {
      texto: "Rehabilita tu edificio con las mejores empresas — pre-informe gratuito",
      ancla: "#contacto",
    },
  ],
};

export const comoFunciona = {
  cejilla: "Cómo funciona",
  titulo: "De la primera visita al cobro de la ayuda",
  intro:
    "El proceso entero, sin zonas grises: qué hacemos nosotros, qué decide tu junta y qué recibes al cerrar cada paso.",
  leyenda: {
    nosotros: "Lo hacemos nosotros",
    junta: "Tu junta decide",
  },
  recibes: "Recibes",
  pasos: [
    {
      titulo: "Visita y pre-informe gratuito",
      plazo: "1–2 semanas",
      quien: "nosotros",
      texto:
        "Visitamos el edificio y os entregamos los números: coste orientativo, ayuda estimada y cuota mensual por vecino.",
      entregable: "Pre-informe por escrito, con cifras y sin compromiso",
    },
    {
      titulo: "Presupuestos y estudio de ayudas",
      plazo: "3–6 semanas",
      quien: "nosotros",
      texto:
        "Pedimos **presupuestos comparables a 2-3 empresas** y hacemos el estudio completo de las ayudas que aplican a tu edificio. Todo montado y explicado, listo para decidir.",
      entregable: "Dosier con presupuestos comparados y ayudas aplicables",
    },
    {
      titulo: "Junta: se explica y se vota",
      plazo: "1 reunión",
      quien: "junta",
      texto:
        "Lo presentamos todo en la junta y lo explicamos sin jerga. **Si se vota que sí, se sigue adelante**: se ratifican los presupuestos — o se cambia lo que haga falta — y firmamos el **mandato de gestión** por escrito.",
      entregable: "Acuerdo de junta y mandato firmado",
    },
    {
      titulo: "Solicitud de las ayudas",
      plazo: "Según convocatoria",
      quien: "nosotros",
      texto:
        "Con el sí de la junta, **solicitamos las ayudas** y presentamos el expediente completo. Os ayudamos a estructurar el pago: financiación de comunidad, derramas suaves o **los anticipos que permita la propia convocatoria**, para reducir lo que adelantáis.",
      entregable: "Expediente de ayudas presentado y plan de pago por vecino",
    },
    {
      titulo: "Justificación y cobro de la ayuda",
      plazo: "4–10 meses",
      quien: "nosotros",
      texto:
        "Mientras la empresa ejecuta la obra, nosotros preparamos y presentamos **toda la justificación que exige la convocatoria**, hasta que el dinero entra en la cuenta de la comunidad. **Nuestro pago final llega cuando la subvención llega.**",
      entregable: "Ayuda justificada y cobrada por la comunidad",
    },
  ],
  balance: {
    titulo: "El proceso entero, para tu comunidad:",
    datos: [
      { valor: "1", etiqueta: "junta con todo sobre la mesa" },
      { valor: "0", etiqueta: "papeles que rellenar" },
      { valor: "0 €", etiqueta: "de honorarios por adelantado" },
    ],
  },
};

/*
 * Cifras del Plan Estatal de Vivienda 2026-2030 (RD 326/2026, BOE 23-04-2026)
 * y del Plan Rehabilita Madrid 2026, revisadas en julio de 2026.
 * TODO: repasarlas con cada nueva convocatoria.
 */
export const planes = {
  cejilla: "Los planes, explicados",
  titulo: "Las ayudas que hacen posible tu obra",
  intro:
    "Estos son los programas que tramitamos hoy para las comunidades. Cada convocatoria tiene su letra pequeña; el pre-informe te dice cuál aplica a tu edificio y con qué cuantía. **Y son acumulables cuando la normativa lo permite.**",
  tarjetas: [
    {
      clave: "estatal",
      estado: "RD 326/2026 · Plan 2026-2030",
      nombre: "Plan Estatal de Vivienda",
      destacado: "80",
      destacadoSufijo: "%",
      destacadoEtiqueta: "del coste, en el tramo más alto",
      texto:
        "El nuevo plan financia seguridad, accesibilidad y eficiencia energética del edificio. En eficiencia, **la ayuda va por tramos de ahorro — 40, 65 u 80 % del coste** según la reducción de consumo que certifique el proyecto: por eso el proyecto importa tanto como la obra.",
      nota: "Hasta 20.500 € por vivienda en eficiencia energética",
    },
    {
      clave: "rehabilita",
      estado: "Ayuntamiento de Madrid · Modalidad exprés",
      nombre: "Plan Rehabilita Madrid",
      destacado: "9.000",
      destacadoSufijo: "€",
      destacadoEtiqueta: "por vivienda, como máximo",
      texto:
        "Las ayudas municipales a eficiencia energética, conservación y **accesibilidad: ascensores, rampas y supresión de barreras**. Su modalidad exprés simplifica la tramitación de las actuaciones más frecuentes.",
      nota: "Compatible con el plan estatal · Cuantías por convocatoria",
    },
    {
      clave: "caes",
      estado: "Abierto todo el año",
      nombre: "CAE — Certificados de Ahorro Energético",
      destacado: "+",
      destacadoSufijo: "€",
      destacadoEtiqueta: "ingreso adicional por el ahorro",
      texto:
        "El ahorro energético que consigue tu obra se convierte en certificados que compran las comercializadoras: **dinero adicional que baja todavía más la cuota** de cada vecino.",
      nota: "Se suma a las subvenciones · Lo negociamos junto a la empresa",
    },
  ],
  escalera: {
    titulo: "Eficiencia energética: la ayuda crece con el ahorro conseguido",
    pasos: [
      {
        valor: 40,
        etiqueta: "Ahorro ≥ 30 %",
        detalle: "El tramo de entrada: reducir un tercio el consumo del edificio",
      },
      {
        valor: 65,
        etiqueta: "Ahorro ≥ 45 %",
        detalle: "Obras de envolvente ambiciosas: fachada, cubierta y ventanas",
      },
      {
        valor: 80,
        etiqueta: "Ahorro > 60 %",
        detalle: "Rehabilitación profunda, hasta 20.500 € por vivienda",
      },
    ],
  },
  cuantias: {
    titulo: "Topes por vivienda",
    filas: [
      ["Seguridad y conservación", "hasta 8.000 €"],
      ["Accesibilidad", "hasta 13.000 €"],
      ["Eficiencia energética", "hasta 20.500 €"],
    ],
    nota: "Topes del RD 326/2026 según programa y actuación; en accesibilidad pueden subir si residen personas con discapacidad. Cada convocatoria fija su detalle: lo confirmamos por escrito en tu pre-informe.",
  },
  cta: "¿Cuál aplica a mi edificio? Pedir pre-informe",
};

export const simulador = {
  cejilla: "Simulador",
  titulo: "¿Cuánto pagaría cada vecino?",
  intro:
    "Mueve los controles y mira los números. Es la misma cuenta que llevamos a tu junta, con los tramos y topes reales del RD 326/2026.",
  etiquetaViviendas: "Viviendas del edificio",
  etiquetaObra: "Tipo de obra",
  obras: [
    { clave: "fachada", nombre: "Fachada" },
    { clave: "fachadaCubierta", nombre: "Fachada + cubierta" },
    { clave: "integral", nombre: "Integral" },
  ],
  etiquetaImporte: "Importe medio de obra por vivienda",
  notaImporte:
    "Lo estimamos por el tipo de obra y el tamaño del edificio. Si ya tenéis un presupuesto sobre la mesa, muévelo y la cuenta entera se rehace.",
  etiquetaTramo: "Ambición energética",
  tramos: [
    { clave: "t40", pct: "40 %", ahorro: "Ahorro ≥ 30 %" },
    { clave: "t65", pct: "65 %", ahorro: "Ahorro ≥ 45 %" },
    { clave: "t80", pct: "80 %", ahorro: "Ahorro > 60 %" },
  ],
  notaTramo:
    "El tramo de ayuda lo fija el ahorro que certifique el proyecto. Nuestro trabajo es llevarte al más alto que tu edificio permita.",
  etiquetaPlazo: "Plazo de financiación",
  plazoSufijo: "años",
  ficha: {
    cabecera: "Cuota estimada",
    derramaAntes: "De golpe, sin ayudas, serían",
    derramaDespues: "€ por vecino",
    porVecinoMes: "por vecino y mes",
    conAnticipoChip: "Con anticipo de subvención",
    sinAnticipo: "Si el programa no permite anticipo:",
    sinAnticipoSufijo: "€/mes mientras llega la ayuda (~18 meses)",
    quienPaga: "Quién paga la obra",
    segAyudas: "Ayudas",
    segComunidad: "Tu comunidad",
    topeChip: "Tope del RD 326/2026 aplicado: {tope} € por vivienda",
  },
  avisoEstimacion: "Estimación orientativa — el cálculo real es gratuito",
  supuestos:
    "Supuestos del ejemplo: interés del 5,9 %, tramos de ayuda del RD 326/2026 según el ahorro certificado — con sus topes por vivienda — el plazo que elijas y el importe medio de obra que fijes. Tu caso se calcula con las convocatorias vigentes.",
  memoria: {
    titulo: "Memoria de cálculo",
    subtitulo: "Así sale la cuota, número a número",
    filas: {
      costeObra: "Obra: {importe} € de media por vivienda × {viviendas}",
      ayuda: "Ayuda estimada",
      ayudaTope: "Ayuda al tope del RD: {tope} € × {viviendas} viv",
      neto: "Coste neto para la comunidad",
      porVivienda: "Parte de cada vivienda",
      financiacion: "Financiado en {meses} cuotas al {interes} de interés",
      puente: "Sin anticipo: adelantar la ayuda ~{meses} meses añade",
    },
    cuotaConAnticipo: "Cuota con anticipo",
    cuotaSinAnticipo: "Cuota sin anticipo",
    notaComunidad:
      "Cada comunidad es distinta: superficie, estado de la fachada, año del edificio y convocatoria vigente cambian el número. El pre-informe gratuito hace esta misma cuenta con los datos reales de tu edificio.",
  },
  cta: "Pedir el cálculo real de mi edificio",
};

export const transparencia = {
  cejilla: "Transparencia",
  titulo: "Cómo cobramos, sin letra pequeña",
  intro:
    "Un intermediario solo funciona si sabes exactamente de qué vive. Nuestro modelo, por escrito en el mandato:",
  compromisos: [
    {
      titulo: "Honorarios por éxito",
      texto:
        "Un fijo pequeño al empezar y el resto ligado a hitos: concesión y cobro de la ayuda. La comunidad paga cuando cobra.",
    },
    {
      titulo: "Comisión de empresa, declarada",
      texto:
        "La empresa adjudicataria nos paga una comisión por recibir la obra preparada. Está escrita en vuestro mandato: sin comisiones ocultas.",
    },
    {
      titulo: "Nunca tocamos vuestra caja",
      texto:
        "Derramas, recibos y pagos siguen circulando por vuestro administrador, como siempre. La subvención se ingresa siempre a nombre de la comunidad: **nunca pedimos la cesión del derecho de cobro**. Nosotros solo facturamos nuestros honorarios.",
    },
    {
      titulo: "Independencia real",
      texto:
        "No tenemos obra propia que colocar ni proyecto propio que firmar: nuestra única mercancía es que el proceso salga bien.",
    },
  ],
};

export const aliados = {
  cejilla: "También trabajamos con",
  titulo: "Administradores y empresas",
  bloques: [
    {
      titulo: "¿Administras fincas?",
      texto:
        "Te quitamos el expediente de rehabilitación de encima: pre-informe gratuito para tus comunidades con problemas, tú convocas, nosotros presentamos. **Compromiso por escrito: jamás haremos administración de fincas** ni tocaremos tu relación con el cliente.",
      enlace: "Hablemos de tu cartera",
      ruta: "/administradores-de-fincas",
    },
    {
      titulo: "¿Eres constructora?",
      texto:
        "Te traemos **obra madura**: junta aprobada, proyecto redactado y ayuda en tramitación. Sin meses de comercial ni presupuestos a fondo perdido. Tú ejecutas; el expediente ya viene hecho.",
      enlace: "Entrar en nuestras licitaciones",
    },
  ],
};

export const preguntas = {
  cejilla: "Preguntas frecuentes",
  titulo: "Lo que toda junta pregunta",
  lista: [
    {
      pregunta: "¿Cuánto cuesta esto a la comunidad?",
      respuesta:
        "El pre-informe es gratuito. Si seguimos adelante, un fijo pequeño al firmar el mandato y el resto **solo si la ayuda se concede y se cobra**. El porcentaje exacto va por escrito antes de empezar.",
    },
    {
      pregunta: "¿Y si al final no dan la subvención?",
      respuesta:
        "Entonces nuestros honorarios de éxito no se devengan: ese es el trato. Antes de presentar nada os decimos con franqueza qué probabilidades reales tiene el expediente.",
    },
    {
      pregunta: "¿Tenemos que cambiar de administrador?",
      respuesta:
        "**No, nunca.** Vuestro administrador sigue llevando la comunidad y su caja. Nosotros llevamos solo el expediente de la obra, y colaboramos con él en todo momento.",
    },
    {
      pregunta: "Ya tenemos una empresa de confianza",
      respuesta:
        "Perfecto: la invitamos a ofertar como una de las 2-3 empresas del concurso. Si es tan buena como creéis, ganará — con proyecto y ayuda ya resueltos, y con sus números comparados delante de la junta.",
    },
    {
      pregunta: "¿No es mejor esperar a la próxima convocatoria?",
      respuesta:
        "La próxima convocatoria la aprovecha quien llega con el expediente preparado. Esperar sin preparar es exactamente lo que hace perder las ayudas: preparar hoy no obliga a nada y os deja listos para pedir.",
    },
    {
      pregunta: "¿Quién firma el proyecto y dirige la obra?",
      respuesta:
        "Siempre un arquitecto o técnico competente, contratado por la comunidad — os proponemos una terna. Nosotros no firmamos proyectos ni dirigimos obras: **somos la consultoría que consigue la ayuda y compara los presupuestos**, y ahí acaba nuestro papel.",
    },
    {
      pregunta: "¿Sois agente rehabilitador?",
      respuesta:
        "No. Un agente rehabilitador redacta el proyecto y dirige la obra, y su modelo suele ir ligado a **la cesión del derecho de cobro** de la subvención. Nosotros somos consultoría: tramitamos las ayudas y comparamos presupuestos, sin obra propia y sin tocar nunca el cobro de la ayuda.",
      ruta: "/agente-rehabilitador-o-gestor",
      enlace: "Ver las diferencias entre las tres figuras →",
    },
  ],
};

export const formulario = {
  cejilla: "Empieza aquí",
  titulo: "Pide el pre-informe gratuito de tu edificio",
  intro:
    "Una ficha de tres casillas: la rellenas en un minuto y te devolvemos los números de tu edificio. Sin compromiso.",
  queRecibiras: {
    titulo: "Qué recibirás",
    puntos: [
      "Coste orientativo de la obra de tu edificio",
      "Ayudas aplicables y cuantía estimada",
      "Cuota mensual por vecino, en varios escenarios",
      "Una recomendación honesta: a veces es «todavía no»",
    ],
  },
  ficha: {
    titulo: "Ficha de solicitud",
    duracion: "1 min",
  },
  simulacion: {
    etiqueta: "Llevamos tu simulación",
    quitar: "Quitar la simulación",
  },
  consentimiento: {
    antes: "He leído y acepto la",
    enlace: "política de privacidad",
    despues: "para que Cimenta me responda sobre mi edificio.",
  },
  bloques: {
    edificio: {
      numero: "01",
      titulo: "El edificio",
      direccion: {
        etiqueta: "Dirección — con eso nos basta",
        ayuda: "Calle y número, ciudad",
      },
    },
    persona: {
      numero: "02",
      titulo: "Tú",
      nombre: { etiqueta: "Nombre", ayuda: "Nombre y apellido" },
      rol: {
        etiqueta: "Tu papel — opcional",
        opciones: ["Presidente/a", "Vecino/a", "Administrador/a de fincas", "Otro"],
      },
    },
    respuesta: {
      numero: "03",
      titulo: "Dónde te respondemos",
      contacto: { etiqueta: "Teléfono o email", ayuda: "Como prefieras" },
    },
  },
  botones: {
    enviar: "Pedir pre-informe gratuito",
    enviando: "Enviando solicitud…",
  },
  errores: {
    nombre: "Escribe tu nombre para poder dirigirnos a ti",
    direccion: "Necesitamos la dirección para estudiar el edificio",
    contacto: "Déjanos un teléfono o un email válido para responderte",
    consentimiento: "Necesitamos tu consentimiento para poder responderte",
  },
  nota: "Respondemos en 48 h laborables · Tus datos solo se usan para prepararte el pre-informe",
  exito: {
    sello: "Solicitud registrada",
    titulo: "Hecho. El pre-informe de tu edificio está en marcha.",
    texto:
      "Te responderemos en menos de 48 horas laborables con los primeros números. Si tenemos dudas sobre el edificio, te llamaremos antes.",
    boton: "Enviar otra solicitud",
  },
  error: {
    titulo: "No hemos podido enviar tu solicitud",
    texto: "Inténtalo de nuevo en unos segundos o escríbenos directamente a",
  },
};

export const pie = {
  descripcion:
    "Consultoría independiente en subvenciones a la rehabilitación para comunidades de propietarios.",
  /** Se muestra en lugar de la calle mientras el negocio sea de área de servicio. */
  areaServicio: "Madrid y área metropolitana · Atendemos en tu edificio",
  derechos: `© ${new Date().getFullYear()} Cimenta · Madrid`,
  enlacesLegales: [
    { texto: "Aviso legal", ruta: "/aviso-legal" },
    { texto: "Privacidad", ruta: "/privacidad" },
  ],
  volverArriba: "Volver arriba",
};

export const paginasLegales = {
  volver: "Volver a la página principal",
  /*
   * PENDIENTE antes de publicar: el art. 10 de la LSSI exige que el aviso
   * legal identifique al titular con su denominación, NIF y domicilio.
   * Añádelos en "Titular del sitio" en cuanto estén decididos — es el mismo
   * dato que hay que rellenar en `marca.direccion` para el Perfil de Empresa.
   */
  avisoLegal: {
    titulo: "Aviso legal",
    actualizado: "Última revisión: julio de 2026",
    secciones: [
      {
        titulo: "Titular del sitio",
        parrafos: [
          "Este sitio web pertenece a Cimenta, consultoría independiente en subvenciones a la rehabilitación de edificios, con actividad en la Comunidad de Madrid. Puedes escribirnos para cualquier cuestión relacionada con este sitio en hola@cimenta.es.",
        ],
      },
      {
        titulo: "Objeto",
        parrafos: [
          "La finalidad de este sitio es informar sobre los servicios de consultoría en subvenciones y de comparación de presupuestos que Cimenta presta a comunidades de propietarios, administradores de fincas y empresas constructoras, y recoger solicitudes de pre-informe.",
          "La información publicada, incluidas las estimaciones del simulador, tiene carácter orientativo y no constituye oferta contractual. Las condiciones concretas de cada encargo se recogen siempre por escrito en el mandato de gestión.",
        ],
      },
      {
        titulo: "Propiedad intelectual",
        parrafos: [
          "Los textos, ilustraciones y elementos gráficos de este sitio son titularidad de Cimenta o se utilizan con autorización de sus titulares. No está permitida su reproducción con fines comerciales sin consentimiento previo.",
        ],
      },
      {
        titulo: "Responsabilidad",
        parrafos: [
          "Cimenta trabaja para que la información de este sitio esté actualizada, en particular la relativa a programas de ayudas públicas, cuyas condiciones dependen de cada convocatoria. Las decisiones de la comunidad deben tomarse siempre sobre los números del pre-informe y de la documentación firmada, no sobre los ejemplos publicados aquí.",
        ],
      },
    ],
  },
  privacidad: {
    titulo: "Política de privacidad",
    actualizado: "Última revisión: julio de 2026",
    secciones: [
      {
        titulo: "Responsable del tratamiento",
        parrafos: [
          "El responsable de los datos que nos facilitas a través de este sitio es Cimenta (Madrid). Contacto para cuestiones de privacidad: hola@cimenta.es.",
        ],
      },
      {
        titulo: "Qué datos recogemos y para qué",
        parrafos: [
          "El formulario de pre-informe recoge tu nombre, tu papel en la comunidad, la dirección del edificio y un dato de contacto (teléfono o email). Si antes has usado el simulador, se envía también el resumen de esa simulación. Los usamos exclusivamente para preparar el pre-informe que nos pides y responderte.",
          "Junto a la solicitud guardamos datos técnicos sobre cómo llegaste: la página desde la que enviaste el formulario, la web que te trajo y, si venías de una campaña, sus parámetros de seguimiento (los llamados UTM). Nos sirven para saber qué canales funcionan, y no se usan para perfilarte ni se cruzan con datos de terceros.",
          "No usamos tus datos para publicidad, no los cedemos a terceros y no tomamos decisiones automatizadas con ellos.",
        ],
      },
      {
        titulo: "Base legal y conservación",
        parrafos: [
          "Tratamos tus datos porque tú nos los pides al solicitar el pre-informe (medidas precontractuales a petición del interesado). Si no seguimos adelante, los conservamos como máximo doce meses y después los eliminamos.",
        ],
      },
      {
        titulo: "Tus derechos",
        parrafos: [
          "Puedes pedirnos acceso, rectificación o supresión de tus datos, así como oponerte al tratamiento, escribiendo a hola@cimenta.es. También puedes reclamar ante la Agencia Española de Protección de Datos si consideras que no hemos tratado tus datos correctamente.",
        ],
      },
      {
        titulo: "Cookies y medición de audiencia",
        parrafos: [
          "Este sitio no utiliza cookies de seguimiento ni de publicidad, y por eso no te muestra ningún banner de consentimiento.",
          "Para saber qué páginas se visitan usamos una herramienta de medición de audiencia que no instala cookies ni identifica a nadie: solo mide este sitio, se trata únicamente por nuestra cuenta, no permite seguirte por otras webs, no se combina con datos de terceros y no se cede a nadie. Son las condiciones que la Agencia Española de Protección de Datos exige para que la medición de audiencia quede exenta de consentimiento previo.",
          "Si algún día activamos publicidad y sus cookies de conversión, esta política se actualizará antes de hacerlo y verás el banner de consentimiento correspondiente.",
        ],
      },
    ],
  },
};
