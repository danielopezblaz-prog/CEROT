/**
 * ————————————————————————————————————————————————————————————————
 *  PÁGINAS DE ATERRIZAJE
 *  Compañero de content.ts: aquí vive el copy de cada página que
 *  ataca una búsqueda concreta. La home sigue en content.ts.
 *
 *  Misma convención de negritas: **así**.
 *
 *  Añadir una página = añadir una entrada aquí + una carpeta en
 *  src/app/<ruta>/. El sitemap y el pie se rellenan solos desde
 *  la lista PAGINAS del final.
 * ————————————————————————————————————————————————————————————————
 */

/**
 * ¿Puede Cimenta describirse como «gestor de la rehabilitación»?
 *
 * Es el término exacto de la normativa para lo que hace —tramitar las
 * ayudas y asesorar la contratación, sin dirigir obra— y da precisión
 * ante una junta. Pero algunas comunidades exigen inscripción en un
 * registro de agentes y gestores para usarlo (la Comunidad Valenciana
 * tiene ese trámite) y **está sin confirmar si Madrid mantiene uno**.
 *
 * Mientras esto sea `false`, la web explica la figura pero no se la
 * atribuye. Ponlo a `true` solo después de preguntarlo en la Dirección
 * General de Vivienda y Rehabilitación de la Comunidad de Madrid.
 */
export const PUEDE_LLAMARSE_GESTOR = false;

export type Bloque =
  | { tipo: "texto"; titulo: string; parrafos: string[] }
  | {
      tipo: "puntos";
      titulo: string;
      intro?: string;
      puntos: { titulo: string; texto: string }[];
    }
  | {
      tipo: "pasos";
      titulo: string;
      intro?: string;
      pasos: { titulo: string; texto: string }[];
    }
  | {
      tipo: "tabla";
      titulo: string;
      intro?: string;
      cabeceras: string[];
      filas: string[][];
      nota?: string;
    }
  | { tipo: "destacado"; titulo: string; parrafos: string[] }
  | { tipo: "aviso"; titulo: string; texto: string };

export type Pagina = {
  /** Ruta sin barra final. Es la clave de todo: sitemap, enlaces y canónica. */
  ruta: string;
  /** Nombre corto para menús y migas. */
  nombre: string;
  titulo: string;
  descripcion: string;
  cejilla: string;
  h1: string;
  entradilla: string;
  actualizado?: string;
  datos?: { valor: string; etiqueta: string }[];
  bloques: Bloque[];
  faq?: { pregunta: string; respuesta: string }[];
  cierre: { titulo: string; texto: string };
  /** Prioridad en el sitemap (la home es 1). */
  prioridad: number;
};

const ACTUALIZADO = "Última revisión: julio de 2026";

/* ——————————————————————————————————————————————————————————————
   01 · Plan Rehabilita Madrid — la página de urgencia
   —————————————————————————————————————————————————————————————— */

const planRehabilita: Pagina = {
  ruta: "/plan-rehabilita-madrid",
  nombre: "Plan Rehabilita Madrid",
  titulo: "Plan Rehabilita Madrid 2026: ayudas, cuantías y plazo",
  descripcion:
    "Qué subvenciona el Plan Rehabilita Madrid 2026, cuánto da por vivienda y hasta cuándo se puede pedir. Preparamos el expediente completo de tu comunidad y cobramos cuando llega la ayuda.",
  cejilla: "Convocatoria abierta",
  h1: "Plan Rehabilita Madrid 2026: qué pide, cuánto da y hasta cuándo",
  entradilla:
    "El Ayuntamiento de Madrid subvenciona obras de conservación, accesibilidad y eficiencia energética en edificios residenciales. **La convocatoria de 2026 cierra el 30 de septiembre**, y el expediente no se monta en una semana.",
  actualizado: ACTUALIZADO,
  datos: [
    { valor: "9.000 €", etiqueta: "por vivienda, como máximo" },
    { valor: "30-sep", etiqueta: "último día para presentar" },
    { valor: "Exprés", etiqueta: "modalidad simplificada disponible" },
  ],
  bloques: [
    {
      tipo: "texto",
      titulo: "Qué es y a quién le sirve",
      parrafos: [
        "Rehabilita Madrid es la línea de ayudas municipales a la rehabilitación de edificios de vivienda. La pide **la comunidad de propietarios**, no cada vecino por su cuenta, y financia una parte del coste de la obra que la junta apruebe.",
        "Es compatible con las ayudas del Plan Estatal de Vivienda: **se pueden acumular cuando la normativa de cada convocatoria lo permite**, y ahí es donde se juega buena parte del ahorro. Un expediente bien montado va a las dos puertas, no a una.",
      ],
    },
    {
      tipo: "puntos",
      titulo: "Qué obras entran",
      intro:
        "Tres familias de actuación, y casi siempre conviene combinarlas en un solo proyecto:",
      puntos: [
        {
          titulo: "Conservación y seguridad",
          texto:
            "Fachadas, cubiertas, estructura, instalaciones. Es la vía natural cuando llega **una ITE desfavorable** y la obra deja de ser opcional.",
        },
        {
          titulo: "Accesibilidad",
          texto:
            "Instalación de ascensor, rampas, salvaescaleras y supresión de barreras. La modalidad exprés simplifica la tramitación de las actuaciones más frecuentes.",
        },
        {
          titulo: "Eficiencia energética",
          texto:
            "Aislamiento de envolvente, ventanas, cubierta y sustitución de instalaciones térmicas. Es la familia **mejor pagada** cuando el proyecto certifica un ahorro alto.",
        },
      ],
    },
    {
      tipo: "texto",
      titulo: "Por qué septiembre se decide en julio",
      parrafos: [
        "Una solicitud completa necesita, como mínimo: acuerdo de junta, proyecto o memoria técnica firmada, presupuesto de la empresa, certificado energético de partida y la documentación de la comunidad al día. **Convocar una junta y reunir todo eso lleva entre seis y diez semanas** en el mejor de los casos.",
        "Quien empieza en septiembre no llega. Quien empieza ahora llega con margen para corregir lo que falte — y esa corrección, en la práctica, es lo que separa un expediente concedido de uno inadmitido.",
      ],
    },
    {
      tipo: "pasos",
      titulo: "Cómo lo hacemos",
      intro:
        "El mismo proceso de siempre, comprimido para llegar a la convocatoria:",
      pasos: [
        {
          titulo: "Visita y pre-informe",
          texto:
            "Vemos el edificio y os damos por escrito el coste orientativo, la ayuda estimada y **la cuota mensual de cada vecino**. Gratuito y sin compromiso.",
        },
        {
          titulo: "Presupuestos comparados",
          texto:
            "Sacamos la obra a concurso entre 2-3 empresas solventes con un pliego comparable, para que la junta vote con números reales delante.",
        },
        {
          titulo: "Junta y mandato",
          texto:
            "Lo explicamos en la junta sin jerga. Si sale que sí, firmamos el mandato de gestión por escrito y **solicitamos con acuerdo expreso de la comunidad**.",
        },
        {
          titulo: "Expediente y justificación",
          texto:
            "Presentamos, respondemos a los requerimientos y justificamos hasta que el dinero entra en la cuenta de la comunidad.",
        },
      ],
    },
    {
      tipo: "aviso",
      titulo: "Las cifras cambian con cada convocatoria",
      texto:
        "Los importes y requisitos de esta página son los publicados para 2026 y se revisan cada vez que sale una convocatoria nueva. Antes de que vuestra comunidad decida nada, os confirmamos por escrito en el pre-informe qué aplica exactamente a vuestro edificio.",
    },
  ],
  faq: [
    {
      pregunta: "¿Podemos pedirla si la obra ya ha empezado?",
      respuesta:
        "Por regla general no: las convocatorias exigen que la actuación no esté iniciada antes de la solicitud, salvo las excepciones que fije cada una. Si ya habéis empezado, decídnoslo el primer día — cambia la estrategia entera del expediente.",
    },
    {
      pregunta: "¿Hay que adelantar el dinero de la obra?",
      respuesta:
        "Casi siempre sí, en parte. Por eso el pre-informe calcula los dos escenarios: con anticipo de la subvención si la convocatoria lo permite, y sin él. Y os ayudamos a estructurar el pago para que no caiga de golpe.",
    },
    {
      pregunta: "¿Sirve para un edificio con locales comerciales?",
      respuesta:
        "Sí, aunque el reparto de la ayuda y los porcentajes de uso residencial condicionan la cuantía. Es una de las cosas que miramos en la visita, porque cambia el número final.",
    },
  ],
  cierre: {
    titulo: "Aún llegas a la convocatoria de 2026",
    texto:
      "Pídenos el pre-informe de tu edificio. Es gratuito, te lo devolvemos con números y te dice si tu comunidad llega a tiempo — incluida la respuesta incómoda de «este año no».",
  },
  prioridad: 0.9,
};

/* ——————————————————————————————————————————————————————————————
   02 · Simulador — el activo único
   —————————————————————————————————————————————————————————————— */

const simuladorPagina: Pagina = {
  ruta: "/simulador",
  nombre: "Simulador de cuota",
  titulo: "Simulador: cuánto paga cada vecino por la obra",
  descripcion:
    "Calcula qué cuesta rehabilitar tu edificio, cuánta ayuda te corresponde y qué cuota mensual pagaría cada vecino. Los tramos y topes reales del RD 326/2026, sin registrarte.",
  cejilla: "Calcula tu cuota",
  h1: "¿Cuánto pagaría cada vecino al mes?",
  entradilla:
    "La pregunta que decide la votación de la junta no es cuánto cuesta la obra: es **cuánto le toca a cada uno**. Mueve los controles y sal de dudas — la misma cuenta que llevamos a las juntas, sin registro y sin dejar tus datos.",
  actualizado: ACTUALIZADO,
  bloques: [
    {
      tipo: "texto",
      titulo: "De dónde salen estos números",
      parrafos: [
        "El simulador aplica los tramos de ayuda del **RD 326/2026** (Plan Estatal de Vivienda 2026-2030) con sus topes por vivienda, reparte el coste neto entre las viviendas del edificio y financia esa parte al plazo que elijas. Nada es una cifra inventada: cada paso está en la memoria de cálculo, desplegable bajo el resultado.",
        "El tramo de ayuda —40, 65 u 80 %— **no lo elige la comunidad: lo fija el ahorro energético que certifique el proyecto**. Por eso el simulador te deja moverlo: para que veas lo que está en juego según la ambición de la obra.",
      ],
    },
    {
      tipo: "puntos",
      titulo: "Lo que el simulador no puede saber",
      intro:
        "Es una estimación honesta, y una estimación tiene límites. Estos son los suyos:",
      puntos: [
        {
          titulo: "El estado real de tu fachada",
          texto:
            "Una patología estructural o un aislamiento imposible cambian el presupuesto por completo. Eso solo se ve en la visita.",
        },
        {
          titulo: "La convocatoria vigente el día que pidáis",
          texto:
            "Los topes y porcentajes se mueven con cada convocatoria. El simulador usa los publicados hoy; **el pre-informe usa los del día de vuestra solicitud**.",
        },
        {
          titulo: "Vuestras condiciones de financiación",
          texto:
            "El interés del ejemplo es orientativo. El real depende de la entidad, del aval de la comunidad y de la morosidad que arrastre.",
        },
        {
          titulo: "Los ingresos que no son subvención",
          texto:
            "Los certificados de ahorro energético (CAE) bajan todavía más la cuota y aquí no se cuentan: se negocian junto a la empresa cuando el proyecto ya existe.",
        },
      ],
    },
    {
      tipo: "destacado",
      titulo: "Del número redondo al número de verdad",
      parrafos: [
        "Si el resultado te encaja, el paso siguiente es el pre-informe: **la misma cuenta, pero con los datos reales de tu edificio** —superficie, año, estado, convocatoria vigente— y por escrito, para que puedas llevarla a la junta.",
        "Es gratuito, no obliga a nada y a veces termina en «todavía no». Preferimos decirlo antes que después.",
      ],
    },
  ],
  cierre: {
    titulo: "Pide el cálculo real de tu edificio",
    texto:
      "Rellena la ficha y te devolvemos el pre-informe con los números de tu comunidad. Si has usado el simulador, tu simulación viaja con la solicitud.",
  },
  prioridad: 0.9,
};

/* ——————————————————————————————————————————————————————————————
   03 · Audita tu oferta — la segunda opinión
   —————————————————————————————————————————————————————————————— */

const auditaTuOferta: Pagina = {
  ruta: "/audita-tu-oferta",
  nombre: "Auditamos tu presupuesto",
  titulo: "Auditamos gratis el presupuesto de tu comunidad",
  descripcion:
    "Segunda opinión independiente sobre el presupuesto de rehabilitación de tu comunidad: partidas, mediciones y ayudas no pedidas. No vendemos obra, así que no tenemos nada que colocarte.",
  cejilla: "Segunda opinión",
  h1: "¿Te parece caro ese presupuesto? Míralo con nosotros antes de votar",
  entradilla:
    "Tienes una oferta encima de la mesa, la junta es en dos semanas y nadie sabe si el número es razonable. **Te lo revisamos gratis y por escrito**: partida a partida, con la ayuda que os corresponde puesta al lado.",
  actualizado: ACTUALIZADO,
  bloques: [
    {
      tipo: "puntos",
      titulo: "Qué miramos",
      intro:
        "Cinco comprobaciones que se pueden hacer sobre el papel, sin pisar la obra:",
      puntos: [
        {
          titulo: "Que las mediciones cuadren",
          texto:
            "Metros de fachada, superficie de cubierta, número de huecos. Es la comprobación más aburrida y **la que más veces encuentra algo**.",
        },
        {
          titulo: "Que las partidas estén desglosadas",
          texto:
            "Un presupuesto de una línea no se puede comparar con nada. Si no hay desglose, el primer entregable es pedirlo.",
        },
        {
          titulo: "Qué entra y qué no",
          texto:
            "Andamio, licencia, dirección facultativa, gestión de residuos, seguridad y salud. Lo que se queda fuera del presupuesto reaparece como imprevisto.",
        },
        {
          titulo: "Que la solución técnica dé el tramo",
          texto:
            "Un aislamiento corto de espesor puede dejaros en el tramo del 40 % cuando el edificio daba para el 65 %. **Ese error no se ve en el precio: se ve en la ayuda.**",
        },
        {
          titulo: "Qué ayudas no se han pedido",
          texto:
            "Es lo más frecuente de todo: obras planteadas contra una sola convocatoria cuando eran compatibles dos, o sin contar los certificados de ahorro energético.",
        },
      ],
    },
    {
      tipo: "destacado",
      titulo: "Solo aritmética verificable",
      parrafos: [
        "No decimos que una empresa esté cobrando de más. Decimos **qué números no cuadran entre sí** y qué preguntas conviene hacerle antes de firmar: una medición que no coincide con la fachada, una partida sin desglosar, una ayuda que no se ha pedido.",
        "La diferencia importa. Lo primero es una acusación que no podemos sostener sin haber visto la obra; lo segundo es un hecho comprobable que la junta puede llevar a la empresa. **Solo hacemos lo segundo**, y por eso el informe se sostiene delante de quien sea.",
      ],
    },
    {
      tipo: "texto",
      titulo: "Por qué es gratis, y qué ganamos",
      parrafos: [
        "Porque es la manera honesta de demostrar lo que hacemos. Si la oferta que tienes es buena, te lo decimos y no habrás perdido nada — **también nos ha pasado**. Si aparece margen de mejora, tendrás delante lo que hacemos todos los días y la conversación sobre el expediente completo se dará sola.",
        "No somos constructora ni estudio de arquitectura: no tenemos obra propia que colocaros. Nuestro único producto es que el proceso salga bien.",
      ],
    },
    {
      tipo: "pasos",
      titulo: "Cómo funciona",
      pasos: [
        {
          titulo: "Nos mandas el presupuesto",
          texto:
            "El PDF de la empresa, y si lo tenéis el acta de la junta o el informe técnico. Con eso empezamos.",
        },
        {
          titulo: "Lo revisamos en 48-72 horas",
          texto:
            "Comprobamos mediciones, desglose, exclusiones y encaje con las convocatorias abiertas.",
        },
        {
          titulo: "Te devolvemos un informe corto",
          texto:
            "Dos o tres páginas: qué está bien, **qué preguntas hacer** y qué ayudas quedan sobre la mesa. Escrito para leerse en una junta.",
        },
      ],
    },
    {
      tipo: "aviso",
      titulo: "Qué necesitamos de ti",
      texto:
        "El presupuesto completo, no un resumen: sin mediciones ni desglose no hay auditoría posible, solo opinión. Si la empresa no te lo entrega desglosado, eso ya es el primer dato.",
    },
  ],
  faq: [
    {
      pregunta: "¿Se entera la empresa de que lo hemos revisado?",
      respuesta:
        "Solo si vosotros queréis. El informe es para la comunidad. Dicho esto, una empresa seria no tiene problema en explicar sus mediciones: si se molesta por la pregunta, eso también es información.",
    },
    {
      pregunta: "¿Y si la oferta que tenemos es correcta?",
      respuesta:
        "Os lo decimos con la misma claridad y ahí se acaba. Un presupuesto bien hecho revisado por un tercero es justo lo que necesita una junta para votar tranquila.",
    },
    {
      pregunta: "¿Tenemos que cambiar de empresa si os contratamos?",
      respuesta:
        "No. Si tenéis una empresa de confianza, la invitamos a ofertar en el concurso como una más. Si es tan buena como creéis, ganará — y ganará con el proyecto y la ayuda ya resueltos.",
    },
  ],
  cierre: {
    titulo: "Mándanos el presupuesto",
    texto:
      "Rellena la ficha con la dirección del edificio y te decimos dónde enviarlo. La auditoría es gratuita y no compromete a nada.",
  },
  prioridad: 0.8,
};

/* ——————————————————————————————————————————————————————————————
   04 · Administradores de fincas — el canal prescriptor
   —————————————————————————————————————————————————————————————— */

const administradores: Pagina = {
  ruta: "/administradores-de-fincas",
  nombre: "Administradores de fincas",
  titulo: "Administradores de fincas: llevamos el expediente",
  descripcion:
    "Colaboramos con administradores de fincas en Madrid: llevamos el expediente de subvenciones y la comparación de presupuestos de tus comunidades. Compromiso por escrito de no hacer nunca administración de fincas.",
  cejilla: "Para administradores",
  h1: "El expediente de rehabilitación, fuera de tu mesa",
  entradilla:
    "Tienes veinte comunidades y tres con la ITE desfavorable. El expediente de ayudas se come las horas que no tienes y no lo paga nadie. **Nosotros lo llevamos, tú sigues llevando la comunidad.**",
  actualizado: ACTUALIZADO,
  bloques: [
    {
      tipo: "destacado",
      titulo: "El compromiso, primero",
      parrafos: [
        "**Jamás haremos administración de fincas.** No es una promesa comercial: va por escrito en el acuerdo de colaboración, porque sabemos que es lo primero que piensas y con razón.",
        "No tocamos tu relación con el cliente, no entramos en tu caja, no hablamos con tus comunidades sin ti. Convocas tú, presentamos nosotros, y el mérito del expediente que sale bien es de los dos.",
      ],
    },
    {
      tipo: "puntos",
      titulo: "Qué te quitas de encima",
      puntos: [
        {
          titulo: "El rastreo de convocatorias",
          texto:
            "Estatal, autonómica, municipal y certificados de ahorro energético, con sus plazos y su letra pequeña. Es un trabajo de seguimiento continuo que no factura.",
        },
        {
          titulo: "La comparación de presupuestos",
          texto:
            "Pliego comparable, 2-3 empresas solventes y un cuadro comparativo con criterio técnico. **Con tu empresa de confianza dentro del concurso**, si la tenéis.",
        },
        {
          titulo: "La junta difícil",
          texto:
            "Vamos y lo explicamos con números: qué ayudas hay, qué plazos corren y qué paga cada vecino al mes. Tú no tienes que defender una cifra que no has calculado.",
        },
        {
          titulo: "La justificación",
          texto:
            "La parte que más expedientes tumba y más tiempo consume, meses después de que la obra haya terminado.",
        },
      ],
    },
    {
      tipo: "texto",
      titulo: "Qué gana tu despacho",
      parrafos: [
        "Una comunidad que resuelve su ITE y baja su derrama **no cambia de administrador**. El expediente de rehabilitación bien llevado es, en la práctica, la mejor herramienta de retención que existe en tu sector.",
        "Y las obras avanzan: se acaban las juntas que aplazan la decisión un año más porque nadie ha puesto los números encima de la mesa.",
      ],
    },
    {
      tipo: "pasos",
      titulo: "Cómo empezamos",
      intro: "Sin exclusividad, sin cuota y sin compromiso de volumen:",
      pasos: [
        {
          titulo: "Una reunión de cartera",
          texto:
            "Media hora. Miramos juntos tus comunidades y marcamos **cuáles tienen expediente viable ahora** y cuáles pueden esperar.",
        },
        {
          titulo: "Pre-informe gratuito de las que elijas",
          texto:
            "Sin coste para ti ni para la comunidad. Tú decides a cuáles se lo presentamos y cuándo.",
        },
        {
          titulo: "Tú convocas, nosotros presentamos",
          texto:
            "En la junta que tú fijes. Si sale que sí, firmamos el mandato con la comunidad y arrancamos.",
        },
      ],
    },
    {
      tipo: "aviso",
      titulo: "Cómo cobramos, por si es lo que estás pensando",
      texto:
        "Nuestros honorarios los paga la comunidad y van ligados al cobro de la ayuda; la empresa adjudicataria nos paga una comisión por recibir la obra preparada, y está declarada por escrito en el mandato. Todo eso lo verás tú antes que nadie: es tu cliente, no queremos sorpresas en tu relación con él.",
    },
  ],
  faq: [
    {
      pregunta: "¿Tengo que firmar exclusividad?",
      respuesta:
        "No. Puedes probar con una comunidad y no volver a llamarnos. La colaboración se sostiene si te sirve, no por contrato.",
    },
    {
      pregunta: "¿Quién habla con los vecinos?",
      respuesta:
        "Nosotros solo en la junta y en lo que toque al expediente, y siempre contigo delante si lo prefieres. El día a día de la comunidad sigue siendo tuyo.",
    },
    {
      pregunta: "¿Y si la comunidad ya tiene técnico?",
      respuesta:
        "Mejor. No firmamos proyectos ni dirigimos obras: trabajamos con el técnico que la comunidad tenga o proponemos una terna si no tiene ninguno.",
    },
  ],
  cierre: {
    titulo: "Hablemos de tu cartera",
    texto:
      "Déjanos tu contacto y te llamamos para fijar media hora. Vienes con la lista de comunidades y sales con las que tienen expediente viable marcadas.",
  },
  prioridad: 0.8,
};

/* ——————————————————————————————————————————————————————————————
   05 · Agente, gestor o consultoría — la página del término
   —————————————————————————————————————————————————————————————— */

const agenteOGestor: Pagina = {
  ruta: "/agente-rehabilitador-o-gestor",
  nombre: "Agente, gestor o consultoría",
  titulo: "Agente rehabilitador, gestor o consultoría: quién hace qué",
  descripcion:
    "Las tres figuras que se ofrecen a una comunidad para gestionar su rehabilitación, en qué se diferencian de verdad y cuál conviene según el caso. Con el punto que casi nadie explica: la cesión del derecho de cobro.",
  cejilla: "Quién es quién",
  h1: "Agente rehabilitador, gestor o consultoría: quién hace qué",
  entradilla:
    "Tres nombres parecidos para tres cosas distintas, y a una junta le venden las tres con las mismas palabras. La diferencia real no está en el servicio: **está en quién asume la obra y quién cobra la subvención**.",
  actualizado: ACTUALIZADO,
  bloques: [
    {
      tipo: "tabla",
      titulo: "Las tres figuras, una al lado de la otra",
      intro:
        "A más alcance, más cosas resueltas de un tirón — y más responsabilidad concentrada en un solo proveedor:",
      cabeceras: ["", "Consultoría", "Gestor de la rehabilitación", "Agente rehabilitador"],
      filas: [
        ["Estudia y tramita las ayudas", "Sí", "Sí", "Sí"],
        ["Compara presupuestos de empresas", "Sí", "Sí", "Normalmente no: la obra es suya"],
        ["Solicita en nombre de la comunidad", "Con mandato expreso", "Sí", "Sí"],
        ["Redacta el proyecto", "No", "No", "Sí"],
        ["Dirige la obra", "No", "No", "Sí"],
        ["Suele pedir la cesión del derecho de cobro", "No", "No", "Sí, es su modelo habitual"],
      ],
      nota:
        "La figura del agente rehabilitador está recogida en el RD 853/2021 y las convocatorias admiten que un agente o gestor sea el solicitante, siempre que exista acuerdo del destinatario de la ayuda que le faculte para ello.",
    },
    {
      tipo: "texto",
      titulo: "El agente rehabilitador: llave en mano",
      parrafos: [
        "Es el modelo más ambicioso: una sola empresa redacta el proyecto, ejecuta o coordina la obra, tramita la ayuda y la justifica. Para una comunidad agotada, la propuesta es tentadora — **una firma y se acabó el problema**.",
        "El precio de esa comodidad es la concentración: quien fija el precio de la obra es el mismo que os asesora sobre si ese precio es razonable. No es ilegal ni deshonesto, pero **desaparece el contraste**, y con él la posibilidad de saber si podríais haber pagado menos.",
      ],
    },
    {
      tipo: "destacado",
      titulo: "El punto que casi nadie os explica: la cesión del derecho de cobro",
      parrafos: [
        "Muchos modelos llave en mano incluyen que la comunidad **ceda el derecho a cobrar la subvención** al agente, que la descuenta del precio de la obra. Sobre el papel es cómodo: la comunidad adelanta menos.",
        "Lo que se pierde es control. La ayuda ya no entra en la cuenta de la comunidad, y si el expediente se complica, la conversación sobre quién asume qué se da con el dinero ya comprometido en el otro lado. **Antes de firmar cualquier cesión, leed quién cobra qué y en qué orden.**",
      ],
    },
    {
      tipo: "puntos",
      titulo: "Cuál te conviene",
      intro: "No hay una respuesta única. Depende de tres cosas:",
      puntos: [
        {
          titulo: "Si la comunidad quiere delegarlo todo",
          texto:
            "Y acepta pagar por esa comodidad sin comparar precios, el agente llave en mano es la vía más rápida. Pedid al menos una segunda oferta antes de firmar.",
        },
        {
          titulo: "Si lo que falta es solo el expediente",
          texto:
            "Tenéis técnico, o tenéis empresa, y lo que se atasca es la ayuda: ahí sobra el llave en mano. **Necesitáis a alguien que tramite, no que construya.**",
        },
        {
          titulo: "Si nadie ha puesto los números encima de la mesa",
          texto:
            "Es el caso más común. Antes de elegir figura, haced el cálculo: coste, ayuda y cuota por vecino. Muchas decisiones cambian cuando aparece ese número.",
        },
      ],
    },
    {
      tipo: "texto",
      titulo: "Dónde encaja Cimenta",
      parrafos: [
        PUEDE_LLAMARSE_GESTOR
          ? "Somos consultoría, y actuamos como **gestor de la rehabilitación** del expediente cuando la junta nos da mandato expreso: estudiamos y tramitamos las ayudas, sacamos la obra a concurso entre empresas solventes y os acompañamos hasta el cobro."
          : "Somos **consultoría**: estudiamos y tramitamos las ayudas, sacamos la obra a concurso entre 2-3 empresas solventes y acompañamos el expediente hasta que el dinero entra. Cuando la junta nos da mandato expreso, podemos presentar la solicitud en nombre de la comunidad.",
        "Lo que no hacemos, y va por escrito: **no redactamos el proyecto, no dirigimos la obra y no pedimos nunca la cesión del derecho de cobro**. La subvención se ingresa siempre a nombre de la comunidad. Nuestros honorarios van ligados a que esa ayuda llegue.",
        "Es menos alcance que un agente rehabilitador, deliberadamente. A cambio, cuando os decimos que un presupuesto es caro, **no hay ninguna obra nuestra esperando detrás**.",
      ],
    },
  ],
  faq: [
    {
      pregunta: "¿Sois agente rehabilitador?",
      respuesta:
        "No. Un agente rehabilitador redacta el proyecto y dirige la obra, y su modelo suele ir ligado a la cesión del derecho de cobro de la subvención. Nosotros somos consultoría: tramitamos las ayudas y comparamos presupuestos, sin obra propia y sin tocar el cobro de la ayuda.",
    },
    {
      pregunta: "¿Podéis pedir la subvención en nombre de la comunidad?",
      respuesta:
        "Sí, cuando la junta lo acuerda expresamente y nos faculta por escrito en el mandato de gestión. Las convocatorias contemplan que la solicitud la presente un tercero con ese acuerdo del destinatario de la ayuda.",
    },
    {
      pregunta: "¿Es más caro contratar por separado?",
      respuesta:
        "Suele ser al revés. El llave en mano ahorra gestión, pero elimina la competencia entre empresas: el ahorro de sacar la obra a concurso casi siempre supera lo que cuesta la consultoría, y además queda por escrito quién cobra qué.",
    },
  ],
  cierre: {
    titulo: "¿Sigues sin tener claro qué necesita tu comunidad?",
    texto:
      "Pide el pre-informe. Te devolvemos los números de tu edificio y una recomendación honesta sobre el camino que os conviene — aunque no seamos nosotros.",
  },
  prioridad: 0.7,
};

/* —————————————————————————————————————————————————————————————— */

/**
 * Todas las páginas de aterrizaje, en el orden en que se enlazan.
 * El sitemap y el pie de página se generan desde aquí: añadir una
 * página a esta lista es lo único que hay que recordar.
 */
export const PAGINAS: Pagina[] = [
  planRehabilita,
  simuladorPagina,
  auditaTuOferta,
  administradores,
  agenteOGestor,
];

export const paginaPorRuta = (ruta: string) =>
  PAGINAS.find((pagina) => pagina.ruta === ruta);

/** Copy de la página de gracias, fuera del índice pero necesaria para medir. */
export const solicitudRecibida = {
  titulo: "Solicitud recibida",
  sello: "Solicitud registrada",
  h1: "Hecho. El pre-informe de tu edificio está en marcha.",
  entradilla:
    "Te responderemos en menos de 48 horas laborables con los primeros números. Si tenemos dudas sobre el edificio, te llamamos antes.",
  mientras: {
    titulo: "Mientras tanto",
    puntos: [
      {
        titulo: "Avisa a tu administrador",
        texto:
          "Trabajamos con él, no contra él. Cuanto antes lo sepa, antes podemos pedirle la documentación de la comunidad.",
        ruta: "/administradores-de-fincas",
        enlace: "Cómo trabajamos con administradores",
      },
      {
        titulo: "Mira el plazo que tienes",
        texto:
          "Si vais a por el Plan Rehabilita Madrid, la convocatoria de 2026 cierra el 30 de septiembre y el expediente lleva semanas.",
        ruta: "/plan-rehabilita-madrid",
        enlace: "Ver la convocatoria",
      },
      {
        titulo: "¿Tienes ya un presupuesto?",
        texto:
          "Si alguna empresa os ha pasado oferta, mándanosla: la auditamos gratis y va con el pre-informe.",
        ruta: "/audita-tu-oferta",
        enlace: "Cómo auditamos un presupuesto",
      },
    ],
  },
  volver: "Volver a la página principal",
};
