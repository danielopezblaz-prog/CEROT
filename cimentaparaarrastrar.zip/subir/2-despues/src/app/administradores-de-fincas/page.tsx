import type { Metadata } from "next";
import { paginaPorRuta } from "@/content-paginas";
import { metadatosDe } from "@/lib/metadatos";
import { Aterrizaje } from "@/components/paginas/Aterrizaje";

const pagina = paginaPorRuta("/administradores-de-fincas")!;

export const metadata: Metadata = metadatosDe(pagina);

export default function PaginaAdministradores() {
  return <Aterrizaje pagina={pagina} />;
}
