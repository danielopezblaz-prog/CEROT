import type { Metadata, Viewport } from "next";
import { hayDireccion, hayTelefono, marca, metadatos } from "@/content";
import { Analitica } from "@/components/Analitica";
import { Proveedores } from "@/components/Proveedores";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(marca.dominio),
  title: {
    default: metadatos.titulo,
    template: `%s — ${marca.nombre}`,
  },
  description: metadatos.descripcion,
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "es_ES",
    url: marca.dominio,
    siteName: marca.nombre,
    title: metadatos.titulo,
    description: metadatos.descripcion,
    images: [
      {
        url: "/og.png",
        type: "image/png",
        width: 1200,
        height: 630,
        alt: `${marca.nombre} — ${marca.claim}`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: metadatos.titulo,
    description: metadatos.descripcion,
    images: ["/og.png"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#f7f7f4",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

/* Datos estructurados: solo lo que es verdad hoy. El teléfono y la calle
   aparecen automáticamente en cuanto se rellenen en content.ts — y deben
   escribirse ahí exactamente igual que en el Perfil de Empresa en Google. */
const datosEstructurados = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: marca.nombre,
  slogan: marca.claim,
  description: metadatos.descripcion,
  url: marca.dominio,
  email: marca.email,
  image: `${marca.dominio}/og.png`,
  ...(hayTelefono() ? { telephone: marca.telefonoE164 || marca.telefono } : {}),
  address: {
    "@type": "PostalAddress",
    ...(hayDireccion()
      ? {
          streetAddress: marca.direccion.calle,
          postalCode: marca.direccion.codigoPostal,
        }
      : {}),
    addressLocality: marca.direccion.localidad,
    addressRegion: marca.direccion.region,
    addressCountry: marca.direccion.pais,
  },
  areaServed: marca.areaServicio.map((nombre) => ({ "@type": "City", name: nombre })),
  knowsAbout: [
    "Rehabilitación de edificios",
    "Subvenciones a la rehabilitación",
    "Comunidades de propietarios",
    "Eficiencia energética",
  ],
};

export default function DisposicionRaiz({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(datosEstructurados) }}
        />
        <Proveedores>{children}</Proveedores>
        <Analitica />
      </body>
    </html>
  );
}
