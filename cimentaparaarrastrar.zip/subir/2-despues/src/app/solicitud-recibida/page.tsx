import type { Metadata } from "next";
import Link from "next/link";
import { nav } from "@/content";
import { solicitudRecibida } from "@/content-paginas";
import { Nav } from "@/components/Nav";
import { PieDePagina } from "@/components/PieDePagina";

/**
 * Página de gracias con URL propia. Existe por dos razones:
 * medir conversiones de anuncios contra un destino estable, y evitar que
 * recargar la página reenvíe la solicitud.
 *
 * Fuera del índice: no es un resultado de búsqueda útil.
 */
export const metadata: Metadata = {
  title: solicitudRecibida.titulo,
  /* Propia, no la de la raíz que hereda del layout. */
  alternates: { canonical: "/solicitud-recibida" },
  robots: { index: false, follow: true },
};

export default function PaginaSolicitudRecibida() {
  return (
    <>
      <a
        href="#contenido"
        className="sr-only z-[60] rounded-lg bg-verde px-4 py-2 font-semibold text-white focus:not-sr-only focus:fixed focus:top-3 focus:left-3"
      >
        {nav.saltar}
      </a>
      <Nav base="/" />

      <main id="contenido" className="mx-auto max-w-[1120px] px-5 py-14 sm:px-8 sm:py-20">
        <div className="rounded-3xl border-2 border-dashed border-verde/50 bg-lavado p-7 sm:p-10">
          <p className="etiqueta-cota inline-block -rotate-2 rounded-md border-2 border-verde px-3 py-2 font-bold text-verde">
            {solicitudRecibida.sello}
          </p>
          <h1 className="mt-6 max-w-[20ch] text-[clamp(27px,4.8vw,40px)] leading-[1.08] font-extrabold tracking-display">
            {solicitudRecibida.h1}
          </h1>
          <p className="mt-4 max-w-[56ch] text-[16px] leading-relaxed text-gris">
            {solicitudRecibida.entradilla}
          </p>
        </div>

        <section className="mt-12">
          <h2 className="text-[clamp(20px,3.2vw,26px)] font-extrabold tracking-display">
            {solicitudRecibida.mientras.titulo}
          </h2>
          <ul className="mt-5 grid gap-3 sm:grid-cols-3">
            {solicitudRecibida.mientras.puntos.map((punto) => (
              <li
                key={punto.titulo}
                className="flex flex-col rounded-2xl border border-linea bg-superficie p-5"
              >
                <h3 className="text-[15px] font-bold tracking-display">
                  {punto.titulo}
                </h3>
                <p className="mt-1.5 grow text-[14px] leading-relaxed text-gris">
                  {punto.texto}
                </p>
                <Link
                  href={punto.ruta}
                  className="mt-3 rounded-md text-[13.5px] font-semibold text-verde hover:text-verde-oscuro"
                >
                  {punto.enlace} →
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <Link
          href="/"
          className="mt-10 inline-block rounded-full border border-linea-fuerte px-6 py-3 text-[14px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde"
        >
          ← {solicitudRecibida.volver}
        </Link>
      </main>

      <PieDePagina base="/" />
    </>
  );
}
