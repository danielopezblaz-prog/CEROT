import dynamic from "next/dynamic";
import { marca, metadatos, nav, preguntas } from "@/content";
import { sinMarcas } from "@/lib/texto";
import { BarraAvisos } from "@/components/BarraAvisos";
import { Nav } from "@/components/Nav";
import { Hero } from "@/components/hero/Hero";
import { Franja } from "@/components/Franja";
import { PieDePagina } from "@/components/PieDePagina";

/* Secciones bajo el pliegue: se sirven con SSR (SEO intacto) pero su
   JavaScript se trocea para no bloquear la hidratación inicial del hero. */
const Servicios = dynamic(() =>
  import("@/components/Servicios").then((m) => m.Servicios),
);
const Proceso = dynamic(() =>
  import("@/components/Proceso").then((m) => m.Proceso),
);
const Planes = dynamic(() =>
  import("@/components/Planes").then((m) => m.Planes),
);
const Simulador = dynamic(() =>
  import("@/components/Simulador").then((m) => m.Simulador),
);
const Transparencia = dynamic(() =>
  import("@/components/Transparencia").then((m) => m.Transparencia),
);
const Aliados = dynamic(() =>
  import("@/components/Aliados").then((m) => m.Aliados),
);
const Preguntas = dynamic(() =>
  import("@/components/Preguntas").then((m) => m.Preguntas),
);
const Formulario = dynamic(() =>
  import("@/components/Formulario").then((m) => m.Formulario),
);

const datosEstructurados = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "ProfessionalService",
      name: marca.nombre,
      description: metadatos.descripcion,
      email: marca.email,
      url: marca.dominio,
      areaServed: { "@type": "City", name: "Madrid" },
      address: { "@type": "PostalAddress", addressLocality: "Madrid", addressCountry: "ES" },
      knowsAbout: [
        "Rehabilitación de edificios",
        "Subvenciones a la rehabilitación",
        "Comunidades de propietarios",
      ],
    },
    {
      "@type": "FAQPage",
      mainEntity: preguntas.lista.map((elemento) => ({
        "@type": "Question",
        name: elemento.pregunta,
        acceptedAnswer: { "@type": "Answer", text: sinMarcas(elemento.respuesta) },
      })),
    },
  ],
};

export default function PaginaPrincipal() {
  return (
    <>
      <a
        href="#contenido"
        className="sr-only z-[60] rounded-lg bg-verde px-4 py-2 font-semibold text-white focus:not-sr-only focus:fixed focus:top-3 focus:left-3"
      >
        {nav.saltar}
      </a>
      <BarraAvisos />
      <Nav />
      <main id="contenido">
        <Hero />
        <Franja />
        <Servicios />
        <Proceso />
        <Planes />
        <Transparencia />
        <Simulador />
        <Formulario />
        <Aliados />
        <Preguntas />
      </main>
      <PieDePagina />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(datosEstructurados) }}
      />
    </>
  );
}
