import type { Metadata } from "next";
import { paginaPorRuta } from "@/content-paginas";
import { metadatosDe } from "@/lib/metadatos";
import { Aterrizaje } from "@/components/paginas/Aterrizaje";

const pagina = paginaPorRuta("/agente-rehabilitador-o-gestor")!;

export const metadata: Metadata = metadatosDe(pagina);

export default function PaginaAgenteOGestor() {
  return <Aterrizaje pagina={pagina} />;
}
