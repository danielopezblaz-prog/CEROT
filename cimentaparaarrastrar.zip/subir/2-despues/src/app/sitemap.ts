import type { MetadataRoute } from "next";
import { marca, pie } from "@/content";
import { PAGINAS } from "@/content-paginas";

/**
 * Todo lo público y indexable. Las páginas de aterrizaje salen solas de
 * PAGINAS, así que crear una nueva no obliga a acordarse de este archivo.
 *
 * Fuera quedan a propósito: /solicitud-recibida (página de gracias, no
 * es un resultado de búsqueda útil) y todo /crm.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const revisado = new Date();

  return [
    {
      url: marca.dominio,
      lastModified: revisado,
      changeFrequency: "weekly",
      priority: 1,
    },
    ...PAGINAS.map((pagina) => ({
      url: `${marca.dominio}${pagina.ruta}`,
      lastModified: revisado,
      changeFrequency: "monthly" as const,
      priority: pagina.prioridad,
    })),
    /* Las legales sí se indexan: para un servicio son señal de confianza. */
    ...pie.enlacesLegales.map((enlace) => ({
      url: `${marca.dominio}${enlace.ruta}`,
      lastModified: revisado,
      changeFrequency: "yearly" as const,
      priority: 0.3,
    })),
  ];
}
