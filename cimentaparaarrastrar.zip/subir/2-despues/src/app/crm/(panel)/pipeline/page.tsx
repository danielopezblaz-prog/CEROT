import Link from "next/link";
import { exigirUsuario } from "@/lib/crm/sesion";
import { listarComerciales } from "@/lib/crm/leads";
import { tableroPipeline } from "@/lib/crm/pipeline";
import { FUENTES } from "@/db/catalogo";
import { Tablero } from "./Tablero";

export const dynamic = "force-dynamic";

const claseCampo =
  "rounded-xl border border-linea-fuerte bg-superficie px-3 py-2 text-[13px] text-tinta focus-visible:outline-2 focus-visible:outline-verde";

export default async function PaginaPipeline({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await exigirUsuario();
  const parametros = await searchParams;
  const uno = (clave: string) => {
    const valor = parametros[clave];
    return typeof valor === "string" && valor ? valor : undefined;
  };
  const filtros = {
    q: uno("q"),
    comercial: uno("comercial"),
    fuente: uno("fuente"),
    desde: uno("desde"),
    hasta: uno("hasta"),
  };
  const columnas = tableroPipeline(filtros);
  const comerciales = listarComerciales();
  const totalTablero = columnas.reduce((suma, columna) => suma + columna.total, 0);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="etiqueta-cota text-verde">Pipeline</p>
          <h1 className="mt-1 text-[24px] font-extrabold tracking-display">
            El embudo, de un vistazo
          </h1>
        </div>
        <p className="font-mono text-[10px] tracking-[0.1em] text-gris uppercase">
          {totalTablero} leads en el tablero
        </p>
      </div>

      <form method="GET" className="mt-4 flex flex-wrap items-end gap-2.5 rounded-3xl border border-linea bg-superficie p-4">
        <div className="min-w-[200px] flex-1">
          <label htmlFor="p-q" className="mb-1 block font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase">
            Buscar
          </label>
          <input id="p-q" name="q" type="search" defaultValue={filtros.q ?? ""} placeholder="Nombre, contacto o dirección" className={`${claseCampo} w-full`} />
        </div>
        <div>
          <label htmlFor="p-comercial" className="mb-1 block font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase">
            Comercial
          </label>
          <select id="p-comercial" name="comercial" defaultValue={filtros.comercial ?? ""} className={claseCampo}>
            <option value="">Cualquiera</option>
            {comerciales.map((comercial) => (
              <option key={comercial.id} value={comercial.id}>{comercial.nombre}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="p-fuente" className="mb-1 block font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase">
            Fuente
          </label>
          <select id="p-fuente" name="fuente" defaultValue={filtros.fuente ?? ""} className={claseCampo}>
            <option value="">Todas</option>
            {FUENTES.map((fuente) => (
              <option key={fuente.clave} value={fuente.clave}>{fuente.nombre}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="p-desde" className="mb-1 block font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase">
            Desde
          </label>
          <input id="p-desde" name="desde" type="date" defaultValue={filtros.desde ?? ""} className={claseCampo} />
        </div>
        <div>
          <label htmlFor="p-hasta" className="mb-1 block font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase">
            Hasta
          </label>
          <input id="p-hasta" name="hasta" type="date" defaultValue={filtros.hasta ?? ""} className={claseCampo} />
        </div>
        <button type="submit" className="rounded-full bg-verde px-5 py-2 text-[13px] font-semibold text-white transition-colors hover:bg-verde-oscuro">
          Filtrar
        </button>
        <Link href="/crm/pipeline" className="rounded-full border border-linea-fuerte px-4 py-2 text-[13px] font-semibold text-gris hover:border-verde hover:text-verde">
          Limpiar
        </Link>
      </form>

      <div className="mt-4">
        <Tablero columnas={columnas} />
      </div>
      <p className="mt-1 font-mono text-[9px] tracking-[0.1em] text-gris uppercase">
        Arrastra las tarjetas entre columnas · cada movimiento queda en el historial del lead
      </p>
    </div>
  );
}
