"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { ESTADOS_LEAD, type ClaveEstadoLead } from "@/db/catalogo";
import type { ColumnaPipeline, TarjetaPipeline } from "@/lib/crm/pipeline";
import { accionCambiarEstado } from "../leads/acciones";

function eurosCortos(cantidad: number): string {
  if (cantidad >= 1_000_000) return `${(cantidad / 1_000_000).toFixed(1)} M€`;
  if (cantidad >= 1_000) return `${Math.round(cantidad / 1_000)} k€`;
  return `${cantidad} €`;
}

function Tarjeta({
  tarjeta,
  alMover,
  arrastrando,
}: {
  tarjeta: TarjetaPipeline;
  alMover: (leadId: number, destino: ClaveEstadoLead) => void;
  arrastrando: (leadId: number | null) => void;
}) {
  return (
    <article
      draggable
      onDragStart={(evento) => {
        evento.dataTransfer.setData("text/plain", String(tarjeta.id));
        evento.dataTransfer.effectAllowed = "move";
        arrastrando(tarjeta.id);
      }}
      onDragEnd={() => arrastrando(null)}
      className="cursor-grab rounded-2xl border border-linea bg-superficie p-3 shadow-[0_2px_10px_rgba(24,33,28,.05)] active:cursor-grabbing"
    >
      <div className="flex items-start justify-between gap-2">
        <Link
          href={`/crm/leads/${tarjeta.id}`}
          className="text-[13px] leading-snug font-semibold text-tinta hover:text-verde"
        >
          {tarjeta.nombre}
        </Link>
        {tarjeta.prioridad === "alta" && (
          <span aria-label="Prioridad alta" className="mt-0.5 inline-block h-2 w-2 shrink-0 rounded-full bg-verde" />
        )}
      </div>
      {tarjeta.direccion && (
        <p className="mt-1 truncate text-[11px] text-gris">{tarjeta.direccion}</p>
      )}
      <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 font-mono text-[8.5px] tracking-[0.08em] text-gris uppercase">
        {tarjeta.valorEstimado !== null && (
          <span className="font-bold text-verde">{eurosCortos(tarjeta.valorEstimado)}</span>
        )}
        {tarjeta.comercial && <span>· {tarjeta.comercial.split(" ")[0]}</span>}
        {tarjeta.seguimientoVencido && (
          <span className="font-bold text-[#8a5b5b]">· vencido</span>
        )}
      </div>
      {/* alternativa accesible y táctil al arrastre */}
      <label className="sr-only" htmlFor={`mover-${tarjeta.id}`}>
        Mover {tarjeta.nombre} a otro estado
      </label>
      <select
        id={`mover-${tarjeta.id}`}
        className="mt-2 w-full rounded-lg border border-linea bg-papel px-2 py-1 text-[11px] text-gris lg:hidden"
        value=""
        onChange={(evento) => {
          if (evento.target.value) alMover(tarjeta.id, evento.target.value as ClaveEstadoLead);
        }}
      >
        <option value="">Mover a…</option>
        {ESTADOS_LEAD.map((estado) => (
          <option key={estado.clave} value={estado.clave}>
            {estado.nombre}
          </option>
        ))}
      </select>
    </article>
  );
}

export function Tablero({ columnas }: { columnas: ColumnaPipeline[] }) {
  const [tablero, setTablero] = useState(columnas);
  const [sobre, setSobre] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [, transicion] = useTransition();
  const [arrastrandoId, setArrastrandoId] = useState<number | null>(null);

  /* el servidor manda: cuando llegan columnas revalidadas, el tablero se realinea
     (patrón oficial de ajuste de estado durante el render) */
  const [columnasPrevias, setColumnasPrevias] = useState(columnas);
  if (columnasPrevias !== columnas) {
    setColumnasPrevias(columnas);
    setTablero(columnas);
  }

  const mover = (leadId: number, destino: ClaveEstadoLead) => {
    const anterior = tablero;
    const origen = anterior.find((columna) =>
      columna.tarjetas.some((tarjeta) => tarjeta.id === leadId),
    );
    if (!origen || origen.estado.clave === destino) return;
    const tarjeta = origen.tarjetas.find((t) => t.id === leadId)!;

    /* optimista: mover ya, revertir si el servidor falla */
    setTablero((actual) =>
      actual.map((columna) => {
        if (columna.estado.clave === origen.estado.clave) {
          const tarjetas = columna.tarjetas.filter((t) => t.id !== leadId);
          return {
            ...columna,
            tarjetas,
            total: tarjetas.length,
            valor: columna.valor - (tarjeta.valorEstimado ?? 0),
          };
        }
        if (columna.estado.clave === destino) {
          const tarjetas = [...columna.tarjetas, tarjeta];
          return {
            ...columna,
            tarjetas,
            total: tarjetas.length,
            valor: columna.valor + (tarjeta.valorEstimado ?? 0),
          };
        }
        return columna;
      }),
    );
    setError(null);

    const datos = new FormData();
    datos.set("leadId", String(leadId));
    datos.set("estado", destino);
    transicion(async () => {
      try {
        await accionCambiarEstado(datos);
      } catch {
        setTablero(anterior);
        setError(`No se pudo mover «${tarjeta.nombre}». Se ha revertido el cambio.`);
      }
    });
  };

  return (
    <div>
      {error && (
        <p role="alert" className="mb-3 rounded-xl border border-[#8a5b5b]/50 bg-[#8a5b5b]/10 px-4 py-2.5 text-[13px] font-medium text-[#6d4747]">
          {error}
        </p>
      )}
      <div className="flex snap-x gap-3 overflow-x-auto pb-4">
        {tablero.map((columna) => (
          <section
            key={columna.estado.clave}
            aria-label={`Columna ${columna.estado.nombre}`}
            onDragOver={(evento) => {
              evento.preventDefault();
              evento.dataTransfer.dropEffect = "move";
              setSobre(columna.estado.clave);
            }}
            onDragLeave={() => setSobre(null)}
            onDrop={(evento) => {
              evento.preventDefault();
              setSobre(null);
              const leadId = Number(evento.dataTransfer.getData("text/plain"));
              if (Number.isInteger(leadId)) mover(leadId, columna.estado.clave);
            }}
            className={`w-[240px] shrink-0 snap-start rounded-2xl border p-2.5 transition-colors ${
              sobre === columna.estado.clave && arrastrandoId !== null
                ? "border-verde bg-lavado"
                : "border-linea bg-papel"
            }`}
          >
            <header className="flex items-center justify-between gap-2 px-1 pb-2">
              <div className="flex items-center gap-2">
                <span
                  aria-hidden="true"
                  className="inline-block h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: columna.estado.color }}
                />
                <h2 className="text-[12px] font-bold tracking-display">{columna.estado.nombre}</h2>
              </div>
              <p className="font-mono text-[9px] tracking-[0.08em] text-gris uppercase">
                {columna.total}
                {columna.valor > 0 && ` · ${eurosCortos(columna.valor)}`}
              </p>
            </header>
            <div className="grid min-h-[60px] gap-2">
              {columna.tarjetas.map((tarjeta) => (
                <Tarjeta
                  key={tarjeta.id}
                  tarjeta={tarjeta}
                  alMover={mover}
                  arrastrando={setArrastrandoId}
                />
              ))}
              {columna.tarjetas.length === 0 && (
                <p className="rounded-xl border border-dashed border-linea-fuerte px-3 py-4 text-center font-mono text-[9px] tracking-[0.1em] text-gris uppercase">
                  Vacío
                </p>
              )}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
