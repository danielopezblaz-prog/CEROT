import { exigirUsuario } from "@/lib/crm/sesion";
import { FormulariosAjustes } from "./FormulariosAjustes";

export const dynamic = "force-dynamic";

export default async function PaginaAjustes() {
  const usuario = await exigirUsuario();

  return (
    <div>
      <p className="etiqueta-cota text-verde">Ajustes</p>
      <h1 className="mt-1 text-[24px] font-extrabold tracking-display">Tu cuenta</h1>
      <p className="mt-1 text-[13.5px] text-gris">
        {usuario.email} · rol: {usuario.rol === "admin" ? "administración" : "comercial"}
      </p>
      <div className="mt-5 max-w-[520px]">
        <FormulariosAjustes nombreActual={usuario.nombre} />
      </div>
    </div>
  );
}
