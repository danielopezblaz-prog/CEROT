"use client";

import { useActionState } from "react";
import {
  accionMiContrasena,
  accionMiPerfil,
  type EstadoAjustes,
} from "../usuarios/acciones";

const claseCampo =
  "w-full rounded-xl border border-linea-fuerte bg-superficie px-3 py-2.5 text-[14px] focus-visible:outline-2 focus-visible:outline-verde";
const claseEtiqueta = "mb-1 block font-mono text-[8.5px] uppercase tracking-[0.14em] text-gris";

function Mensaje({ estado }: { estado: EstadoAjustes }) {
  if (!estado) return null;
  if (estado.error) {
    return (
      <p role="alert" className="rounded-xl border border-[#8a5b5b]/50 bg-[#8a5b5b]/10 px-3.5 py-2 text-[13px] font-medium text-[#6d4747]">
        {estado.error}
      </p>
    );
  }
  return (
    <p className="rounded-xl border border-verde/40 bg-lavado px-3.5 py-2 text-[13px] font-medium text-verde-oscuro">
      {estado.hecho}
    </p>
  );
}

export function FormulariosAjustes({ nombreActual }: { nombreActual: string }) {
  const [estadoPerfil, enviarPerfil, perfilPendiente] = useActionState<EstadoAjustes, FormData>(
    accionMiPerfil,
    undefined,
  );
  const [estadoClave, enviarClave, clavePendiente] = useActionState<EstadoAjustes, FormData>(
    accionMiContrasena,
    undefined,
  );

  return (
    <div className="grid gap-5">
      <section className="rounded-3xl border border-linea bg-superficie p-5">
        <h2 className="font-mono text-[9px] tracking-[0.14em] text-verde uppercase">Datos propios</h2>
        <form action={enviarPerfil} className="mt-3 grid gap-3">
          <div>
            <label htmlFor="a-nombre" className={claseEtiqueta}>Nombre</label>
            <input id="a-nombre" name="nombre" defaultValue={nombreActual} required className={claseCampo} />
          </div>
          <Mensaje estado={estadoPerfil} />
          <button
            type="submit"
            disabled={perfilPendiente}
            className="justify-self-start rounded-full bg-verde px-5 py-2 text-[13.5px] font-semibold text-white transition-colors hover:bg-verde-oscuro disabled:opacity-60"
          >
            {perfilPendiente ? "Guardando…" : "Guardar"}
          </button>
        </form>
      </section>

      <section className="rounded-3xl border border-linea bg-superficie p-5">
        <h2 className="font-mono text-[9px] tracking-[0.14em] text-verde uppercase">Cambiar contraseña</h2>
        <form action={enviarClave} className="mt-3 grid gap-3">
          <div>
            <label htmlFor="a-actual" className={claseEtiqueta}>Contraseña actual</label>
            <input id="a-actual" name="actual" type="password" autoComplete="current-password" required className={claseCampo} />
          </div>
          <div>
            <label htmlFor="a-nueva" className={claseEtiqueta}>Nueva contraseña</label>
            <input id="a-nueva" name="nueva" type="password" autoComplete="new-password" required minLength={10} placeholder="Mínimo 10 caracteres" className={claseCampo} />
          </div>
          <Mensaje estado={estadoClave} />
          <button
            type="submit"
            disabled={clavePendiente}
            className="justify-self-start rounded-full bg-verde px-5 py-2 text-[13.5px] font-semibold text-white transition-colors hover:bg-verde-oscuro disabled:opacity-60"
          >
            {clavePendiente ? "Cambiando…" : "Cambiar contraseña"}
          </button>
        </form>
      </section>
    </div>
  );
}
