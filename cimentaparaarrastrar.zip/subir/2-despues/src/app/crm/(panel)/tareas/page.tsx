import Link from "next/link";
import { exigirUsuario } from "@/lib/crm/sesion";
import { listarTareas, type AmbitoTareas } from "@/lib/crm/tareas";
import { fechaYHora, estaVencida } from "@/lib/crm/fechas";
import { ESTADOS_TAREA, TIPOS_TAREA } from "@/db/catalogo";
import { ChipEstado, VistaVacia } from "@/components/crm/Ui";
import { accionEstadoTarea } from "../leads/acciones";

export const dynamic = "force-dynamic";

const AMBITOS: { clave: AmbitoTareas; nombre: string }[] = [
  { clave: "hoy", nombre: "Hoy" },
  { clave: "vencidas", nombre: "Vencidas" },
  { clave: "proximas", nombre: "Próximas" },
];

export default async function PaginaTareas({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const usuario = await exigirUsuario();
  const parametros = await searchParams;
  const ambitoBruto = typeof parametros.ambito === "string" ? parametros.ambito : "hoy";
  const ambito: AmbitoTareas = (["hoy", "vencidas", "proximas"] as const).includes(
    ambitoBruto as AmbitoTareas,
  )
    ? (ambitoBruto as AmbitoTareas)
    : "hoy";
  const soloMias = parametros.mias === "1";

  const tareas = listarTareas(ambito, soloMias ? usuario.id : undefined);

  const enlace = (destino: AmbitoTareas, mias: boolean) =>
    `/crm/tareas?ambito=${destino}${mias ? "&mias=1" : ""}`;

  return (
    <div>
      <p className="etiqueta-cota text-verde">Tareas</p>
      <h1 className="mt-1 text-[24px] font-extrabold tracking-display">
        Seguimientos del equipo
      </h1>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        {AMBITOS.map((opcion) => (
          <Link
            key={opcion.clave}
            href={enlace(opcion.clave, soloMias)}
            aria-current={ambito === opcion.clave ? "true" : undefined}
            className={`etiqueta-cota rounded-full border px-3.5 py-1.5 text-[9px] transition-colors ${
              ambito === opcion.clave
                ? "border-verde bg-verde text-white"
                : "border-linea-fuerte text-gris hover:border-verde hover:text-verde"
            }`}
          >
            {opcion.nombre}
          </Link>
        ))}
        <span className="mx-1 h-4 w-px bg-linea-fuerte" aria-hidden="true" />
        <Link
          href={enlace(ambito, !soloMias)}
          aria-current={soloMias ? "true" : undefined}
          className={`etiqueta-cota rounded-full border px-3.5 py-1.5 text-[9px] transition-colors ${
            soloMias
              ? "border-verde bg-verde text-white"
              : "border-linea-fuerte text-gris hover:border-verde hover:text-verde"
          }`}
        >
          Solo las mías
        </Link>
      </div>

      <div className="mt-4">
        {tareas.length === 0 ? (
          <VistaVacia
            titulo={
              ambito === "vencidas"
                ? "Nada vencido — así se hace"
                : ambito === "hoy"
                  ? "Hoy no hay tareas programadas"
                  : "Sin tareas próximas"
            }
            texto="Las tareas se crean desde la ficha de cada lead y aparecen aquí ordenadas por vencimiento."
          />
        ) : (
          <ul className="grid gap-2.5">
            {tareas.map(({ tarea, lead, responsable }) => (
              <li
                key={tarea.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-linea bg-superficie px-4 py-3"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-[14px] font-semibold text-tinta">{tarea.titulo}</p>
                    <span className="etiqueta-cota rounded-full bg-malla-suave px-2 py-0.5 text-[8px] text-verde">
                      {TIPOS_TAREA.find((tipo) => tipo.clave === tarea.tipo)?.nombre ?? tarea.tipo}
                    </span>
                  </div>
                  <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[9px] tracking-[0.1em] text-gris uppercase">
                    <span
                      className={
                        estaVencida(tarea.venceEn) && tarea.estado === "pendiente"
                          ? "font-bold text-[#8a5b5b]"
                          : ""
                      }
                    >
                      {fechaYHora(tarea.venceEn)}
                    </span>
                    <span>· {responsable ?? "—"} ·</span>
                    <Link href={`/crm/leads/${lead.id}`} className="normal-case underline-offset-2 hover:text-verde hover:underline">
                      {lead.nombre}
                    </Link>
                    <ChipEstado clave={lead.estado} />
                  </p>
                </div>
                <form action={accionEstadoTarea} className="flex items-center gap-2">
                  <input type="hidden" name="tareaId" value={tarea.id} />
                  <input type="hidden" name="leadId" value={lead.id} />
                  <select
                    name="estado"
                    defaultValue={tarea.estado}
                    aria-label={`Estado de la tarea ${tarea.titulo}`}
                    className="rounded-lg border border-linea bg-superficie px-2 py-1.5 text-[12px]"
                  >
                    {ESTADOS_TAREA.map((estado) => (
                      <option key={estado.clave} value={estado.clave}>
                        {estado.nombre}
                      </option>
                    ))}
                  </select>
                  <button
                    type="submit"
                    className="rounded-full bg-verde px-3.5 py-1.5 text-[12px] font-semibold text-white transition-colors hover:bg-verde-oscuro"
                  >
                    Aplicar
                  </button>
                </form>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
