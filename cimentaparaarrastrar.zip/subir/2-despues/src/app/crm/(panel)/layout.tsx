import type { Metadata } from "next";
import Link from "next/link";
import { exigirUsuario } from "@/lib/crm/sesion";
import { cerrarSesion } from "@/lib/crm/autenticacion";
import { MarcaLogo } from "@/components/Compartidos";
import { NavEscritorio, NavMovil } from "@/components/crm/BarraLateral";

export const metadata: Metadata = {
  title: "CRM · Cimenta",
  robots: { index: false, follow: false },
};

/** Cascarón del panel: cabecera + barra lateral. Sesión exigida en servidor. */
export default async function PanelLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const usuario = await exigirUsuario();

  return (
    <div className="min-h-svh bg-papel">
      <header className="relative z-40 border-b border-linea bg-superficie">
        <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link href="/crm" className="flex items-center gap-3">
            <MarcaLogo tamano={32} />
            <span className="leading-none">
              <span className="block text-[17px] font-extrabold tracking-display text-tinta">
                Cimenta
              </span>
              <span className="mt-0.5 block font-mono text-[8px] tracking-[0.16em] text-gris uppercase">
                CRM de leads
              </span>
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <p className="hidden font-mono text-[10px] tracking-[0.12em] text-gris uppercase md:block">
              {usuario.nombre} · {usuario.rol === "admin" ? "administración" : "comercial"}
            </p>
            <form action={cerrarSesion}>
              <button
                type="submit"
                className="rounded-full border border-linea-fuerte px-4 py-2 text-[13px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde"
              >
                Salir
              </button>
            </form>
            <NavMovil esAdmin={usuario.rol === "admin"} />
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1400px] gap-8 px-4 py-6 sm:px-6 lg:py-8">
        <div className="hidden lg:block lg:w-[210px] lg:shrink-0">
          <NavEscritorio esAdmin={usuario.rol === "admin"} />
        </div>
        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  );
}
