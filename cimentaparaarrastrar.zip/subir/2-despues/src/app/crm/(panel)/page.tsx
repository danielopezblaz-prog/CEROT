import Link from "next/link";
import { exigirUsuario } from "@/lib/crm/sesion";
import {
  conversionPorComercial,
  kpis,
  porCampana,
  porEstado,
  porFuente,
  resolverRango,
  seriePorDia,
  type ClaveRango,
} from "@/lib/crm/metricas";
import { euros, fechaLarga } from "@/lib/crm/fechas";
import {
  BarrasH,
  Kpi,
  LineaTemporal,
  TarjetaGrafica,
  VacioGrafica,
} from "@/components/crm/Graficas";

export const dynamic = "force-dynamic";

const RANGOS: { clave: ClaveRango; nombre: string }[] = [
  { clave: "hoy", nombre: "Hoy" },
  { clave: "7d", nombre: "7 días" },
  { clave: "30d", nombre: "30 días" },
  { clave: "mes", nombre: "Este mes" },
  { clave: "mes_anterior", nombre: "Mes anterior" },
  { clave: "anio", nombre: "Este año" },
];

export default async function PaginaPanel({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const usuario = await exigirUsuario();
  const parametros = await searchParams;
  const rango = resolverRango(parametros);

  const indicadores = kpis(rango);
  const serie = seriePorDia(rango);
  const estados = porEstado(rango);
  const fuentes = porFuente(rango);
  const campanas = porCampana(rango);
  const comerciales = conversionPorComercial(rango);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="etiqueta-cota text-verde">Panel</p>
          <h1 className="mt-1 text-[24px] font-extrabold tracking-display">
            Hola, {usuario.nombre.split(" ")[0]}
          </h1>
          <p className="mt-1 font-mono text-[9.5px] tracking-[0.1em] text-gris uppercase">
            Periodo: {fechaLarga(rango.inicio)} — {fechaLarga(rango.fin)}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {RANGOS.map((opcion) => (
            <Link
              key={opcion.clave}
              href={`/crm?rango=${opcion.clave}`}
              aria-current={rango.clave === opcion.clave ? "true" : undefined}
              className={`etiqueta-cota rounded-full border px-3 py-1.5 text-[8.5px] transition-colors ${
                rango.clave === opcion.clave
                  ? "border-verde bg-verde text-white"
                  : "border-linea-fuerte text-gris hover:border-verde hover:text-verde"
              }`}
            >
              {opcion.nombre}
            </Link>
          ))}
          <form method="GET" className="flex items-center gap-1.5">
            <input type="hidden" name="rango" value="personalizado" />
            <label className="sr-only" htmlFor="rango-desde">Desde</label>
            <input
              id="rango-desde"
              name="desde"
              type="date"
              required
              defaultValue={typeof parametros.desde === "string" ? parametros.desde : ""}
              className="rounded-lg border border-linea-fuerte bg-superficie px-2 py-1 text-[11.5px]"
            />
            <label className="sr-only" htmlFor="rango-hasta">Hasta</label>
            <input
              id="rango-hasta"
              name="hasta"
              type="date"
              defaultValue={typeof parametros.hasta === "string" ? parametros.hasta : ""}
              className="rounded-lg border border-linea-fuerte bg-superficie px-2 py-1 text-[11.5px]"
            />
            <button
              type="submit"
              className={`etiqueta-cota rounded-full border px-3 py-1.5 text-[8.5px] ${
                rango.clave === "personalizado"
                  ? "border-verde bg-verde text-white"
                  : "border-linea-fuerte text-gris hover:border-verde hover:text-verde"
              }`}
            >
              Aplicar
            </button>
          </form>
        </div>
      </div>

      {/* ————— KPIs ————— */}
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
        <Kpi valor={indicadores.hoy} etiqueta="Leads hoy" />
        <Kpi valor={indicadores.semana} etiqueta="Últimos 7 días" />
        <Kpi valor={indicadores.mes} etiqueta="Este mes" />
        <Kpi
          valor={indicadores.sinContactar}
          etiqueta="Sin contactar"
          alerta={indicadores.sinContactar > 0}
        />
        <Kpi
          valor={indicadores.seguimientosVencidos}
          etiqueta="Seguimientos vencidos"
          alerta={indicadores.seguimientosVencidos > 0}
        />
        <Kpi valor={indicadores.sinAsignar} etiqueta="Sin asignar" alerta={indicadores.sinAsignar > 0} />
        <Kpi valor={indicadores.nuevosRango} etiqueta="Nuevos en el periodo" />
        <Kpi valor={indicadores.ganadosRango} etiqueta="Mandatos firmados" />
        <Kpi valor={indicadores.perdidosRango} etiqueta="Perdidos" />
        <Kpi
          valor={indicadores.conversionRango === null ? "—" : `${indicadores.conversionRango} %`}
          etiqueta="Conversión de cierres"
        />
      </div>

      <p className="mt-3 rounded-2xl border border-linea bg-superficie px-4 py-3 font-mono text-[10px] tracking-[0.1em] text-gris uppercase">
        Valor estimado del pipeline abierto:{" "}
        <strong className="text-[13px] font-bold text-verde">{euros(indicadores.valorPipeline)}</strong>
      </p>

      {/* ————— Gráficos ————— */}
      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <TarjetaGrafica titulo="Evolución de leads en el periodo">
          <LineaTemporal datos={serie} />
        </TarjetaGrafica>
        <TarjetaGrafica titulo="Leads por estado (creados en el periodo)">
          <BarrasH
            filas={estados.map((estado) => ({
              etiqueta: estado.nombre,
              valor: estado.total,
              punto: estado.color,
            }))}
          />
        </TarjetaGrafica>
        <TarjetaGrafica titulo="Leads por fuente">
          <BarrasH filas={fuentes.map((fuente) => ({ etiqueta: fuente.nombre, valor: fuente.total }))} />
        </TarjetaGrafica>
        <TarjetaGrafica titulo="Conversión por comercial (leads del periodo)">
          <BarrasH
            filas={comerciales.map((comercial) => ({
              etiqueta: comercial.nombre,
              valor: comercial.pct,
            }))}
            formato={(valor) => `${valor} %`}
            maximo={100}
          />
        </TarjetaGrafica>
      </div>

      {/* ————— Atribución de campañas —————
          Sale de los UTM que guarda cada lead: no hace falta ningún píxel
          en la web. Cruza esta tabla con el gasto de cada campaña y tienes
          el coste por mandato firmado. */}
      <section className="mt-5 rounded-3xl border border-linea bg-superficie p-5">
        <h2 className="font-mono text-[9px] tracking-[0.14em] text-verde uppercase">
          Atribución por campaña (leads creados en el periodo)
        </h2>
        <div className="mt-4">
          {campanas.length === 0 ? (
            <VacioGrafica texto="Sin leads en el periodo" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px] border-collapse text-[13px]">
                <thead>
                  <tr>
                    {["Origen", "Campaña", "Medio", "Leads", "Mandatos", "Conversión"].map(
                      (cabecera, indice) => (
                        <th
                          key={cabecera}
                          scope="col"
                          className={`border-b border-linea pb-2 font-mono text-[8.5px] tracking-[0.12em] text-gris uppercase ${
                            indice > 2 ? "text-right" : "text-left"
                          }`}
                        >
                          {cabecera}
                        </th>
                      ),
                    )}
                  </tr>
                </thead>
                <tbody>
                  {campanas.map((fila) => (
                    <tr
                      key={`${fila.fuente}-${fila.campana}`}
                      className="border-b border-linea last:border-0"
                    >
                      <td className="py-2.5 font-semibold text-tinta">{fila.fuente}</td>
                      <td className="py-2.5 text-gris">{fila.campana}</td>
                      <td className="py-2.5 text-gris">{fila.medio}</td>
                      <td className="py-2.5 text-right font-mono tabular-nums">
                        {fila.total}
                      </td>
                      <td className="py-2.5 text-right font-mono font-bold text-verde tabular-nums">
                        {fila.ganados}
                      </td>
                      <td className="py-2.5 text-right font-mono text-gris tabular-nums">
                        {fila.conversion === null ? "—" : `${fila.conversion} %`}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <p className="mt-3 font-mono text-[9px] leading-relaxed tracking-[0.08em] text-gris uppercase">
          La conversión se calcula sobre los leads ya cerrados del periodo, no
          sobre el total: los abiertos todavía no han pasado por junta.
        </p>
      </section>

      <div className="mt-5 flex flex-wrap gap-2">
        <Link href="/crm/leads?especial=sin_contactar" className="rounded-full border border-linea-fuerte px-4 py-2 text-[13px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde">
          Ver sin contactar →
        </Link>
        <Link href="/crm/leads?especial=seguimiento_vencido" className="rounded-full border border-linea-fuerte px-4 py-2 text-[13px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde">
          Ver seguimientos vencidos →
        </Link>
        <Link href="/crm/pipeline" className="rounded-full bg-verde px-4 py-2 text-[13px] font-semibold text-white transition-colors hover:bg-verde-oscuro">
          Abrir el pipeline →
        </Link>
      </div>
    </div>
  );
}
