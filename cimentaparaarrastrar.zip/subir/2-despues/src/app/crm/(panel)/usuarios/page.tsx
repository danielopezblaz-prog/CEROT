import { exigirAdmin } from "@/lib/crm/sesion";
import { listarUsuarios } from "@/lib/crm/usuarios";
import { ROLES_USUARIO } from "@/db/catalogo";
import { fechaLarga } from "@/lib/crm/fechas";
import {
  accionAlternarActivo,
  accionActualizarUsuario,
  accionCrearUsuario,
} from "./acciones";

export const dynamic = "force-dynamic";

const claseCampo =
  "w-full rounded-xl border border-linea-fuerte bg-superficie px-3 py-2 text-[13.5px] focus-visible:outline-2 focus-visible:outline-verde";
const claseEtiqueta = "mb-1 block font-mono text-[8.5px] uppercase tracking-[0.14em] text-gris";

export default async function PaginaUsuarios({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const admin = await exigirAdmin();
  const parametros = await searchParams;
  const error = typeof parametros.error === "string" ? parametros.error : null;
  const hecho = typeof parametros.hecho === "string";
  const usuarios = listarUsuarios();

  return (
    <div>
      <p className="etiqueta-cota text-verde">Usuarios</p>
      <h1 className="mt-1 text-[24px] font-extrabold tracking-display">Equipo del CRM</h1>

      {error && (
        <p role="alert" className="mt-3 rounded-xl border border-[#8a5b5b]/50 bg-[#8a5b5b]/10 px-4 py-2.5 text-[13px] font-medium text-[#6d4747]">
          {error}
        </p>
      )}
      {hecho && !error && (
        <p className="mt-3 rounded-xl border border-verde/40 bg-lavado px-4 py-2.5 text-[13px] font-medium text-verde-oscuro">
          Guardado.
        </p>
      )}

      <div className="mt-4 grid gap-4">
        {usuarios.map((usuario) => (
          <section
            key={usuario.id}
            aria-label={usuario.nombre}
            className={`rounded-3xl border bg-superficie p-5 ${usuario.activo ? "border-linea" : "border-dashed border-linea-fuerte opacity-70"}`}
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-[15.5px] font-bold tracking-display">
                  {usuario.nombre}
                  {usuario.id === admin.id && (
                    <span className="ml-2 font-mono text-[9px] tracking-[0.1em] text-verde uppercase">(tú)</span>
                  )}
                </p>
                <p className="mt-0.5 text-[12.5px] text-gris">
                  {usuario.email} · alta {fechaLarga(usuario.creadoEn)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`etiqueta-cota rounded-full px-2.5 py-1 text-[8.5px] ${
                    usuario.rol === "admin" ? "bg-tinta text-white" : "bg-malla-suave text-verde"
                  }`}
                >
                  {ROLES_USUARIO.find((rol) => rol.clave === usuario.rol)?.nombre ?? usuario.rol}
                </span>
                <span
                  className={`etiqueta-cota rounded-full border px-2.5 py-1 text-[8.5px] ${
                    usuario.activo ? "border-verde text-verde" : "border-linea-fuerte text-gris"
                  }`}
                >
                  {usuario.activo ? "Activo" : "Desactivado"}
                </span>
                {usuario.id !== admin.id && (
                  <form action={accionAlternarActivo}>
                    <input type="hidden" name="id" value={usuario.id} />
                    <input type="hidden" name="activo" value={usuario.activo ? "0" : "1"} />
                    <button
                      type="submit"
                      className="rounded-full border border-linea-fuerte px-3.5 py-1.5 text-[12.5px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde"
                    >
                      {usuario.activo ? "Desactivar" : "Reactivar"}
                    </button>
                  </form>
                )}
              </div>
            </div>

            <details className="mt-3">
              <summary className="cursor-pointer font-mono text-[9px] tracking-[0.12em] text-gris uppercase hover:text-verde">
                Editar nombre, rol o contraseña
              </summary>
              <form action={accionActualizarUsuario} className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <input type="hidden" name="id" value={usuario.id} />
                <div>
                  <label htmlFor={`u-nombre-${usuario.id}`} className={claseEtiqueta}>Nombre</label>
                  <input id={`u-nombre-${usuario.id}`} name="nombre" defaultValue={usuario.nombre} className={claseCampo} />
                </div>
                <div>
                  <label htmlFor={`u-rol-${usuario.id}`} className={claseEtiqueta}>Rol</label>
                  <select id={`u-rol-${usuario.id}`} name="rol" defaultValue={usuario.rol} className={claseCampo} disabled={usuario.id === admin.id}>
                    {ROLES_USUARIO.map((rol) => (
                      <option key={rol.clave} value={rol.clave}>{rol.nombre}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor={`u-pass-${usuario.id}`} className={claseEtiqueta}>Nueva contraseña (opcional)</label>
                  <input id={`u-pass-${usuario.id}`} name="contrasena" type="password" autoComplete="new-password" placeholder="Mínimo 10 caracteres" className={claseCampo} />
                </div>
                <div className="flex items-end">
                  <button type="submit" className="rounded-full bg-verde px-5 py-2 text-[13px] font-semibold text-white transition-colors hover:bg-verde-oscuro">
                    Guardar
                  </button>
                </div>
              </form>
            </details>
          </section>
        ))}
      </div>

      <section aria-label="Nuevo usuario" className="mt-6 rounded-3xl border border-dashed border-linea-fuerte bg-superficie/70 p-5">
        <h2 className="font-mono text-[9px] tracking-[0.14em] text-verde uppercase">Añadir usuario</h2>
        <form action={accionCrearUsuario} className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div>
            <label htmlFor="n-nombre" className={claseEtiqueta}>Nombre</label>
            <input id="n-nombre" name="nombre" required className={claseCampo} />
          </div>
          <div>
            <label htmlFor="n-email" className={claseEtiqueta}>Email</label>
            <input id="n-email" name="email" type="email" required className={claseCampo} />
          </div>
          <div>
            <label htmlFor="n-contrasena" className={claseEtiqueta}>Contraseña</label>
            <input id="n-contrasena" name="contrasena" type="password" autoComplete="new-password" required minLength={10} className={claseCampo} />
          </div>
          <div>
            <label htmlFor="n-rol" className={claseEtiqueta}>Rol</label>
            <select id="n-rol" name="rol" defaultValue="comercial" className={claseCampo}>
              {ROLES_USUARIO.map((rol) => (
                <option key={rol.clave} value={rol.clave}>{rol.nombre}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <button type="submit" className="rounded-full bg-verde px-5 py-2 text-[13px] font-semibold text-white transition-colors hover:bg-verde-oscuro">
              Crear
            </button>
          </div>
        </form>
        <p className="mt-3 font-mono text-[9px] leading-relaxed tracking-[0.08em] text-gris uppercase">
          Los usuarios con actividad nunca se borran: se desactivan y su historial se conserva.
        </p>
      </section>
    </div>
  );
}
