"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { exigirAdmin, exigirUsuario } from "@/lib/crm/sesion";
import {
  actualizarMiNombre,
  actualizarUsuario,
  cambiarMiContrasena,
  crearUsuario,
} from "@/lib/crm/usuarios";

function volver(resultado: { ok: boolean; error?: string }, destino: string) {
  revalidatePath(destino);
  if (!resultado.ok) {
    redirect(`${destino}?error=${encodeURIComponent(resultado.error ?? "No se pudo guardar")}`);
  }
  redirect(`${destino}?hecho=1`);
}

export async function accionCrearUsuario(formulario: FormData) {
  const admin = await exigirAdmin();
  const resultado = crearUsuario(admin, {
    nombre: String(formulario.get("nombre") ?? ""),
    email: String(formulario.get("email") ?? ""),
    contrasena: String(formulario.get("contrasena") ?? ""),
    rol: String(formulario.get("rol") ?? "comercial"),
  });
  volver(resultado, "/crm/usuarios");
}

export async function accionActualizarUsuario(formulario: FormData) {
  const admin = await exigirAdmin();
  const id = Number(formulario.get("id"));
  if (!Number.isInteger(id)) redirect("/crm/usuarios");
  const contrasena = String(formulario.get("contrasena") ?? "");
  const resultado = actualizarUsuario(admin, id, {
    nombre: String(formulario.get("nombre") ?? ""),
    rol: String(formulario.get("rol") ?? ""),
    contrasena: contrasena || undefined,
  });
  volver(resultado, "/crm/usuarios");
}

export async function accionAlternarActivo(formulario: FormData) {
  const admin = await exigirAdmin();
  const id = Number(formulario.get("id"));
  const activo = String(formulario.get("activo")) === "1";
  if (!Number.isInteger(id)) redirect("/crm/usuarios");
  const resultado = actualizarUsuario(admin, id, { activo });
  volver(resultado, "/crm/usuarios");
}

export type EstadoAjustes = { error?: string; hecho?: string } | undefined;

export async function accionMiPerfil(
  _anterior: EstadoAjustes,
  formulario: FormData,
): Promise<EstadoAjustes> {
  const usuario = await exigirUsuario();
  const resultado = actualizarMiNombre(usuario, String(formulario.get("nombre") ?? ""));
  revalidatePath("/crm/ajustes");
  return resultado.ok ? { hecho: "Nombre actualizado" } : { error: resultado.error };
}

export async function accionMiContrasena(
  _anterior: EstadoAjustes,
  formulario: FormData,
): Promise<EstadoAjustes> {
  const usuario = await exigirUsuario();
  const resultado = cambiarMiContrasena(
    usuario,
    String(formulario.get("actual") ?? ""),
    String(formulario.get("nueva") ?? ""),
  );
  return resultado.ok ? { hecho: "Contraseña cambiada" } : { error: resultado.error };
}
