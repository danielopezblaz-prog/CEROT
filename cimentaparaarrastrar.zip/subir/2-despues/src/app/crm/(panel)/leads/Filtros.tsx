"use client";

import { useRef } from "react";
import Link from "next/link";
import { ESTADOS_LEAD, FUENTES, PRIORIDADES } from "@/db/catalogo";

const claseCampo =
  "rounded-xl border border-linea-fuerte bg-superficie px-3 py-2 text-[13.5px] text-tinta focus-visible:outline-2 focus-visible:outline-verde";
const claseEtiqueta =
  "mb-1 block font-mono text-[8.5px] uppercase tracking-[0.14em] text-gris";

export function Filtros({
  parametros,
  comerciales,
}: {
  parametros: Record<string, string | undefined>;
  comerciales: { id: number; nombre: string }[];
}) {
  const formulario = useRef<HTMLFormElement>(null);
  const enviar = () => formulario.current?.requestSubmit();

  const chip = (especial: string | undefined, texto: string) => {
    const activo = (parametros.especial ?? "") === (especial ?? "");
    const params = new URLSearchParams();
    for (const [clave, valor] of Object.entries(parametros)) {
      if (valor && clave !== "especial" && clave !== "pagina") params.set(clave, valor);
    }
    if (especial) params.set("especial", especial);
    return (
      <Link
        key={texto}
        href={`/crm/leads?${params.toString()}`}
        aria-current={activo ? "true" : undefined}
        className={`etiqueta-cota rounded-full border px-3 py-1.5 text-[9px] whitespace-nowrap transition-colors ${
          activo
            ? "border-verde bg-verde text-white"
            : "border-linea-fuerte text-gris hover:border-verde hover:text-verde"
        }`}
      >
        {texto}
      </Link>
    );
  };

  return (
    <div className="rounded-3xl border border-linea bg-superficie p-4 sm:p-5">
      {/* accesos rápidos */}
      <div className="flex flex-wrap gap-2">
        {chip(undefined, "Todos")}
        {chip("mios", "Mis leads")}
        {chip("sin_contactar", "Sin contactar")}
        {chip("sin_asignar", "Sin asignar")}
        {chip("seguimiento_vencido", "Seguimiento vencido")}
        {chip("duplicados", "Posibles duplicados")}
      </div>

      <form ref={formulario} method="GET" className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {parametros.especial && (
          <input type="hidden" name="especial" value={parametros.especial} />
        )}
        <div className="md:col-span-2">
          <label htmlFor="filtro-q" className={claseEtiqueta}>
            Buscar
          </label>
          <input
            id="filtro-q"
            name="q"
            type="search"
            defaultValue={parametros.q ?? ""}
            placeholder="Nombre, email, teléfono o dirección"
            className={`${claseCampo} w-full`}
          />
        </div>
        <div>
          <label htmlFor="filtro-estado" className={claseEtiqueta}>
            Estado
          </label>
          <select
            id="filtro-estado"
            name="estado"
            defaultValue={parametros.estado ?? ""}
            onChange={enviar}
            className={`${claseCampo} w-full`}
          >
            <option value="">Todos</option>
            {ESTADOS_LEAD.map((estado) => (
              <option key={estado.clave} value={estado.clave}>
                {estado.nombre}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="filtro-comercial" className={claseEtiqueta}>
            Comercial
          </label>
          <select
            id="filtro-comercial"
            name="comercial"
            defaultValue={parametros.comercial ?? ""}
            onChange={enviar}
            className={`${claseCampo} w-full`}
          >
            <option value="">Cualquiera</option>
            {comerciales.map((comercial) => (
              <option key={comercial.id} value={comercial.id}>
                {comercial.nombre}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="filtro-fuente" className={claseEtiqueta}>
            Fuente
          </label>
          <select
            id="filtro-fuente"
            name="fuente"
            defaultValue={parametros.fuente ?? ""}
            onChange={enviar}
            className={`${claseCampo} w-full`}
          >
            <option value="">Todas</option>
            {FUENTES.map((fuente) => (
              <option key={fuente.clave} value={fuente.clave}>
                {fuente.nombre}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="filtro-prioridad" className={claseEtiqueta}>
            Prioridad
          </label>
          <select
            id="filtro-prioridad"
            name="prioridad"
            defaultValue={parametros.prioridad ?? ""}
            onChange={enviar}
            className={`${claseCampo} w-full`}
          >
            <option value="">Todas</option>
            {PRIORIDADES.map((prioridad) => (
              <option key={prioridad.clave} value={prioridad.clave}>
                {prioridad.nombre}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="filtro-desde" className={claseEtiqueta}>
            Desde
          </label>
          <input
            id="filtro-desde"
            name="desde"
            type="date"
            defaultValue={parametros.desde ?? ""}
            onChange={enviar}
            className={`${claseCampo} w-full`}
          />
        </div>
        <div>
          <label htmlFor="filtro-hasta" className={claseEtiqueta}>
            Hasta
          </label>
          <input
            id="filtro-hasta"
            name="hasta"
            type="date"
            defaultValue={parametros.hasta ?? ""}
            onChange={enviar}
            className={`${claseCampo} w-full`}
          />
        </div>
        <div>
          <label htmlFor="filtro-orden" className={claseEtiqueta}>
            Orden
          </label>
          <select
            id="filtro-orden"
            name="orden"
            defaultValue={parametros.orden ?? "recientes"}
            onChange={enviar}
            className={`${claseCampo} w-full`}
          >
            <option value="recientes">Más recientes</option>
            <option value="antiguos">Más antiguos</option>
            <option value="seguimiento">Próximo seguimiento</option>
            <option value="nombre">Nombre (A-Z)</option>
            <option value="valor">Mayor valor estimado</option>
          </select>
        </div>
        <div className="flex items-end gap-2">
          <button
            type="submit"
            className="rounded-full bg-verde px-5 py-2 text-[13.5px] font-semibold text-white transition-colors hover:bg-verde-oscuro"
          >
            Filtrar
          </button>
          <Link
            href="/crm/leads"
            className="rounded-full border border-linea-fuerte px-4 py-2 text-[13.5px] font-semibold text-gris transition-colors hover:border-verde hover:text-verde"
          >
            Limpiar
          </Link>
        </div>
      </form>
    </div>
  );
}
