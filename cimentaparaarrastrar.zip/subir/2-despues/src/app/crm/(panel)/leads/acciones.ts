"use server";

import { revalidatePath } from "next/cache";
import { esEstadoLead, esEstadoTarea } from "@/db/catalogo";
import { exigirAdmin, exigirUsuario } from "@/lib/crm/sesion";
import {
  actualizarCampos,
  anotarLead,
  asignarComercial,
  cambiarEstadoLead,
  eliminarLead,
} from "@/lib/crm/leads";
import { cambiarEstadoTarea, crearTarea } from "@/lib/crm/tareas";

function refrescar(leadId?: number) {
  revalidatePath("/crm/leads");
  revalidatePath("/crm/pipeline");
  revalidatePath("/crm");
  if (leadId) revalidatePath(`/crm/leads/${leadId}`);
}

export async function accionCambiarEstado(formulario: FormData) {
  const usuario = await exigirUsuario();
  const leadId = Number(formulario.get("leadId"));
  const estado = String(formulario.get("estado") ?? "");
  const motivo = String(formulario.get("motivo") ?? "");
  if (!Number.isInteger(leadId) || !esEstadoLead(estado)) return;
  cambiarEstadoLead(leadId, estado, usuario, { motivoPerdida: motivo });
  refrescar(leadId);
}

export async function accionAsignar(formulario: FormData) {
  const usuario = await exigirUsuario();
  const leadId = Number(formulario.get("leadId"));
  const bruto = String(formulario.get("comercialId") ?? "");
  const comercialId = bruto === "" ? null : Number(bruto);
  if (!Number.isInteger(leadId)) return;
  if (comercialId !== null && !Number.isInteger(comercialId)) return;
  asignarComercial(leadId, comercialId, usuario);
  refrescar(leadId);
}

export async function accionEliminar(formulario: FormData) {
  const usuario = await exigirAdmin();
  const leadId = Number(formulario.get("leadId"));
  if (!Number.isInteger(leadId)) return;
  eliminarLead(leadId, usuario);
  refrescar();
}

export async function accionAnotar(formulario: FormData) {
  const usuario = await exigirUsuario();
  const leadId = Number(formulario.get("leadId"));
  const texto = String(formulario.get("texto") ?? "");
  if (!Number.isInteger(leadId)) return;
  anotarLead(leadId, usuario, texto);
  refrescar(leadId);
}

function fechaDe(valor: FormDataEntryValue | null): Date | null {
  const texto = String(valor ?? "").trim();
  if (!texto) return null;
  const fecha = new Date(texto);
  return Number.isNaN(fecha.getTime()) ? null : fecha;
}

function textoDe(valor: FormDataEntryValue | null, maximo = 200): string | null {
  const texto = String(valor ?? "").trim().slice(0, maximo);
  return texto || null;
}

export async function accionActualizarFicha(formulario: FormData) {
  const usuario = await exigirUsuario();
  const leadId = Number(formulario.get("leadId"));
  if (!Number.isInteger(leadId)) return;
  const valorBruto = String(formulario.get("valorEstimado") ?? "").replace(/[^\d]/g, "");
  actualizarCampos(leadId, usuario, {
    prioridad: String(formulario.get("prioridad") ?? ""),
    valorEstimado: valorBruto ? Number(valorBruto) : null,
    proximoSeguimientoEn: fechaDe(formulario.get("proximoSeguimiento")),
    empresa: textoDe(formulario.get("empresa"), 160),
    ciudad: textoDe(formulario.get("ciudad"), 120),
    tipoObra: textoDe(formulario.get("tipoObra"), 120),
    fechaJunta: fechaDe(formulario.get("fechaJunta")),
    administradorFincas: textoDe(formulario.get("administradorFincas"), 160),
    planAyudas: textoDe(formulario.get("planAyudas"), 120),
  });
  refrescar(leadId);
}

export async function accionCrearTarea(formulario: FormData) {
  const usuario = await exigirUsuario();
  const leadId = Number(formulario.get("leadId"));
  const vence = fechaDe(formulario.get("venceEn"));
  const responsable = Number(formulario.get("responsableId"));
  if (!Number.isInteger(leadId) || !vence) return;
  crearTarea(leadId, usuario, {
    titulo: String(formulario.get("titulo") ?? ""),
    tipo: String(formulario.get("tipo") ?? "seguimiento"),
    venceEn: vence,
    responsableId: Number.isInteger(responsable) && responsable > 0 ? responsable : undefined,
  });
  refrescar(leadId);
  revalidatePath("/crm/tareas");
}

export async function accionEstadoTarea(formulario: FormData) {
  const usuario = await exigirUsuario();
  const tareaId = Number(formulario.get("tareaId"));
  const estado = String(formulario.get("estado") ?? "");
  const leadId = Number(formulario.get("leadId"));
  if (!Number.isInteger(tareaId) || !esEstadoTarea(estado)) return;
  cambiarEstadoTarea(tareaId, estado, usuario);
  refrescar(Number.isInteger(leadId) ? leadId : undefined);
  revalidatePath("/crm/tareas");
}
