"use client";

import { useState } from "react";
import { COLUMNAS_CSV } from "@/lib/crm/csv";

/** Exportación CSV (solo se muestra a admin): columnas a elegir + filtros activos. */
export function ExportarCsv({ parametros }: { parametros: Record<string, string | undefined> }) {
  const [abierto, setAbierto] = useState(false);
  const [elegidas, setElegidas] = useState<Set<string>>(
    () => new Set(COLUMNAS_CSV.map((columna) => columna.clave)),
  );

  const alternar = (clave: string) =>
    setElegidas((actual) => {
      const nuevo = new Set(actual);
      if (nuevo.has(clave)) nuevo.delete(clave);
      else nuevo.add(clave);
      return nuevo;
    });

  const exportar = () => {
    const params = new URLSearchParams();
    for (const [clave, valor] of Object.entries(parametros)) {
      if (valor) params.set(clave, valor);
    }
    params.set("columnas", [...elegidas].join(","));
    window.location.href = `/api/crm/exportar?${params.toString()}`;
    setAbierto(false);
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setAbierto((estado) => !estado)}
        aria-expanded={abierto}
        className="rounded-full border border-linea-fuerte px-4 py-2 text-[13px] font-semibold text-tinta transition-colors hover:border-verde hover:text-verde"
      >
        Exportar CSV
      </button>
      {abierto && (
        <div className="absolute right-0 z-40 mt-2 w-[260px] rounded-2xl border border-linea bg-superficie p-4 shadow-[0_20px_50px_rgba(24,33,28,.15)]">
          <p className="font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase">
            Columnas · respeta los filtros activos
          </p>
          <div className="mt-2.5 grid max-h-[260px] gap-1.5 overflow-y-auto">
            {COLUMNAS_CSV.map((columna) => (
              <label key={columna.clave} className="flex cursor-pointer items-center gap-2 text-[12.5px] text-tinta">
                <input
                  type="checkbox"
                  checked={elegidas.has(columna.clave)}
                  onChange={() => alternar(columna.clave)}
                  className="h-3.5 w-3.5 accent-verde"
                />
                {columna.nombre}
              </label>
            ))}
          </div>
          <button
            type="button"
            onClick={exportar}
            disabled={elegidas.size === 0}
            className="mt-3 w-full rounded-full bg-verde px-4 py-2 text-[13px] font-bold text-white transition-colors hover:bg-verde-oscuro disabled:opacity-50"
          >
            Descargar ({elegidas.size} columnas)
          </button>
        </div>
      )}
    </div>
  );
}
