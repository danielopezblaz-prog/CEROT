/** Esqueleto del listado mientras el servidor resuelve filtros y datos. */
export default function CargandoLeads() {
  return (
    <div aria-busy="true" aria-label="Cargando leads">
      <div className="h-5 w-24 animate-pulse rounded-full bg-lavado" />
      <div className="mt-2 h-8 w-56 animate-pulse rounded-xl bg-lavado" />
      <div className="mt-4 h-40 animate-pulse rounded-3xl bg-lavado" />
      <div className="mt-4 overflow-hidden rounded-3xl border border-linea bg-superficie">
        {[...Array(8)].map((_, indice) => (
          <div key={indice} className="flex items-center gap-6 border-b border-linea px-4 py-4 last:border-0">
            <div className="h-4 w-1/4 animate-pulse rounded bg-lavado" />
            <div className="h-4 w-1/6 animate-pulse rounded bg-lavado" />
            <div className="h-4 w-1/6 animate-pulse rounded bg-lavado" />
            <div className="h-4 w-1/5 animate-pulse rounded bg-lavado" />
          </div>
        ))}
      </div>
    </div>
  );
}
