"use client";

import { useState, useTransition } from "react";
import { accionCambiarEstado } from "../acciones";

/** Cierre del lead: ganado directo, perdido/no válido con motivo. */
export function MarcarCierre({ leadId, estado }: { leadId: number; estado: string }) {
  const [modal, setModal] = useState<"perdido" | "no_valido" | null>(null);
  const [motivo, setMotivo] = useState("");
  const [pendiente, transicion] = useTransition();
  const cerrado = ["ganado", "perdido", "no_valido"].includes(estado);

  const enviar = (destino: string, conMotivo?: string) => {
    const datos = new FormData();
    datos.set("leadId", String(leadId));
    datos.set("estado", destino);
    if (conMotivo) datos.set("motivo", conMotivo);
    transicion(async () => {
      await accionCambiarEstado(datos);
      setModal(null);
      setMotivo("");
    });
  };

  if (cerrado) return null;

  return (
    <>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={pendiente}
          onClick={() => enviar("ganado")}
          className="rounded-full bg-verde px-4 py-2 text-[13px] font-bold text-white transition-colors hover:bg-verde-oscuro disabled:opacity-60"
        >
          ✓ Mandato firmado
        </button>
        <button
          type="button"
          onClick={() => setModal("perdido")}
          className="rounded-full border border-[#8a5b5b]/60 px-4 py-2 text-[13px] font-semibold text-[#8a5b5b] transition-colors hover:bg-[#8a5b5b]/10"
        >
          Perdido
        </button>
        <button
          type="button"
          onClick={() => setModal("no_valido")}
          className="rounded-full border border-linea-fuerte px-4 py-2 text-[13px] font-semibold text-gris transition-colors hover:border-tinta/40"
        >
          No válido
        </button>
      </div>

      {modal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="cierre-titulo"
          className="fixed inset-0 z-50 flex items-center justify-center bg-tinta/60 p-5"
          onClick={(evento) => {
            if (evento.target === evento.currentTarget) setModal(null);
          }}
        >
          <div className="w-full max-w-[440px] rounded-3xl border border-linea bg-superficie p-6 shadow-[0_30px_80px_rgba(24,33,28,.3)]">
            <h3 id="cierre-titulo" className="text-[17px] font-bold tracking-display">
              {modal === "perdido" ? "Marcar como perdido" : "Marcar como no válido"}
            </h3>
            <p className="mt-1.5 text-[13.5px] text-gris">
              El motivo queda en el historial y alimenta el dashboard.
            </p>
            <label htmlFor="motivo-cierre" className="mt-4 mb-1 block font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase">
              Motivo
            </label>
            <textarea
              id="motivo-cierre"
              value={motivo}
              onChange={(evento) => setMotivo(evento.target.value)}
              rows={3}
              placeholder="P. ej., la junta votó posponer la obra"
              className="w-full rounded-xl border border-linea-fuerte bg-superficie px-3 py-2.5 text-[14px] text-tinta focus-visible:outline-2 focus-visible:outline-verde"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setModal(null)}
                className="rounded-full border border-linea-fuerte px-4 py-2 text-[13.5px] font-semibold text-tinta"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={pendiente || motivo.trim().length < 3}
                onClick={() => enviar(modal, motivo.trim())}
                className="rounded-full bg-[#8a5b5b] px-4 py-2 text-[13.5px] font-bold text-white disabled:opacity-50"
              >
                {pendiente ? "Guardando…" : "Confirmar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
