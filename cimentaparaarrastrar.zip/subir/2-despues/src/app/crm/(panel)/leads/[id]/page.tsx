import Link from "next/link";
import { notFound } from "next/navigation";
import { exigirUsuario } from "@/lib/crm/sesion";
import { listarComerciales, obtenerLead } from "@/lib/crm/leads";
import { cronologiaDeLead } from "@/lib/crm/ficha";
import { tareasDeLead } from "@/lib/crm/tareas";
import { fechaLarga, fechaYHora, euros, estaVencida } from "@/lib/crm/fechas";
import { ESTADOS_TAREA, FUENTES, PRIORIDADES, TIPOS_TAREA, estadoLead } from "@/db/catalogo";
import { ChipDuplicado, ChipEstado, ChipPrioridad } from "@/components/crm/Ui";
import { SelectorComercial, SelectorEstado, BotonEliminar } from "../AccionesRapidas";
import { MarcarCierre } from "./MarcarCierre";
import {
  accionActualizarFicha,
  accionAnotar,
  accionCrearTarea,
  accionEstadoTarea,
} from "../acciones";

export const dynamic = "force-dynamic";

const claseCampo =
  "w-full rounded-xl border border-linea-fuerte bg-superficie px-3 py-2 text-[13.5px] text-tinta focus-visible:outline-2 focus-visible:outline-verde";
const claseEtiqueta = "mb-1 block font-mono text-[8.5px] uppercase tracking-[0.14em] text-gris";

function Tarjeta({ titulo, children }: { titulo: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl border border-linea bg-superficie p-5">
      <h2 className="font-mono text-[9px] tracking-[0.14em] text-verde uppercase">{titulo}</h2>
      <div className="mt-3">{children}</div>
    </section>
  );
}

function Dato({ nombre, children }: { nombre: string; children: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-linea py-2 last:border-0">
      <dt className="text-[12.5px] text-gris">{nombre}</dt>
      <dd className="text-right text-[13px] font-medium text-tinta">{children}</dd>
    </div>
  );
}

const ICONO_EVENTO: Record<string, string> = {
  creacion: "＋",
  estado: "⇢",
  asignacion: "◉",
  nota: "✎",
  tarea_creada: "◻",
  tarea_completada: "✓",
  edicion: "…",
};

export default async function FichaLead({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const usuario = await exigirUsuario();
  const { id } = await params;
  const leadId = Number(id);
  if (!Number.isInteger(leadId)) notFound();
  const resultado = obtenerLead(leadId);
  if (!resultado) notFound();
  const { lead } = resultado;
  const comerciales = listarComerciales();
  const cronologia = cronologiaDeLead(leadId);
  const tareas = tareasDeLead(leadId);

  const nombreFuente = FUENTES.find((f) => f.clave === lead.fuente)?.nombre ?? lead.fuente;

  return (
    <div>
      <Link href="/crm/leads" className="font-mono text-[10px] tracking-[0.1em] text-gris uppercase hover:text-verde">
        ← Volver al listado
      </Link>

      {/* ————— Cabecera ————— */}
      <div className="mt-3 rounded-3xl border border-linea bg-superficie p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-[24px] leading-tight font-extrabold tracking-display">
                {lead.nombre}
              </h1>
              <ChipEstado clave={lead.estado} />
              <ChipPrioridad clave={lead.prioridad} />
              {lead.posibleDuplicado && <ChipDuplicado />}
            </div>
            <p className="mt-1.5 text-[13.5px] text-gris">
              {lead.rolContacto ?? "—"}
              {lead.direccion ? ` · ${lead.direccion}` : ""}
              {lead.viviendas ? ` · ${lead.viviendas} viviendas` : ""}
            </p>
            <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-[14px]">
              {lead.email && (
                <a href={`mailto:${lead.email}`} className="font-semibold text-verde hover:underline">
                  {lead.email}
                </a>
              )}
              {lead.telefono && (
                <a href={`tel:${lead.telefono}`} className="font-semibold text-tinta hover:text-verde">
                  {lead.telefono}
                </a>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end gap-2.5">
            <MarcarCierre leadId={lead.id} estado={lead.estado} />
            <div className="flex flex-wrap justify-end gap-2">
              <SelectorEstado leadId={lead.id} estado={lead.estado} />
              <SelectorComercial
                leadId={lead.id}
                comercialId={lead.comercialId}
                comerciales={comerciales}
              />
              {usuario.rol === "admin" && <BotonEliminar leadId={lead.id} nombre={lead.nombre} />}
            </div>
          </div>
        </div>
        {lead.motivoPerdida && (
          <p className="mt-4 rounded-xl border border-[#8a5b5b]/40 bg-[#8a5b5b]/5 px-4 py-2.5 text-[13px] text-[#6d4747]">
            <strong className="font-semibold">Motivo de cierre:</strong> {lead.motivoPerdida}
          </p>
        )}
      </div>

      <div className="mt-5 grid items-start gap-5 xl:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        {/* ————— Columna principal ————— */}
        <div className="grid gap-5">
          <Tarjeta titulo="Solicitud original">
            <dl>
              <Dato nombre="Contacto tal cual lo escribió">{lead.contactoOriginal ?? "—"}</Dato>
              <Dato nombre="Simulación adjunta">{lead.simulacion ?? "No usó el simulador"}</Dato>
              <Dato nombre="Consentimiento RGPD">
                {lead.consentimientoEn ? fechaYHora(lead.consentimientoEn) : "Sin registrar"}
              </Dato>
              {lead.mensaje && <Dato nombre="Mensaje">{lead.mensaje}</Dato>}
            </dl>
          </Tarjeta>

          <Tarjeta titulo="Cualificación">
            <form action={accionActualizarFicha} className="grid gap-3 sm:grid-cols-2">
              <input type="hidden" name="leadId" value={lead.id} />
              <div>
                <label htmlFor="f-prioridad" className={claseEtiqueta}>Prioridad</label>
                <select id="f-prioridad" name="prioridad" defaultValue={lead.prioridad} className={claseCampo}>
                  {PRIORIDADES.map((p) => (
                    <option key={p.clave} value={p.clave}>{p.nombre}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="f-valor" className={claseEtiqueta}>Valor estimado (€)</label>
                <input id="f-valor" name="valorEstimado" inputMode="numeric" defaultValue={lead.valorEstimado ?? ""} placeholder="p. ej., 216000" className={claseCampo} />
              </div>
              <div>
                <label htmlFor="f-seguimiento" className={claseEtiqueta}>Próximo seguimiento</label>
                <input id="f-seguimiento" name="proximoSeguimiento" type="date" defaultValue={lead.proximoSeguimientoEn ? lead.proximoSeguimientoEn.toISOString().slice(0, 10) : ""} className={claseCampo} />
              </div>
              <div>
                <label htmlFor="f-junta" className={claseEtiqueta}>Fecha de la próxima junta</label>
                <input id="f-junta" name="fechaJunta" type="date" defaultValue={lead.fechaJunta ? lead.fechaJunta.toISOString().slice(0, 10) : ""} className={claseCampo} />
              </div>
              <div>
                <label htmlFor="f-obra" className={claseEtiqueta}>Tipo de obra prevista</label>
                <input id="f-obra" name="tipoObra" defaultValue={lead.tipoObra ?? ""} placeholder="Fachada, integral, accesibilidad…" className={claseCampo} />
              </div>
              <div>
                <label htmlFor="f-plan" className={claseEtiqueta}>Plan de ayudas objetivo</label>
                <input id="f-plan" name="planAyudas" defaultValue={lead.planAyudas ?? ""} placeholder="Estatal, Rehabilita Madrid, CAE…" className={claseCampo} />
              </div>
              <div>
                <label htmlFor="f-administrador" className={claseEtiqueta}>Administrador de fincas</label>
                <input id="f-administrador" name="administradorFincas" defaultValue={lead.administradorFincas ?? ""} className={claseCampo} />
              </div>
              <div>
                <label htmlFor="f-empresa" className={claseEtiqueta}>Empresa / comunidad</label>
                <input id="f-empresa" name="empresa" defaultValue={lead.empresa ?? ""} className={claseCampo} />
              </div>
              <div className="sm:col-span-2">
                <button type="submit" className="rounded-full bg-verde px-5 py-2 text-[13.5px] font-semibold text-white transition-colors hover:bg-verde-oscuro">
                  Guardar cualificación
                </button>
              </div>
            </form>
          </Tarjeta>

          <Tarjeta titulo="Tareas de este lead">
            {tareas.length === 0 ? (
              <p className="text-[13px] text-gris">Sin tareas todavía.</p>
            ) : (
              <ul className="grid gap-2">
                {tareas.map(({ tarea, responsable }) => (
                  <li key={tarea.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-linea px-3.5 py-2.5">
                    <div>
                      <p className={`text-[13.5px] font-semibold ${tarea.estado === "completada" ? "text-gris line-through" : "text-tinta"}`}>
                        {tarea.titulo}
                      </p>
                      <p className="mt-0.5 font-mono text-[9px] tracking-[0.1em] text-gris uppercase">
                        {TIPOS_TAREA.find((t) => t.clave === tarea.tipo)?.nombre ?? tarea.tipo} ·{" "}
                        <span className={estaVencida(tarea.venceEn) && tarea.estado === "pendiente" ? "text-[#8a5b5b]" : ""}>
                          {fechaYHora(tarea.venceEn)}
                        </span>{" "}
                        · {responsable ?? "—"}
                      </p>
                    </div>
                    <form action={accionEstadoTarea} className="flex items-center gap-2">
                      <input type="hidden" name="tareaId" value={tarea.id} />
                      <input type="hidden" name="leadId" value={lead.id} />
                      <select
                        name="estado"
                        defaultValue={tarea.estado}
                        aria-label={`Estado de la tarea ${tarea.titulo}`}
                        className="rounded-lg border border-linea bg-superficie px-2 py-1.5 text-[12px]"
                      >
                        {ESTADOS_TAREA.map((estado) => (
                          <option key={estado.clave} value={estado.clave}>{estado.nombre}</option>
                        ))}
                      </select>
                      <button type="submit" className="rounded-full border border-linea-fuerte px-3 py-1.5 text-[12px] font-semibold text-tinta hover:border-verde hover:text-verde">
                        Aplicar
                      </button>
                    </form>
                  </li>
                ))}
              </ul>
            )}

            <form action={accionCrearTarea} className="mt-4 grid gap-3 rounded-2xl border border-dashed border-linea-fuerte p-4 sm:grid-cols-2">
              <input type="hidden" name="leadId" value={lead.id} />
              <div className="sm:col-span-2">
                <label htmlFor="t-titulo" className={claseEtiqueta}>Nueva tarea</label>
                <input id="t-titulo" name="titulo" required placeholder="P. ej., llamar para cerrar la visita" className={claseCampo} />
              </div>
              <div>
                <label htmlFor="t-tipo" className={claseEtiqueta}>Tipo</label>
                <select id="t-tipo" name="tipo" defaultValue="llamada" className={claseCampo}>
                  {TIPOS_TAREA.map((tipo) => (
                    <option key={tipo.clave} value={tipo.clave}>{tipo.nombre}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="t-vence" className={claseEtiqueta}>Fecha y hora</label>
                <input id="t-vence" name="venceEn" type="datetime-local" required className={claseCampo} />
              </div>
              <div>
                <label htmlFor="t-responsable" className={claseEtiqueta}>Responsable</label>
                <select id="t-responsable" name="responsableId" defaultValue={lead.comercialId ?? usuario.id} className={claseCampo}>
                  {comerciales.map((comercial) => (
                    <option key={comercial.id} value={comercial.id}>{comercial.nombre}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-end">
                <button type="submit" className="rounded-full bg-verde px-5 py-2 text-[13.5px] font-semibold text-white transition-colors hover:bg-verde-oscuro">
                  Crear tarea
                </button>
              </div>
            </form>
          </Tarjeta>
        </div>

        {/* ————— Columna lateral ————— */}
        <div className="grid gap-5">
          <Tarjeta titulo="Origen">
            <dl>
              <Dato nombre="Fuente">{nombreFuente}</Dato>
              <Dato nombre="Formulario">{lead.formularioOrigen ?? "—"}</Dato>
              <Dato nombre="URL">
                <span className="block max-w-[220px] truncate">{lead.urlOrigen ?? "—"}</span>
              </Dato>
              <Dato nombre="Referrer">
                <span className="block max-w-[220px] truncate">{lead.referrer ?? "—"}</span>
              </Dato>
              <Dato nombre="Campaña">
                {lead.utmSource
                  ? `${lead.utmSource}${lead.utmMedium ? ` / ${lead.utmMedium}` : ""}${lead.utmCampaign ? ` / ${lead.utmCampaign}` : ""}`
                  : "—"}
              </Dato>
              <Dato nombre="Entrada">{fechaYHora(lead.creadoEn)}</Dato>
              <Dato nombre="Último contacto">{fechaLarga(lead.ultimoContactoEn)}</Dato>
              <Dato nombre="Valor estimado">{euros(lead.valorEstimado)}</Dato>
            </dl>
          </Tarjeta>

          <Tarjeta titulo="Añadir nota interna">
            <form action={accionAnotar} className="grid gap-2.5">
              <input type="hidden" name="leadId" value={lead.id} />
              <label htmlFor="nota-texto" className="sr-only">Nota interna</label>
              <textarea
                id="nota-texto"
                name="texto"
                rows={3}
                required
                placeholder="Solo la ve el equipo; nunca sale del CRM."
                className="w-full rounded-xl border border-linea-fuerte bg-superficie px-3 py-2.5 text-[13.5px] focus-visible:outline-2 focus-visible:outline-verde"
              />
              <button type="submit" className="justify-self-start rounded-full bg-verde px-5 py-2 text-[13.5px] font-semibold text-white transition-colors hover:bg-verde-oscuro">
                Guardar nota
              </button>
            </form>
          </Tarjeta>

          <Tarjeta titulo="Cronología">
            <ol className="relative ml-1 grid gap-0 border-l border-linea-fuerte">
              {cronologia.map((evento) => (
                <li key={evento.id} className="relative pb-4 pl-5 last:pb-0">
                  <span
                    aria-hidden="true"
                    className="absolute top-0.5 -left-[9px] flex h-[17px] w-[17px] items-center justify-center rounded-full border border-verde/40 bg-superficie font-mono text-[8.5px] text-verde"
                  >
                    {ICONO_EVENTO[evento.tipo] ?? "·"}
                  </span>
                  <p className="text-[12.5px] leading-snug text-tinta">
                    {evento.tipo === "estado" ? (
                      <>
                        <strong className="font-semibold">
                          {estadoLead(evento.estadoAnterior ?? "")?.nombre ?? evento.estadoAnterior}
                        </strong>{" "}
                        → <strong className="font-semibold">{estadoLead(evento.estadoNuevo ?? "")?.nombre ?? evento.estadoNuevo}</strong>
                        {evento.texto ? ` · ${evento.texto}` : ""}
                      </>
                    ) : evento.tipo === "creacion" ? (
                      evento.texto ?? "Lead creado"
                    ) : (
                      evento.texto ?? evento.tipo
                    )}
                  </p>
                  <p className="mt-0.5 font-mono text-[8.5px] tracking-[0.1em] text-gris uppercase">
                    {fechaYHora(evento.fecha)} · {evento.usuario ?? "Sistema"}
                  </p>
                </li>
              ))}
            </ol>
          </Tarjeta>
        </div>
      </div>
    </div>
  );
}
