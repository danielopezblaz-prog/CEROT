import Link from "next/link";
import { exigirUsuario } from "@/lib/crm/sesion";
import {
  filtrosDesdeParametros,
  listarComerciales,
  listarLeads,
} from "@/lib/crm/leads";
import { fechaCorta, estaVencida } from "@/lib/crm/fechas";
import { FUENTES } from "@/db/catalogo";
import { ChipDuplicado, ChipPrioridad, Paginacion, VistaVacia } from "@/components/crm/Ui";
import { Filtros } from "./Filtros";
import { BotonEliminar, SelectorComercial, SelectorEstado } from "./AccionesRapidas";
import { ExportarCsv } from "./ExportarCsv";

export const dynamic = "force-dynamic";

export default async function PaginaLeads({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const usuario = await exigirUsuario();
  const parametrosBrutos = await searchParams;
  const filtros = filtrosDesdeParametros(parametrosBrutos);
  const { filas, total, paginas, pagina } = listarLeads(filtros, usuario);
  const comerciales = listarComerciales();

  const parametrosPlanos: Record<string, string | undefined> = {};
  for (const clave of ["q", "estado", "comercial", "fuente", "prioridad", "desde", "hasta", "especial", "orden"]) {
    const valor = parametrosBrutos[clave];
    if (typeof valor === "string" && valor) parametrosPlanos[clave] = valor;
  }

  const nombreFuente = (clave: string) =>
    FUENTES.find((fuente) => fuente.clave === clave)?.nombre ?? clave;

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="etiqueta-cota text-verde">Leads</p>
          <h1 className="mt-1 text-[24px] font-extrabold tracking-display">
            Todos los leads
          </h1>
        </div>
        <div className="flex items-center gap-3">
          {usuario.rol === "admin" && <ExportarCsv parametros={parametrosPlanos} />}
          <Paginacion
            pagina={pagina}
            paginas={paginas}
            total={total}
            base="/crm/leads"
            parametros={parametrosPlanos}
          />
        </div>
      </div>

      <div className="mt-4">
        <Filtros parametros={parametrosPlanos} comerciales={comerciales} />
      </div>

      <div className="mt-4">
        {filas.length === 0 ? (
          <VistaVacia
            titulo="Ningún lead con estos filtros"
            texto="Prueba a limpiar la búsqueda o los filtros. Los leads nuevos del formulario aparecen aquí en cuanto llegan."
          />
        ) : (
          <div className="overflow-x-auto rounded-3xl border border-linea bg-superficie">
            <table className="w-full min-w-[980px] border-collapse text-left">
              <thead>
                <tr className="border-b border-linea">
                  {["Lead", "Contacto", "Estado", "Prioridad", "Comercial", "Fuente", "Entrada", "Seguimiento", ""].map(
                    (titulo, indice) => (
                      <th
                        key={indice}
                        scope="col"
                        className="px-4 py-3 font-mono text-[8.5px] tracking-[0.14em] text-gris uppercase"
                      >
                        {titulo}
                      </th>
                    ),
                  )}
                </tr>
              </thead>
              <tbody>
                {filas.map(({ lead, comercial }) => (
                  <tr key={lead.id} className="border-b border-linea last:border-0 hover:bg-lavado/40">
                    <td className="px-4 py-3">
                      <Link
                        href={`/crm/leads/${lead.id}`}
                        className="font-semibold text-tinta hover:text-verde"
                      >
                        {lead.nombre}
                      </Link>
                      <p className="mt-0.5 max-w-[220px] truncate text-[12px] text-gris">
                        {lead.direccion ?? "—"}
                        {lead.viviendas ? ` · ${lead.viviendas} viv` : ""}
                      </p>
                      {lead.posibleDuplicado && (
                        <p className="mt-1">
                          <ChipDuplicado />
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[13px]">
                      {lead.email && (
                        <a href={`mailto:${lead.email}`} className="block text-verde hover:underline">
                          {lead.email}
                        </a>
                      )}
                      {lead.telefono && (
                        <a href={`tel:${lead.telefono}`} className="block text-tinta hover:text-verde">
                          {lead.telefono}
                        </a>
                      )}
                      {!lead.email && !lead.telefono && (
                        <span className="text-gris">{lead.contactoOriginal ?? "—"}</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <SelectorEstado leadId={lead.id} estado={lead.estado} />
                    </td>
                    <td className="px-4 py-3">
                      <ChipPrioridad clave={lead.prioridad} />
                    </td>
                    <td className="px-4 py-3">
                      <SelectorComercial
                        leadId={lead.id}
                        comercialId={lead.comercialId}
                        comerciales={comerciales}
                      />
                      {comercial === null && lead.comercialId === null && (
                        <span className="sr-only">Sin asignar</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[12.5px] text-gris">{nombreFuente(lead.fuente)}</td>
                    <td className="px-4 py-3 text-[12.5px] whitespace-nowrap text-gris">
                      {fechaCorta(lead.creadoEn)}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {lead.proximoSeguimientoEn ? (
                        <span
                          className={`text-[12.5px] font-semibold ${
                            estaVencida(lead.proximoSeguimientoEn) ? "text-[#8a5b5b]" : "text-verde"
                          }`}
                        >
                          {fechaCorta(lead.proximoSeguimientoEn)}
                          {estaVencida(lead.proximoSeguimientoEn) ? " · vencido" : ""}
                        </span>
                      ) : (
                        <span className="text-[12.5px] text-gris">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {usuario.rol === "admin" && (
                        <BotonEliminar leadId={lead.id} nombre={lead.nombre} />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="mt-4 flex justify-end">
        <Paginacion
          pagina={pagina}
          paginas={paginas}
          total={total}
          base="/crm/leads"
          parametros={parametrosPlanos}
        />
      </div>
    </div>
  );
}
