"use client";

import { useState, useTransition } from "react";
import { ESTADOS_LEAD } from "@/db/catalogo";
import { accionAsignar, accionCambiarEstado, accionEliminar } from "./acciones";

const claseSelector =
  "w-full min-w-[140px] max-w-[180px] rounded-lg border border-linea bg-superficie px-2 py-1.5 text-[12.5px] text-tinta focus-visible:outline-2 focus-visible:outline-verde disabled:opacity-50";

export function SelectorEstado({ leadId, estado }: { leadId: number; estado: string }) {
  const [pendiente, transicion] = useTransition();
  return (
    <select
      aria-label="Cambiar estado"
      className={claseSelector}
      defaultValue={estado}
      disabled={pendiente}
      onChange={(evento) => {
        const datos = new FormData();
        datos.set("leadId", String(leadId));
        datos.set("estado", evento.target.value);
        transicion(() => accionCambiarEstado(datos));
      }}
    >
      {ESTADOS_LEAD.map((opcion) => (
        <option key={opcion.clave} value={opcion.clave}>
          {opcion.nombre}
        </option>
      ))}
    </select>
  );
}

export function SelectorComercial({
  leadId,
  comercialId,
  comerciales,
}: {
  leadId: number;
  comercialId: number | null;
  comerciales: { id: number; nombre: string }[];
}) {
  const [pendiente, transicion] = useTransition();
  return (
    <select
      aria-label="Asignar comercial"
      className={claseSelector}
      defaultValue={comercialId === null ? "" : String(comercialId)}
      disabled={pendiente}
      onChange={(evento) => {
        const datos = new FormData();
        datos.set("leadId", String(leadId));
        datos.set("comercialId", evento.target.value);
        transicion(() => accionAsignar(datos));
      }}
    >
      <option value="">Sin asignar</option>
      {comerciales.map((comercial) => (
        <option key={comercial.id} value={comercial.id}>
          {comercial.nombre}
        </option>
      ))}
    </select>
  );
}

/** Eliminar (solo admin): modal de confirmación antes de borrar. */
export function BotonEliminar({ leadId, nombre }: { leadId: number; nombre: string }) {
  const [abierto, setAbierto] = useState(false);
  const [pendiente, transicion] = useTransition();

  return (
    <>
      <button
        type="button"
        onClick={() => setAbierto(true)}
        aria-label={`Eliminar el lead ${nombre}`}
        className="rounded-full border border-linea-fuerte px-3 py-1.5 text-[12px] font-semibold text-gris transition-colors hover:border-[#8a5b5b] hover:text-[#8a5b5b]"
      >
        Eliminar
      </button>

      {abierto && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby={`eliminar-titulo-${leadId}`}
          className="fixed inset-0 z-50 flex items-center justify-center bg-tinta/60 p-5"
          onClick={(evento) => {
            if (evento.target === evento.currentTarget) setAbierto(false);
          }}
        >
          <div className="w-full max-w-[400px] rounded-3xl border border-linea bg-superficie p-6 shadow-[0_30px_80px_rgba(24,33,28,.3)]">
            <h3 id={`eliminar-titulo-${leadId}`} className="text-[17px] font-bold tracking-display">
              ¿Eliminar este lead?
            </h3>
            <p className="mt-2 text-[13.5px] leading-relaxed text-gris">
              <strong className="text-tinta">{nombre}</strong> dejará de aparecer en el
              CRM. El borrado es lógico: el historial se conserva y puede recuperarse
              desde la base de datos.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setAbierto(false)}
                className="rounded-full border border-linea-fuerte px-4 py-2 text-[13.5px] font-semibold text-tinta"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={pendiente}
                onClick={() => {
                  const datos = new FormData();
                  datos.set("leadId", String(leadId));
                  transicion(async () => {
                    await accionEliminar(datos);
                    setAbierto(false);
                  });
                }}
                className="rounded-full bg-[#8a5b5b] px-4 py-2 text-[13.5px] font-bold text-white transition-opacity disabled:opacity-60"
              >
                {pendiente ? "Eliminando…" : "Sí, eliminar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
