import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { usuarioActual } from "@/lib/crm/sesion";
import { Logotipo } from "@/components/Compartidos";
import { FormularioAcceso } from "./FormularioAcceso";

export const metadata: Metadata = {
  title: "Acceso · CRM de Cimenta",
  robots: { index: false, follow: false },
};

export default async function PaginaAcceso() {
  const usuario = await usuarioActual();
  if (usuario) redirect("/crm");

  return (
    <main className="trama-malla flex min-h-svh items-center justify-center bg-tinta px-5 py-10">
      <div className="w-full max-w-[400px]">
        <div className="flex justify-center">
          <Logotipo claro />
        </div>
        <div className="mt-8 rounded-3xl border border-white/10 bg-white/[.04] p-6 sm:p-8">
          <h1 className="text-[22px] leading-tight font-extrabold tracking-display text-white">
            CRM de leads
          </h1>
          <p className="mt-1.5 text-[13.5px] text-white/60">
            Acceso privado del equipo de Cimenta.
          </p>
          <FormularioAcceso />
        </div>
        <p className="mt-6 text-center font-mono text-[9px] tracking-[0.14em] text-white/40 uppercase">
          Uso interno · Los accesos quedan registrados
        </p>
      </div>
    </main>
  );
}
