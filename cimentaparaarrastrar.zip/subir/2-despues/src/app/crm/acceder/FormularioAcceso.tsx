"use client";

import { useActionState } from "react";
import { iniciarSesion, type ResultadoAcceso } from "@/lib/crm/autenticacion";

const claseCampo =
  "w-full rounded-xl border border-white/15 bg-white/[.07] px-3.5 py-3.5 text-[16px] text-white placeholder:text-white/35 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-malla";
const claseEtiqueta =
  "mb-1.5 block font-mono text-[9.5px] uppercase tracking-[0.14em] text-white/60";

export function FormularioAcceso() {
  const [resultado, accion, enviando] = useActionState<ResultadoAcceso, FormData>(
    iniciarSesion,
    undefined,
  );

  return (
    <form action={accion} className="mt-6 grid gap-4">
      <div>
        <label htmlFor="acceso-email" className={claseEtiqueta}>
          Email
        </label>
        <input
          id="acceso-email"
          name="email"
          type="email"
          autoComplete="username"
          required
          className={claseCampo}
          placeholder="tu@cimenta.es"
        />
      </div>
      <div>
        <label htmlFor="acceso-contrasena" className={claseEtiqueta}>
          Contraseña
        </label>
        <input
          id="acceso-contrasena"
          name="contrasena"
          type="password"
          autoComplete="current-password"
          required
          className={claseCampo}
          placeholder="••••••••••"
        />
      </div>

      {resultado?.error && (
        <p role="alert" className="rounded-xl border border-malla/50 bg-white/[.05] px-4 py-3 text-[13.5px] font-medium text-white">
          {resultado.error}
        </p>
      )}

      <button
        type="submit"
        disabled={enviando}
        className="mt-1 rounded-full bg-malla px-6 py-3.5 text-[15px] font-bold text-tinta transition-colors hover:bg-[#8fd4b0] disabled:opacity-60"
      >
        {enviando ? "Comprobando…" : "Entrar"}
      </button>
    </form>
  );
}
