import type { Metadata } from "next";
import { paginaPorRuta } from "@/content-paginas";
import { metadatosDe } from "@/lib/metadatos";
import { Aterrizaje } from "@/components/paginas/Aterrizaje";

const pagina = paginaPorRuta("/plan-rehabilita-madrid")!;

export const metadata: Metadata = metadatosDe(pagina);

export default function PaginaPlanRehabilita() {
  return <Aterrizaje pagina={pagina} />;
}
