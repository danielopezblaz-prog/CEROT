import type { Metadata } from "next";
import { paginasLegales } from "@/content";
import { PaginaLegal } from "@/components/PaginaLegal";

export const metadata: Metadata = {
  title: paginasLegales.privacidad.titulo,
  alternates: { canonical: "/privacidad" },
  /* Indexables: para un servicio, las legales son señal de confianza. */
  robots: { index: true, follow: true },
};

export default function Privacidad() {
  return <PaginaLegal datos={paginasLegales.privacidad} />;
}
