import { NextResponse } from "next/server";
import {
  avisarNuevoLead,
  crearLeadDesdeWeb,
  limpiar,
  type CargaLeadWeb,
} from "@/lib/crm/captura";
import { intentar } from "@/lib/crm/limitador";

/**
 * Recibe las solicitudes de pre-informe del formulario público y las
 * guarda como leads del CRM. El contrato con el visitante no cambia:
 * mismo cuerpo, misma respuesta { ok } y mismo mensaje de éxito.
 *
 * Si la base de datos fallara, el lead NO se pierde: queda como log
 * estructurado completo y se intenta avisar por email al equipo.
 */
export async function POST(peticion: Request) {
  let datos: Record<string, unknown>;
  try {
    datos = await peticion.json();
  } catch {
    return NextResponse.json(
      { ok: false, error: "El cuerpo de la petición no es válido" },
      { status: 400 },
    );
  }

  /* Señuelo antispam: si el campo oculto llega relleno, se ignora en silencio. */
  if (limpiar(datos.referencia)) {
    return NextResponse.json({ ok: true });
  }

  const ip =
    peticion.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "desconocida";

  /* Límite básico por IP y freno anti doble envío (mismo contacto seguido). */
  if (!intentar(`lead:ip:${ip}`, 8, 60_000).permitido) {
    return NextResponse.json(
      { ok: false, error: "Demasiadas solicitudes seguidas. Espera un minuto." },
      { status: 429 },
    );
  }
  const huella = `lead:doble:${limpiar(datos.contacto, 160).toLowerCase()}`;
  if (limpiar(datos.contacto) && !intentar(huella, 2, 30_000).permitido) {
    /* segundo clic inmediato del mismo envío: éxito idempotente, sin duplicar */
    return NextResponse.json({ ok: true });
  }

  const origenBruto =
    typeof datos.origen === "object" && datos.origen !== null
      ? (datos.origen as Record<string, unknown>)
      : {};

  const carga: CargaLeadWeb = {
    nombre: limpiar(datos.nombre, 160),
    rol: limpiar(datos.rol, 80),
    direccion: limpiar(datos.direccion, 240),
    viviendas: limpiar(datos.viviendas, 6),
    contacto: limpiar(datos.contacto, 160),
    simulacion: limpiar(datos.simulacion, 240),
    consentimiento: datos.consentimiento === true,
    origen: {
      url: limpiar(origenBruto.url, 300),
      referrer:
        limpiar(origenBruto.referrer, 300) ||
        limpiar(peticion.headers.get("referer"), 300),
      utmSource: limpiar(origenBruto.utmSource, 120),
      utmMedium: limpiar(origenBruto.utmMedium, 120),
      utmCampaign: limpiar(origenBruto.utmCampaign, 120),
      utmTerm: limpiar(origenBruto.utmTerm, 120),
      utmContent: limpiar(origenBruto.utmContent, 120),
    },
  };

  try {
    const resultado = crearLeadDesdeWeb(carga);
    if (!resultado.ok) {
      return NextResponse.json({ ok: false, error: resultado.error }, { status: 400 });
    }
    void avisarNuevoLead(carga, resultado.leadId);
    return NextResponse.json({ ok: true });
  } catch (error) {
    /* Red de seguridad: conservar el lead en el log y avisar. */
    console.error(
      JSON.stringify({
        nivel: "error",
        origen: "api-lead",
        mensaje: "Fallo guardando el lead; datos conservados en este log",
        detalle: String(error),
        carga,
      }),
    );
    void avisarNuevoLead(carga, null);
    /* El visitante no tiene la culpa: su solicitud está a salvo en el log. */
    return NextResponse.json({ ok: true });
  }
}
