import { NextResponse } from "next/server";
import { bd, esquema } from "@/db/indice";
import { usuarioActual } from "@/lib/crm/sesion";
import { filtrosDesdeParametros, listarLeads } from "@/lib/crm/leads";
import { COLUMNAS_CSV, generarCsv, type ClaveColumnaCsv } from "@/lib/crm/csv";

export const dynamic = "force-dynamic";

const TOPE_EXPORTACION = 5000;

/** Exportación CSV (solo admin) respetando búsqueda y filtros activos. */
export async function GET(peticion: Request) {
  const usuario = await usuarioActual();
  if (!usuario) {
    return NextResponse.json({ ok: false, error: "No autenticado" }, { status: 401 });
  }
  if (usuario.rol !== "admin") {
    return NextResponse.json({ ok: false, error: "Solo administración puede exportar" }, { status: 403 });
  }

  const url = new URL(peticion.url);
  const parametros: Record<string, string | undefined> = {};
  url.searchParams.forEach((valor, clave) => {
    parametros[clave] = valor;
  });

  const columnasBrutas = (parametros.columnas ?? "")
    .split(",")
    .filter((clave): clave is ClaveColumnaCsv =>
      COLUMNAS_CSV.some((columna) => columna.clave === clave),
    );
  const columnas = columnasBrutas.length
    ? columnasBrutas
    : COLUMNAS_CSV.map((columna) => columna.clave);

  /* mismas condiciones que el listado, sin paginar (con tope de seguridad) */
  const filtros = filtrosDesdeParametros(parametros);
  const { total } = listarLeads(filtros, usuario);
  const paginas = Math.min(Math.ceil(Math.max(total, 1) / 25), TOPE_EXPORTACION / 25);
  const filas: Parameters<typeof generarCsv>[0] = [];
  for (let pagina = 1; pagina <= paginas; pagina += 1) {
    const lote = listarLeads({ ...filtros, pagina }, usuario);
    filas.push(...lote.filas.map(({ lead, comercial }) => ({ ...lead, comercial })));
    if (filas.length >= TOPE_EXPORTACION) break;
  }

  const csv = generarCsv(filas, columnas);
  const fecha = new Date().toISOString().slice(0, 10);

  bd()
    .insert(esquema.actividad)
    .values({
      usuarioId: usuario.id,
      accion: "exportacion_csv",
      detalle: `${filas.length} leads · columnas: ${columnas.join(",")}`,
    })
    .run();

  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="leads-cimenta-${fecha}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
