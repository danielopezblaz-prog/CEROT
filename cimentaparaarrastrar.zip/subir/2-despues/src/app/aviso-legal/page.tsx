import type { Metadata } from "next";
import { paginasLegales } from "@/content";
import { PaginaLegal } from "@/components/PaginaLegal";

export const metadata: Metadata = {
  title: paginasLegales.avisoLegal.titulo,
  alternates: { canonical: "/aviso-legal" },
  /* Indexables: para un servicio, las legales son señal de confianza. */
  robots: { index: true, follow: true },
};

export default function AvisoLegal() {
  return <PaginaLegal datos={paginasLegales.avisoLegal} />;
}
