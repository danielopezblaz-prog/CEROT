import type { MetadataRoute } from "next";
import { marca } from "@/content";

/**
 * El panel del CRM está protegido por sesión, así que no hay fuga de datos
 * por dejarlo abierto al rastreo — pero tampoco hay ninguna razón para
 * invitar a rastrearlo. La página de gracias se excluye porque solo tiene
 * sentido después de enviar el formulario.
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/crm", "/api", "/solicitud-recibida"],
    },
    sitemap: `${marca.dominio}/sitemap.xml`,
    host: marca.dominio,
  };
}
