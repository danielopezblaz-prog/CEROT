import type { Metadata } from "next";
import dynamic from "next/dynamic";
import { paginaPorRuta } from "@/content-paginas";
import { metadatosDe } from "@/lib/metadatos";
import { Aterrizaje } from "@/components/paginas/Aterrizaje";

const Simulador = dynamic(() =>
  import("@/components/Simulador").then((m) => m.Simulador),
);

const pagina = paginaPorRuta("/simulador")!;

export const metadata: Metadata = metadatosDe(pagina);

export default function PaginaSimulador() {
  return (
    <Aterrizaje pagina={pagina}>
      {/* Sin cabecera propia: su titular ya es el h1 de la página. */}
      <Simulador conCabecera={false} />
    </Aterrizaje>
  );
}
