import type { Metadata } from "next";
import { paginaPorRuta } from "@/content-paginas";
import { metadatosDe } from "@/lib/metadatos";
import { Aterrizaje } from "@/components/paginas/Aterrizaje";

const pagina = paginaPorRuta("/audita-tu-oferta")!;

export const metadata: Metadata = metadatosDe(pagina);

export default function PaginaAuditaTuOferta() {
  return <Aterrizaje pagina={pagina} />;
}
