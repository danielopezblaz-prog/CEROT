import { NextResponse, type NextRequest } from "next/server";
import { verificarSesion, COOKIE_SESION } from "@/lib/crm/token";

/**
 * Muro del CRM: sin sesión válida no se entra en /crm ni en /api/crm.
 * Aquí solo se comprueba la firma del token (edge, sin base de datos);
 * cada página y acción vuelve a validar usuario activo y rol en servidor.
 */
export async function middleware(peticion: NextRequest) {
  const { pathname } = peticion.nextUrl;

  if (pathname === "/crm/acceder") {
    return NextResponse.next();
  }

  const token = peticion.cookies.get(COOKIE_SESION)?.value;
  const sesion = token ? await verificarSesion(token) : null;

  if (!sesion) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ ok: false, error: "No autenticado" }, { status: 401 });
    }
    const destino = new URL("/crm/acceder", peticion.url);
    return NextResponse.redirect(destino);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/crm/:path*", "/api/crm/:path*"],
};
