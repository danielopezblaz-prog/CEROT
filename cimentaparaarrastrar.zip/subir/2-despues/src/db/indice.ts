import fs from "node:fs";
import path from "node:path";
import Database from "better-sqlite3";
import { drizzle, type BetterSQLite3Database } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import * as esquema from "./esquema";

export type BaseDeDatos = BetterSQLite3Database<typeof esquema>;

/**
 * Cliente único de base de datos. SQLite en fichero (DATABASE_PATH,
 * por defecto datos/crm.db) con migraciones aplicadas al arrancar.
 * En tests, DATABASE_PATH=":memory:" crea una base efímera.
 */

declare global {
  var __baseDeDatosCrm: BaseDeDatos | undefined;
}

function abrir(): BaseDeDatos {
  const ruta = process.env.DATABASE_PATH ?? path.join(process.cwd(), "datos", "crm.db");
  if (ruta !== ":memory:") {
    fs.mkdirSync(path.dirname(ruta), { recursive: true });
  }
  const sqlite = new Database(ruta);
  sqlite.pragma("journal_mode = WAL");
  sqlite.pragma("foreign_keys = ON");
  const db = drizzle(sqlite, { schema: esquema });
  migrate(db, {
    migrationsFolder: path.join(process.cwd(), "src", "db", "migraciones"),
  });
  return db;
}

/** La instancia se conserva entre recargas de Next en desarrollo. */
export function bd(): BaseDeDatos {
  if (!globalThis.__baseDeDatosCrm) {
    globalThis.__baseDeDatosCrm = abrir();
  }
  return globalThis.__baseDeDatosCrm;
}

export { esquema };
