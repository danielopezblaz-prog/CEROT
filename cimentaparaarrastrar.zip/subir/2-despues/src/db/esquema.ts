import { sql } from "drizzle-orm";
import {
  index,
  integer,
  sqliteTable,
  text,
} from "drizzle-orm/sqlite-core";

/**
 * Esquema del CRM (SQLite vía Drizzle). Portable a Postgres: los tipos
 * usados existen en ambos dialectos y el acceso pasa siempre por Drizzle.
 */

const creadoEn = () =>
  integer("creado_en", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`);

const actualizadoEn = () =>
  integer("actualizado_en", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`);

export const usuarios = sqliteTable(
  "usuarios",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    nombre: text("nombre").notNull(),
    email: text("email").notNull().unique(),
    hashContrasena: text("hash_contrasena").notNull(),
    rol: text("rol").notNull().default("comercial"),
    activo: integer("activo", { mode: "boolean" }).notNull().default(true),
    creadoEn: creadoEn(),
    actualizadoEn: actualizadoEn(),
  },
  (tabla) => [index("idx_usuarios_activo").on(tabla.activo)],
);

export const leads = sqliteTable(
  "leads",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),

    /* — lo que recoge el formulario público — */
    nombre: text("nombre").notNull(),
    rolContacto: text("rol_contacto"),
    direccion: text("direccion"),
    viviendas: integer("viviendas"),
    email: text("email"),
    telefono: text("telefono"),
    /** El campo `contacto` tal cual lo escribió la persona. */
    contactoOriginal: text("contacto_original"),
    /** Resumen del simulador si la persona lo usó antes de escribir. */
    simulacion: text("simulacion"),
    mensaje: text("mensaje"),
    consentimientoEn: integer("consentimiento_en", { mode: "timestamp" }),

    /* — cualificación (la rellena el equipo, no el visitante) — */
    empresa: text("empresa"),
    ciudad: text("ciudad"),
    tipoObra: text("tipo_obra"),
    fechaJunta: integer("fecha_junta", { mode: "timestamp" }),
    administradorFincas: text("administrador_fincas"),
    planAyudas: text("plan_ayudas"),

    /* — gestión — */
    estado: text("estado").notNull().default("nuevo"),
    prioridad: text("prioridad").notNull().default("media"),
    valorEstimado: integer("valor_estimado"),
    comercialId: integer("comercial_id").references(() => usuarios.id),
    motivoPerdida: text("motivo_perdida"),
    posibleDuplicado: integer("posible_duplicado", { mode: "boolean" })
      .notNull()
      .default(false),
    duplicadoDe: integer("duplicado_de"),

    /* — origen — */
    fuente: text("fuente").notNull().default("web"),
    formularioOrigen: text("formulario_origen"),
    urlOrigen: text("url_origen"),
    referrer: text("referrer"),
    utmSource: text("utm_source"),
    utmMedium: text("utm_medium"),
    utmCampaign: text("utm_campaign"),
    utmTerm: text("utm_term"),
    utmContent: text("utm_content"),

    /* — fechas — */
    ultimoContactoEn: integer("ultimo_contacto_en", { mode: "timestamp" }),
    proximoSeguimientoEn: integer("proximo_seguimiento_en", {
      mode: "timestamp",
    }),
    creadoEn: creadoEn(),
    actualizadoEn: actualizadoEn(),
    eliminadoEn: integer("eliminado_en", { mode: "timestamp" }),
  },
  (tabla) => [
    index("idx_leads_email").on(tabla.email),
    index("idx_leads_telefono").on(tabla.telefono),
    index("idx_leads_estado").on(tabla.estado),
    index("idx_leads_comercial").on(tabla.comercialId),
    index("idx_leads_fuente").on(tabla.fuente),
    index("idx_leads_creado").on(tabla.creadoEn),
    index("idx_leads_seguimiento").on(tabla.proximoSeguimientoEn),
    index("idx_leads_eliminado").on(tabla.eliminadoEn),
  ],
);

export const leadHistorial = sqliteTable(
  "lead_historial",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    leadId: integer("lead_id")
      .notNull()
      .references(() => leads.id),
    /** null = acción del sistema (p. ej., creación desde la web). */
    usuarioId: integer("usuario_id").references(() => usuarios.id),
    tipo: text("tipo").notNull(),
    estadoAnterior: text("estado_anterior"),
    estadoNuevo: text("estado_nuevo"),
    comentario: text("comentario"),
    creadoEn: creadoEn(),
  },
  (tabla) => [
    index("idx_historial_lead").on(tabla.leadId),
    index("idx_historial_creado").on(tabla.creadoEn),
  ],
);

export const leadNotas = sqliteTable(
  "lead_notas",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    leadId: integer("lead_id")
      .notNull()
      .references(() => leads.id),
    usuarioId: integer("usuario_id")
      .notNull()
      .references(() => usuarios.id),
    texto: text("texto").notNull(),
    creadoEn: creadoEn(),
  },
  (tabla) => [index("idx_notas_lead").on(tabla.leadId)],
);

export const tareas = sqliteTable(
  "tareas",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    leadId: integer("lead_id")
      .notNull()
      .references(() => leads.id),
    usuarioId: integer("usuario_id")
      .notNull()
      .references(() => usuarios.id),
    titulo: text("titulo").notNull(),
    tipo: text("tipo").notNull().default("seguimiento"),
    venceEn: integer("vence_en", { mode: "timestamp" }).notNull(),
    estado: text("estado").notNull().default("pendiente"),
    completadaEn: integer("completada_en", { mode: "timestamp" }),
    creadoEn: creadoEn(),
    actualizadoEn: actualizadoEn(),
  },
  (tabla) => [
    index("idx_tareas_lead").on(tabla.leadId),
    index("idx_tareas_usuario").on(tabla.usuarioId),
    index("idx_tareas_vence").on(tabla.venceEn),
    index("idx_tareas_estado").on(tabla.estado),
  ],
);

/** Registro básico de actividad (exportaciones, accesos, altas de usuario). */
export const actividad = sqliteTable(
  "actividad",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    usuarioId: integer("usuario_id").references(() => usuarios.id),
    accion: text("accion").notNull(),
    detalle: text("detalle"),
    creadoEn: creadoEn(),
  },
  (tabla) => [index("idx_actividad_creado").on(tabla.creadoEn)],
);

export type Usuario = typeof usuarios.$inferSelect;
export type Lead = typeof leads.$inferSelect;
export type LeadNuevo = typeof leads.$inferInsert;
export type Historial = typeof leadHistorial.$inferSelect;
export type Nota = typeof leadNotas.$inferSelect;
export type Tarea = typeof tareas.$inferSelect;
