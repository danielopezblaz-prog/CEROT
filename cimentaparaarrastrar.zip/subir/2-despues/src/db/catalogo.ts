/**
 * Catálogo del CRM: estados del pipeline, tipos de tarea, prioridades,
 * fuentes y roles. TODO lo que enumera vive aquí — ampliar el CRM es
 * añadir una entrada en este archivo, no tocar media aplicación.
 *
 * El pipeline refleja el ciclo de venta real de Cimenta:
 * la "demo" es la visita + pre-informe y el cierre es el mandato
 * de gestión que vota la junta.
 */

export const ESTADOS_LEAD = [
  { clave: "nuevo", nombre: "Nuevo", color: "#5b6862", cierre: null },
  { clave: "contactado", nombre: "Contactado", color: "#1b5038", cierre: null },
  { clave: "visita", nombre: "Visita programada", color: "#25714f", cierre: null },
  { clave: "preinforme", nombre: "Pre-informe entregado", color: "#2e8a61", cierre: null },
  { clave: "junta", nombre: "En junta", color: "#7ec9a3", cierre: null },
  { clave: "ganado", nombre: "Mandato firmado", color: "#18211c", cierre: "ganado" },
  { clave: "perdido", nombre: "Perdido", color: "#8a5b5b", cierre: "perdido" },
  { clave: "no_valido", nombre: "No válido", color: "#9aa39e", cierre: "descartado" },
] as const;

export type ClaveEstadoLead = (typeof ESTADOS_LEAD)[number]["clave"];

export const ESTADO_INICIAL: ClaveEstadoLead = "nuevo";

/** Estados que se muestran como columnas del Kanban (todos, en orden). */
export const ESTADOS_PIPELINE = ESTADOS_LEAD.map((estado) => estado.clave);

export const PRIORIDADES = [
  { clave: "baja", nombre: "Baja" },
  { clave: "media", nombre: "Media" },
  { clave: "alta", nombre: "Alta" },
] as const;

export type ClavePrioridad = (typeof PRIORIDADES)[number]["clave"];

export const TIPOS_TAREA = [
  { clave: "llamada", nombre: "Llamada" },
  { clave: "email", nombre: "Email" },
  { clave: "visita", nombre: "Visita" },
  { clave: "reunion", nombre: "Reunión" },
  { clave: "whatsapp", nombre: "WhatsApp" },
  { clave: "seguimiento", nombre: "Seguimiento" },
  { clave: "otro", nombre: "Otro" },
] as const;

export type ClaveTipoTarea = (typeof TIPOS_TAREA)[number]["clave"];

/** Tipos de tarea que cuentan como contacto real con el lead. */
export const TIPOS_TAREA_CONTACTO: ClaveTipoTarea[] = [
  "llamada",
  "email",
  "visita",
  "reunion",
  "whatsapp",
];

export const ESTADOS_TAREA = [
  { clave: "pendiente", nombre: "Pendiente" },
  { clave: "en_progreso", nombre: "En progreso" },
  { clave: "completada", nombre: "Completada" },
  { clave: "cancelada", nombre: "Cancelada" },
] as const;

export type ClaveEstadoTarea = (typeof ESTADOS_TAREA)[number]["clave"];

export const FUENTES = [
  { clave: "web", nombre: "Web — formulario" },
  { clave: "telefono", nombre: "Teléfono" },
  { clave: "referido", nombre: "Referido" },
  { clave: "administrador", nombre: "Administrador de fincas" },
  { clave: "otro", nombre: "Otro" },
] as const;

export type ClaveFuente = (typeof FUENTES)[number]["clave"];

export const ROLES_USUARIO = [
  { clave: "admin", nombre: "Administración" },
  { clave: "comercial", nombre: "Comercial" },
] as const;

export type ClaveRolUsuario = (typeof ROLES_USUARIO)[number]["clave"];

/** Roles de contacto tal y como los recoge el formulario público. */
export const ROLES_CONTACTO = [
  "Presidente/a de la comunidad",
  "Vecino/a",
  "Administrador/a de fincas",
  "Empresa constructora",
] as const;

export const TIPOS_HISTORIAL = [
  "creacion",
  "estado",
  "asignacion",
  "nota",
  "tarea_creada",
  "tarea_completada",
  "edicion",
] as const;

export type ClaveTipoHistorial = (typeof TIPOS_HISTORIAL)[number];

/* ——— Ayudas de consulta ——— */

const indiceEstados = new Map(ESTADOS_LEAD.map((estado) => [estado.clave, estado]));

export function estadoLead(clave: string) {
  return indiceEstados.get(clave as ClaveEstadoLead) ?? null;
}

export function esEstadoLead(clave: string): clave is ClaveEstadoLead {
  return indiceEstados.has(clave as ClaveEstadoLead);
}

export function esPrioridad(clave: string): clave is ClavePrioridad {
  return PRIORIDADES.some((prioridad) => prioridad.clave === clave);
}

export function esTipoTarea(clave: string): clave is ClaveTipoTarea {
  return TIPOS_TAREA.some((tipo) => tipo.clave === clave);
}

export function esEstadoTarea(clave: string): clave is ClaveEstadoTarea {
  return ESTADOS_TAREA.some((estado) => estado.clave === clave);
}

export function esFuente(clave: string): clave is ClaveFuente {
  return FUENTES.some((fuente) => fuente.clave === clave);
}

export function esRolUsuario(clave: string): clave is ClaveRolUsuario {
  return ROLES_USUARIO.some((rol) => rol.clave === clave);
}
