CREATE TABLE `actividad` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`usuario_id` integer,
	`accion` text NOT NULL,
	`detalle` text,
	`creado_en` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_actividad_creado` ON `actividad` (`creado_en`);--> statement-breakpoint
CREATE TABLE `lead_historial` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`usuario_id` integer,
	`tipo` text NOT NULL,
	`estado_anterior` text,
	`estado_nuevo` text,
	`comentario` text,
	`creado_en` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_historial_lead` ON `lead_historial` (`lead_id`);--> statement-breakpoint
CREATE INDEX `idx_historial_creado` ON `lead_historial` (`creado_en`);--> statement-breakpoint
CREATE TABLE `lead_notas` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`usuario_id` integer NOT NULL,
	`texto` text NOT NULL,
	`creado_en` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_notas_lead` ON `lead_notas` (`lead_id`);--> statement-breakpoint
CREATE TABLE `leads` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`nombre` text NOT NULL,
	`rol_contacto` text,
	`direccion` text,
	`viviendas` integer,
	`email` text,
	`telefono` text,
	`contacto_original` text,
	`simulacion` text,
	`mensaje` text,
	`consentimiento_en` integer,
	`empresa` text,
	`ciudad` text,
	`tipo_obra` text,
	`fecha_junta` integer,
	`administrador_fincas` text,
	`plan_ayudas` text,
	`estado` text DEFAULT 'nuevo' NOT NULL,
	`prioridad` text DEFAULT 'media' NOT NULL,
	`valor_estimado` integer,
	`comercial_id` integer,
	`motivo_perdida` text,
	`posible_duplicado` integer DEFAULT false NOT NULL,
	`duplicado_de` integer,
	`fuente` text DEFAULT 'web' NOT NULL,
	`formulario_origen` text,
	`url_origen` text,
	`referrer` text,
	`utm_source` text,
	`utm_medium` text,
	`utm_campaign` text,
	`utm_term` text,
	`utm_content` text,
	`ultimo_contacto_en` integer,
	`proximo_seguimiento_en` integer,
	`creado_en` integer DEFAULT (unixepoch()) NOT NULL,
	`actualizado_en` integer DEFAULT (unixepoch()) NOT NULL,
	`eliminado_en` integer,
	FOREIGN KEY (`comercial_id`) REFERENCES `usuarios`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_leads_email` ON `leads` (`email`);--> statement-breakpoint
CREATE INDEX `idx_leads_telefono` ON `leads` (`telefono`);--> statement-breakpoint
CREATE INDEX `idx_leads_estado` ON `leads` (`estado`);--> statement-breakpoint
CREATE INDEX `idx_leads_comercial` ON `leads` (`comercial_id`);--> statement-breakpoint
CREATE INDEX `idx_leads_fuente` ON `leads` (`fuente`);--> statement-breakpoint
CREATE INDEX `idx_leads_creado` ON `leads` (`creado_en`);--> statement-breakpoint
CREATE INDEX `idx_leads_seguimiento` ON `leads` (`proximo_seguimiento_en`);--> statement-breakpoint
CREATE INDEX `idx_leads_eliminado` ON `leads` (`eliminado_en`);--> statement-breakpoint
CREATE TABLE `tareas` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`usuario_id` integer NOT NULL,
	`titulo` text NOT NULL,
	`tipo` text DEFAULT 'seguimiento' NOT NULL,
	`vence_en` integer NOT NULL,
	`estado` text DEFAULT 'pendiente' NOT NULL,
	`completada_en` integer,
	`creado_en` integer DEFAULT (unixepoch()) NOT NULL,
	`actualizado_en` integer DEFAULT (unixepoch()) NOT NULL,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_tareas_lead` ON `tareas` (`lead_id`);--> statement-breakpoint
CREATE INDEX `idx_tareas_usuario` ON `tareas` (`usuario_id`);--> statement-breakpoint
CREATE INDEX `idx_tareas_vence` ON `tareas` (`vence_en`);--> statement-breakpoint
CREATE INDEX `idx_tareas_estado` ON `tareas` (`estado`);--> statement-breakpoint
CREATE TABLE `usuarios` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`nombre` text NOT NULL,
	`email` text NOT NULL,
	`hash_contrasena` text NOT NULL,
	`rol` text DEFAULT 'comercial' NOT NULL,
	`activo` integer DEFAULT true NOT NULL,
	`creado_en` integer DEFAULT (unixepoch()) NOT NULL,
	`actualizado_en` integer DEFAULT (unixepoch()) NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `usuarios_email_unique` ON `usuarios` (`email`);--> statement-breakpoint
CREATE INDEX `idx_usuarios_activo` ON `usuarios` (`activo`);