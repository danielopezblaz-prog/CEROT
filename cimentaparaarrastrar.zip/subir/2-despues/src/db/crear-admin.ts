/**
 * Crea (o repara) el primer usuario administrador en producción.
 *
 * Uso:
 *   ADMIN_NOMBRE="Nombre" ADMIN_EMAIL="correo@cimenta.es" ADMIN_CONTRASENA="…" npm run db:admin
 */
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { bd, esquema } from "./indice";

const nombre = process.env.ADMIN_NOMBRE?.trim();
const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
const contrasena = process.env.ADMIN_CONTRASENA;

if (!nombre || !email || !contrasena) {
  console.error("Faltan variables: ADMIN_NOMBRE, ADMIN_EMAIL y ADMIN_CONTRASENA.");
  process.exit(1);
}
if (contrasena.length < 10) {
  console.error("La contraseña debe tener al menos 10 caracteres.");
  process.exit(1);
}

const db = bd();
const hash = bcrypt.hashSync(contrasena, 12);
const existente = db
  .select()
  .from(esquema.usuarios)
  .where(eq(esquema.usuarios.email, email))
  .get();

if (existente) {
  db.update(esquema.usuarios)
    .set({ nombre, hashContrasena: hash, rol: "admin", activo: true, actualizadoEn: new Date() })
    .where(eq(esquema.usuarios.id, existente.id))
    .run();
  console.log(`Usuario ${email} actualizado como administrador.`);
} else {
  db.insert(esquema.usuarios)
    .values({ nombre, email, hashContrasena: hash, rol: "admin" })
    .run();
  console.log(`Administrador ${email} creado.`);
}
