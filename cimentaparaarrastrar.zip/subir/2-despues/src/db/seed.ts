/**
 * Semillas de DESARROLLO: 1 admin, 2 comerciales y ~20 leads con
 * actividad, notas y tareas repartidas en el tiempo para que el
 * dashboard y el pipeline se vean con datos.
 *
 * ⚠️ Credenciales solo para desarrollo. En producción, crea el admin
 * real con `npm run db:admin` y no ejecutes nunca este script.
 */
import bcrypt from "bcryptjs";
import { bd, esquema } from "./indice";
import { ESTADOS_LEAD, TIPOS_TAREA } from "./catalogo";

const db = bd();

const DIA = 24 * 60 * 60 * 1000;
const ahora = Date.now();
const hace = (dias: number, horas = 10) =>
  new Date(ahora - dias * DIA + horas * 60 * 60 * 1000 - 10 * 60 * 60 * 1000);
const dentroDe = (dias: number, horas = 10) => hace(-dias, horas);

async function sembrar() {
  const yaHay = db.select().from(esquema.usuarios).all();
  if (yaHay.length > 0) {
    console.log("La base de datos ya tiene usuarios; no se siembra dos veces.");
    return;
  }

  const hash = (contrasena: string) => bcrypt.hashSync(contrasena, 10);

  const admin = db
    .insert(esquema.usuarios)
    .values({
      nombre: "Ana Dirección",
      email: "admin@cimenta.dev",
      hashContrasena: hash("cimenta-admin-dev"),
      rol: "admin",
    })
    .returning().get();
  const comercial1 = db
    .insert(esquema.usuarios)
    .values({
      nombre: "Carlos Comercial",
      email: "carlos@cimenta.dev",
      hashContrasena: hash("cimenta-carlos-dev"),
      rol: "comercial",
    })
    .returning().get();
  const comercial2 = db
    .insert(esquema.usuarios)
    .values({
      nombre: "Lucía Comercial",
      email: "lucia@cimenta.dev",
      hashContrasena: hash("cimenta-lucia-dev"),
      rol: "comercial",
    })
    .returning().get();

  const comerciales = [comercial1.id, comercial2.id];

  type Semilla = {
    nombre: string;
    rolContacto: string;
    direccion: string;
    viviendas: number | null;
    email?: string;
    telefono?: string;
    estado: string;
    prioridad?: string;
    valorEstimado?: number;
    fuente?: string;
    diasAtras: number;
    simulacion?: string;
    motivoPerdida?: string;
    seguimientoEnDias?: number | null;
  };

  const semillas: Semilla[] = [
    { nombre: "María Gómez", rolContacto: "Presidente/a de la comunidad", direccion: "C/ Alcalá 214, Madrid", viviendas: 24, email: "maria.gomez@ejemplo.es", estado: "junta", prioridad: "alta", valorEstimado: 216000, diasAtras: 55, simulacion: "24 viv · Fachada + cubierta · 9.000 €/viv · ayuda 65 % · cuota ~35 €/mes", seguimientoEnDias: 3 },
    { nombre: "José Luis Prieto", rolContacto: "Administrador/a de fincas", direccion: "Av. de la Albufera 89, Madrid", viviendas: 40, email: "jl.prieto@fincasprieto.es", telefono: "+34 611 22 33 44", estado: "preinforme", prioridad: "alta", valorEstimado: 480000, diasAtras: 48, seguimientoEnDias: 1 },
    { nombre: "Carmen Ruiz", rolContacto: "Vecino/a", direccion: "C/ Bravo Murillo 120, Madrid", viviendas: 18, telefono: "+34 699 88 77 66", estado: "contactado", diasAtras: 44, seguimientoEnDias: 2 },
    { nombre: "Antonio Vega", rolContacto: "Presidente/a de la comunidad", direccion: "C/ Embajadores 55, Madrid", viviendas: 12, email: "avega@ejemplo.es", estado: "ganado", valorEstimado: 132000, diasAtras: 60, seguimientoEnDias: null },
    { nombre: "Fincas Aluche SL", rolContacto: "Administrador/a de fincas", direccion: "C/ Camarena 33, Madrid", viviendas: 60, email: "info@fincasaluche.es", estado: "visita", prioridad: "alta", valorEstimado: 540000, fuente: "administrador", diasAtras: 30, seguimientoEnDias: 0 },
    { nombre: "Rosa Fernández", rolContacto: "Vecino/a", direccion: "C/ López de Hoyos 170, Madrid", viviendas: 28, email: "rosa.f@ejemplo.es", telefono: "+34 655 44 33 22", estado: "perdido", valorEstimado: 250000, diasAtras: 40, motivoPerdida: "La junta votó posponer la obra un año" },
    { nombre: "Miguel Ángel Torres", rolContacto: "Presidente/a de la comunidad", direccion: "Paseo de Extremadura 240, Madrid", viviendas: 36, email: "matorres@ejemplo.es", estado: "preinforme", valorEstimado: 320000, diasAtras: 26, seguimientoEnDias: 5 },
    { nombre: "Constructora Herso", rolContacto: "Empresa constructora", direccion: "—", viviendas: null, email: "obras@herso.es", estado: "no_valido", diasAtras: 35, motivoPerdida: "Empresa: no es cliente, pasa a lista de aliados" },
    { nombre: "Pilar Sánchez", rolContacto: "Presidente/a de la comunidad", direccion: "C/ Marcelo Usera 44, Madrid", viviendas: 20, telefono: "+34 622 11 00 99", estado: "visita", prioridad: "media", valorEstimado: 180000, diasAtras: 20, seguimientoEnDias: 1 },
    { nombre: "Fernando Ortiz", rolContacto: "Vecino/a", direccion: "C/ Alcántara 21, Madrid", viviendas: 16, email: "fortiz@ejemplo.es", estado: "contactado", diasAtras: 17, seguimientoEnDias: 4 },
    { nombre: "Comunidad García Noblejas 71", rolContacto: "Presidente/a de la comunidad", direccion: "C/ García Noblejas 71, Madrid", viviendas: 48, email: "presidencia.gn71@ejemplo.es", estado: "junta", prioridad: "alta", valorEstimado: 430000, diasAtras: 24, simulacion: "48 viv · Integral · 11.500 €/viv · ayuda 80 % · cuota ~19 €/mes", seguimientoEnDias: 7 },
    { nombre: "Teresa Molina", rolContacto: "Administrador/a de fincas", direccion: "C/ Antonio López 98, Madrid", viviendas: 32, email: "tmolina@fincasmolina.es", estado: "ganado", valorEstimado: 288000, diasAtras: 28, fuente: "administrador" },
    { nombre: "Ángel Navarro", rolContacto: "Vecino/a", direccion: "Av. de Oporto 12, Madrid", viviendas: 22, telefono: "+34 688 55 44 33", estado: "nuevo", diasAtras: 12, seguimientoEnDias: 0 },
    { nombre: "Marta Iglesias", rolContacto: "Presidente/a de la comunidad", direccion: "C/ Francos Rodríguez 60, Madrid", viviendas: 26, email: "marta.iglesias@ejemplo.es", estado: "contactado", valorEstimado: 234000, diasAtras: 10, simulacion: "26 viv · Fachada · 6.300 €/viv · ayuda 40 % · cuota ~42 €/mes", seguimientoEnDias: 2 },
    { nombre: "Julián Castro", rolContacto: "Presidente/a de la comunidad", direccion: "C/ Sierra de Cadí 8, Madrid", viviendas: 14, email: "jcastro@ejemplo.es", telefono: "+34 677 66 55 44", estado: "perdido", valorEstimado: 126000, diasAtras: 15, motivoPerdida: "Eligieron gestionarlo con su administrador" },
    { nombre: "Beatriz Lara", rolContacto: "Vecino/a", direccion: "C/ Oca 82, Madrid", viviendas: 30, email: "blara@ejemplo.es", estado: "visita", valorEstimado: 270000, diasAtras: 7, seguimientoEnDias: 1 },
    { nombre: "Comunidad Ntra. Sra. de la Luz 14", rolContacto: "Presidente/a de la comunidad", direccion: "C/ Ntra. Sra. de la Luz 14, Madrid", viviendas: 44, email: "luz14@ejemplo.es", estado: "nuevo", prioridad: "alta", valorEstimado: 396000, diasAtras: 4, simulacion: "44 viv · Integral · 12.000 €/viv · ayuda 80 % · cuota ~21 €/mes", seguimientoEnDias: 1 },
    { nombre: "Sergio Peña", rolContacto: "Vecino/a", direccion: "C/ Payaso Fofó 21, Madrid", viviendas: null, telefono: "+34 644 33 22 11", estado: "nuevo", diasAtras: 2, seguimientoEnDias: 2 },
    { nombre: "Isabel Quintana", rolContacto: "Administrador/a de fincas", direccion: "C/ Arturo Soria 145, Madrid", viviendas: 52, email: "iquintana@qfincas.es", estado: "contactado", prioridad: "alta", valorEstimado: 470000, fuente: "administrador", diasAtras: 1, seguimientoEnDias: 3 },
    { nombre: "David Marín", rolContacto: "Presidente/a de la comunidad", direccion: "C/ Puerto de Canfranc 31, Madrid", viviendas: 34, email: "dmarin@ejemplo.es", estado: "nuevo", diasAtras: 0, simulacion: "34 viv · Fachada + cubierta · 8.250 €/viv · ayuda 65 % · cuota ~30 €/mes", seguimientoEnDias: 1 },
    { nombre: "María Gómez", rolContacto: "Vecino/a", direccion: "C/ Alcalá 214, Madrid", viviendas: 24, email: "maria.gomez@ejemplo.es", estado: "nuevo", diasAtras: 1, seguimientoEnDias: null },
  ];

  let indice = 0;
  for (const semilla of semillas) {
    indice += 1;
    const creado = hace(semilla.diasAtras, 9 + (indice % 8));
    const cerrado = semilla.estado === "ganado" || semilla.estado === "perdido" || semilla.estado === "no_valido";
    const sinAsignar = semilla.estado === "nuevo" && indice % 3 === 0;
    const comercialId = sinAsignar ? null : comerciales[indice % 2];
    const esDuplicado = indice === semillas.length; // la última repite email

    const lead = db
      .insert(esquema.leads)
      .values({
        nombre: semilla.nombre,
        rolContacto: semilla.rolContacto,
        direccion: semilla.direccion,
        viviendas: semilla.viviendas,
        email: semilla.email ?? null,
        telefono: semilla.telefono ?? null,
        contactoOriginal: semilla.email ?? semilla.telefono ?? null,
        simulacion: semilla.simulacion ?? null,
        consentimientoEn: creado,
        estado: semilla.estado,
        prioridad: semilla.prioridad ?? "media",
        valorEstimado: semilla.valorEstimado ?? null,
        comercialId,
        motivoPerdida: semilla.motivoPerdida ?? null,
        posibleDuplicado: esDuplicado,
        duplicadoDe: esDuplicado ? 1 : null,
        fuente: semilla.fuente ?? "web",
        formularioOrigen: "pre-informe",
        urlOrigen: "https://cimenta.es/#contacto",
        utmSource: indice % 4 === 0 ? "google" : null,
        utmMedium: indice % 4 === 0 ? "cpc" : null,
        utmCampaign: indice % 4 === 0 ? "rehabilitacion-madrid" : null,
        ultimoContactoEn: semilla.estado === "nuevo" ? null : hace(Math.max(0, semilla.diasAtras - 2)),
        proximoSeguimientoEn:
          cerrado || semilla.seguimientoEnDias === null || semilla.seguimientoEnDias === undefined
            ? null
            : semilla.seguimientoEnDias <= 0
              ? hace(1 - semilla.seguimientoEnDias)
              : dentroDe(semilla.seguimientoEnDias),
        creadoEn: creado,
        actualizadoEn: creado,
      })
      .returning().get();

    db.insert(esquema.leadHistorial)
      .values({
        leadId: lead.id,
        usuarioId: null,
        tipo: "creacion",
        estadoNuevo: "nuevo",
        comentario: "Lead recibido desde el formulario de la web",
        creadoEn: creado,
      })
      .run();

    /* recorrido por el pipeline hasta su estado actual */
    const orden = ESTADOS_LEAD.map((estado) => estado.clave);
    const hastaIndice = orden.indexOf(semilla.estado as (typeof orden)[number]);
    let anterior = "nuevo";
    for (let paso = 1; paso <= hastaIndice && hastaIndice <= 5; paso += 1) {
      const clave = orden[paso];
      db.insert(esquema.leadHistorial)
        .values({
          leadId: lead.id,
          usuarioId: comercialId ?? admin.id,
          tipo: "estado",
          estadoAnterior: anterior,
          estadoNuevo: clave,
          creadoEn: hace(Math.max(0, semilla.diasAtras - paso * 3), 12),
        })
        .run();
      anterior = clave;
    }
    if (hastaIndice > 5) {
      db.insert(esquema.leadHistorial)
        .values({
          leadId: lead.id,
          usuarioId: comercialId ?? admin.id,
          tipo: "estado",
          estadoAnterior: "junta",
          estadoNuevo: semilla.estado,
          comentario: semilla.motivoPerdida ?? null,
          creadoEn: hace(Math.max(0, semilla.diasAtras - 12), 13),
        })
        .run();
    }

    if (comercialId) {
      db.insert(esquema.leadHistorial)
        .values({
          leadId: lead.id,
          usuarioId: admin.id,
          tipo: "asignacion",
          comentario: `Asignado a ${comercialId === comercial1.id ? comercial1.nombre : comercial2.nombre}`,
          creadoEn: hace(Math.max(0, semilla.diasAtras - 1), 11),
        })
        .run();
    }

    if (indice % 2 === 0) {
      db.insert(esquema.leadNotas)
        .values({
          leadId: lead.id,
          usuarioId: comercialId ?? admin.id,
          texto:
            indice % 4 === 0
              ? "Edificio de los 70 con ITE desfavorable en fachada. Muy receptivos a la financiación por cuotas."
              : "Prefiere que llamemos por la tarde. La junta se reúne el primer jueves de cada mes.",
          creadoEn: hace(Math.max(0, semilla.diasAtras - 2), 17),
        })
        .run();
    }

    if (!cerrado) {
      const tipo = TIPOS_TAREA[indice % TIPOS_TAREA.length].clave;
      const vence = semilla.seguimientoEnDias === null || semilla.seguimientoEnDias === undefined
        ? dentroDe(6)
        : semilla.seguimientoEnDias <= 0
          ? hace(1 - semilla.seguimientoEnDias, 12)
          : dentroDe(semilla.seguimientoEnDias, 12);
      db.insert(esquema.tareas)
        .values({
          leadId: lead.id,
          usuarioId: comercialId ?? admin.id,
          titulo:
            tipo === "visita"
              ? "Visita al edificio para tomar datos"
              : tipo === "llamada"
                ? "Llamar para cerrar fecha de visita"
                : "Seguimiento del pre-informe",
          tipo,
          venceEn: vence,
          estado: "pendiente",
          creadoEn: hace(Math.max(0, semilla.diasAtras - 1), 9),
        })
        .run();
    }

    if (indice % 3 === 0) {
      db.insert(esquema.tareas)
        .values({
          leadId: lead.id,
          usuarioId: comercialId ?? admin.id,
          titulo: "Primera llamada de contacto",
          tipo: "llamada",
          venceEn: hace(Math.max(0, semilla.diasAtras - 1), 12),
          estado: "completada",
          completadaEn: hace(Math.max(0, semilla.diasAtras - 1), 13),
          creadoEn: hace(semilla.diasAtras, 10),
        })
        .run();
    }
  }

  console.log("Semillas creadas:");
  console.log("  admin@cimenta.dev / cimenta-admin-dev  (admin)");
  console.log("  carlos@cimenta.dev / cimenta-carlos-dev (comercial)");
  console.log("  lucia@cimenta.dev / cimenta-lucia-dev  (comercial)");
  console.log(`  ${semillas.length} leads con historial, notas y tareas.`);
  console.log("⚠️  Solo desarrollo: nunca uses estas credenciales en producción.");
}

sembrar().catch((error) => {
  console.error(error);
  process.exit(1);
});
