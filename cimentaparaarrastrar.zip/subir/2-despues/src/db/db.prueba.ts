import { beforeAll, describe, expect, it } from "vitest";
import { eq, isNull, and } from "drizzle-orm";
import { bd, esquema, type BaseDeDatos } from "./indice";
import {
  ESTADOS_LEAD,
  ESTADO_INICIAL,
  esEstadoLead,
  estadoLead,
} from "./catalogo";

describe("catálogo", () => {
  it("tiene el pipeline del ciclo real con cierres definidos", () => {
    expect(ESTADOS_LEAD.map((estado) => estado.clave)).toEqual([
      "nuevo",
      "contactado",
      "visita",
      "preinforme",
      "junta",
      "ganado",
      "perdido",
      "no_valido",
    ]);
    expect(ESTADO_INICIAL).toBe("nuevo");
    expect(estadoLead("ganado")?.cierre).toBe("ganado");
    expect(esEstadoLead("inventado")).toBe(false);
  });
});

describe("base de datos", () => {
  let db: BaseDeDatos;

  beforeAll(() => {
    db = bd();
  });

  it("migra el esquema y aplica valores por defecto", () => {
    const usuario = db
      .insert(esquema.usuarios)
      .values({ nombre: "Prueba", email: "prueba@cimenta.dev", hashContrasena: "x" })
      .returning().get();
    expect(usuario.rol).toBe("comercial");
    expect(usuario.activo).toBe(true);

    const lead = db
      .insert(esquema.leads)
      .values({ nombre: "Lead de prueba", contactoOriginal: "600 000 000" })
      .returning().get();
    expect(lead.estado).toBe(ESTADO_INICIAL);
    expect(lead.prioridad).toBe("media");
    expect(lead.fuente).toBe("web");
    expect(lead.eliminadoEn).toBeNull();
  });

  it("el borrado es lógico: el lead sigue existiendo con eliminadoEn", () => {
    const lead = db
      .insert(esquema.leads)
      .values({ nombre: "Para borrar" })
      .returning().get();
    db.update(esquema.leads)
      .set({ eliminadoEn: new Date() })
      .where(eq(esquema.leads.id, lead.id))
      .run();

    const visibles = db
      .select()
      .from(esquema.leads)
      .where(and(eq(esquema.leads.id, lead.id), isNull(esquema.leads.eliminadoEn)))
      .all();
    expect(visibles).toHaveLength(0);

    const crudo = db
      .select()
      .from(esquema.leads)
      .where(eq(esquema.leads.id, lead.id))
      .get();
    expect(crudo?.eliminadoEn).toBeInstanceOf(Date);
  });

  it("el historial enlaza con el lead y admite acciones del sistema", () => {
    const lead = db.insert(esquema.leads).values({ nombre: "Con historia" }).returning().get();
    db.insert(esquema.leadHistorial)
      .values({ leadId: lead.id, usuarioId: null, tipo: "creacion", estadoNuevo: "nuevo" })
      .run();
    const filas = db
      .select()
      .from(esquema.leadHistorial)
      .where(eq(esquema.leadHistorial.leadId, lead.id))
      .all();
    expect(filas).toHaveLength(1);
    expect(filas[0].usuarioId).toBeNull();
  });
});
