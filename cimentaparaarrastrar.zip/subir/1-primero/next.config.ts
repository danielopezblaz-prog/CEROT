import type { NextConfig } from "next";

const config: NextConfig = {
  reactStrictMode: true,
  /* Servidor autocontenido: lo que necesita el contenedor de despliegue
     en un nodo con disco (Railway, Fly.io o Render). Ver Dockerfile. */
  output: "standalone",
  /* better-sqlite3 es un módulo nativo: se carga en tiempo de ejecución,
     no se empaqueta. */
  serverExternalPackages: ["better-sqlite3"],
  /* CSS crítico inline: elimina la petición bloqueante de la hoja de estilos. */
  experimental: {
    inlineCss: true,
  },
};

export default config;
