# Lanzamiento de Cimenta

Checklist operativo para sacar la web al mercado. Va en orden de ejecución:
primero lo que impide publicar, luego dónde publicar, después cómo medir sin
saltarse la ley, y solo al final SEO y anuncios.

Lo que ya está hecho en el código lleva `[x]`. Lo que depende de una decisión
tuya o de un trámite fuera del repositorio, `[ ]`.

---

## 1 · Antes de publicar

- [x] `robots.txt` excluye `/crm`, `/api` y `/solicitud-recibida`.
- [x] `sitemap.xml` lista la home, las cinco páginas de aterrizaje y las legales.
- [x] Las páginas legales se indexan (son señal de confianza para un servicio).
- [x] Página de gracias con URL propia: `/solicitud-recibida`, con destino
      estable para medir conversiones.
- [x] Analítica sin cookies lista para activar (no carga nada hasta que la
      configuras).
- [ ] **Decidir teléfono y dirección públicos** y rellenarlos en
      `src/content.ts` → `marca.telefono`, `marca.telefonoE164` y
      `marca.direccion`. Todo lo que los usa —pie, JSON-LD, ficha de
      contacto— aparece solo en cuanto existan.
- [ ] **Completar el aviso legal** con denominación, NIF y domicilio: lo exige
      el art. 10 de la LSSI. Está marcado con un comentario en `src/content.ts`.

---

## 2 · El nombre: consultoría, gestor o agente

Son tres figuras distintas y conviene no mezclarlas:

| | Consultoría | Gestor de la rehabilitación | Agente rehabilitador |
|---|---|---|---|
| Tramita las ayudas | sí | sí | sí |
| Compara presupuestos | sí | sí | normalmente no: la obra es suya |
| Redacta proyecto y dirige obra | no | no | sí |
| Cesión del derecho de cobro | no | no | es su modelo habitual |

La marca es **«Consultores en rehabilitación»** y la web explica las tres
figuras en `/agente-rehabilitador-o-gestor`: capta el tráfico del término que
no usamos y de paso nos distingue.

- [ ] **Preguntar en la Dirección General de Vivienda y Rehabilitación de la
      Comunidad de Madrid** si existe un registro de agentes y gestores y qué
      exige. Algunas comunidades lo tienen (la Valenciana, por ejemplo) y
      condiciona si Cimenta puede llamarse «gestor de la rehabilitación».
- [ ] Cuando esté confirmado, poner `PUEDE_LLAMARSE_GESTOR = true` en
      `src/content-paginas.ts`. Ese único cambio ajusta el texto del servicio.

---

## 3 · Dónde publicar

La web y el CRM tienen necesidades opuestas: la web pública va perfecta sin
servidor, pero **el CRM guarda su base de datos en un fichero SQLite**. En una
plataforma con sistema de ficheros efímero perdería los leads en cada
despliegue.

**Recomendación para arrancar: todo en un nodo con disco** (Railway, Fly.io o
Render, ~5-20 €/mes). SQLite sigue funcionando sin tocar código. Ya está
preparado: `Dockerfile` + `output: "standalone"`.

- [ ] Crear el servicio y **montar un volumen persistente en `/datos`**.
- [ ] Variables de entorno del servicio: `SESSION_SECRET` (obligatoria),
      `RESEND_API_KEY`, `CRM_EMAIL_AVISOS`, `CRM_EMAIL_REMITENTE`.
- [ ] Registrar `cimenta.es` y apuntar el DNS.
- [ ] Comprobar que `marca.dominio` de `src/content.ts` coincide con el
      dominio real: de ahí salen canónicas, sitemap y Open Graph.
- [ ] Crear el primer administrador con `npm run db:admin`.
      **Nunca `npm run db:seed` en producción** — son datos de desarrollo.

Cuando haya concurrencia real en el CRM o quieras copias de seguridad
gestionadas, migrar a Postgres (Neon o Supabase). El acceso ya pasa todo por
Drizzle, así que el cambio queda acotado al esquema y la conexión.

### Correo del dominio — no es un detalle

Los avisos de lead salen por Resend. Sin los tres registros DNS acaban en
spam, y con ellos el aviso de que ha entrado un lead.

- [ ] **SPF**, **DKIM** y **DMARC** configurados el mismo día que apuntes el
      dominio, antes de publicar nada.
- [ ] Enviarte un lead de prueba a ti mismo y comprobar el circuito completo:
      formulario → CRM → correo en la bandeja de entrada (no en spam).

---

## 4 · Medir sin multa

Hoy la política de privacidad dice que el sitio no usa cookies de seguimiento.
Eso es un compromiso legal y determina qué se puede instalar.

### Ahora: analítica sin cookies, sin banner

La guía de la AEPD sobre cookies de medición de audiencia (11-01-2024) exime
del consentimiento si la herramienta cumple **las cinco condiciones**: mide
solo este sitio, se trata solo por cuenta del editor, no permite seguir al
usuario entre webs, no se combina con datos de terceros y no se cede.
Plausible, Umami y Matomo autoalojado sin cookies las cumplen.

- [ ] Contratar o desplegar la herramienta y rellenar `NEXT_PUBLIC_ANALITICA_*`
      (ver `.env.example`). Sin esas variables no se carga ningún script.

### El día que enciendas Google Ads

Ese mismo día, no antes y sobre todo no después:

- [ ] Banner de consentimiento con **CMP certificado por Google**.
- [ ] **Consent Mode v2** (obligatorio en el EEE desde marzo de 2024 para
      conversiones y remarketing).
- [ ] Rechazar tan fácil como aceptar; nada se dispara antes del «sí».
- [ ] **Reescribir la sección de cookies de la política de privacidad**: la
      frase «no utiliza cookies de seguimiento» deja de ser cierta.

### La alternativa que ya funciona: medir desde el CRM

Cada lead guarda sus UTM y el panel del CRM los agrupa por campaña
(«Atribución por campaña», y también salen en el CSV). Cruzando el gasto de
cada campaña con esa tabla sale el coste por mandato firmado, **sin un solo
píxel y sin depender del consentimiento de nadie**. Mide el expediente, no el
clic — que es lo único que factura.

---

## 5 · Páginas

Primera tanda, ya publicada:

| URL | Búsqueda que ataca |
|---|---|
| `/plan-rehabilita-madrid` | «plan rehabilita madrid 2026», «plazo ayudas rehabilitación madrid» |
| `/simulador` | «cuánto cuesta rehabilitar mi fachada», «cuánto dan de ayuda por vivienda» |
| `/audita-tu-oferta` | «segunda opinión presupuesto obra», «me parece caro este presupuesto» |
| `/administradores-de-fincas` | el canal prescriptor número uno |
| `/agente-rehabilitador-o-gestor` | el término que no usamos, captado explicándolo |

Segunda tanda, pendiente:

- [ ] `/subvenciones-rehabilitacion-madrid` — la cabecera del tema, enlaza al resto.
- [ ] `/fachada` y `/ascensor` — la obra más buscada y la de accesibilidad.
- [ ] `/quienes-somos` y `/casos` — no traen tráfico: cierran la venta. Necesitan
      cara, nombre y un expediente real, así que dependen de ti.

Añadir una página es añadir una entrada a `PAGINAS` en
`src/content-paginas.ts` y una carpeta en `src/app/`. El sitemap y el pie se
rellenan solos.

---

## 6 · SEO local — lo más rentable, y es gratis

- [ ] Alta en el **Perfil de Empresa en Google** como *empresa de servicio en
      área*: se puede ocultar la dirección si no atiendes en oficina.
- [ ] Hace falta una dirección real **para verificar**, aunque luego se oculte.
      La verificación puede pedir vídeo o videollamada.
- [ ] Definir el área: Madrid capital y los municipios donde quieras trabajar
      (están en `marca.areaServicio`).
- [ ] Teléfono y dirección **idénticos carácter por carácter** en la web y en
      el perfil.

Reseñas: pedirlas al cerrar expediente, cuando la ayuda ya se ha cobrado, y al
presidente de la comunidad. Nunca comprarlas ni incentivarlas con regalos.
Responder a todas, también a las malas.

---

## 7 · Contenidos

Las búsquedas de ayudas en Madrid las ocupan sedes oficiales y empresas de
fachadas. No hay nadie independiente defendiendo a la comunidad — ese es el
hueco.

Una constructora no puede publicar «cómo saber si tu constructora te está
cobrando de más». Nosotros sí, y ese contenido es a la vez el mejor imán de
búsquedas y el argumento de venta.

Cadencia realista para una persona sola: **dos piezas al mes**, siempre con la
misma estructura — problema, números reales, qué hacer, formulario.

---

## 8 · Anuncios

Referencias de mercado español para servicios locales: CPC 0,50-2 € en
términos normales y 4-8 € en los competidos, coste por lead 70-250 €, mínimo
operativo 800-1.200 €/mes para tener datos con los que decidir.

| Campaña | Cuándo | % del gasto |
|---|---|---|
| Convocatoria («plan rehabilita madrid 2026») | al lanzar | 40 % |
| Problema concreto («subvención fachada comunidad») | al lanzar | 30 % |
| Defensa («segunda opinión presupuesto») | mes 2+ | 15 % |
| Marca («cimenta») | al lanzar | 5 % |
| Retorno (recordatorio a quien ya visitó) | mes 3+ | 10 % |

**No comprar** genéricos como «reformas Madrid» o «rehabilitación de
edificios»: caros, llenos de constructoras y con intención equivocada.

Negativas desde el primer día:

```
empleo, curso, ayuntamiento, sede electrónica, gratis, particular,
alquiler, oposiciones, trabajo, subvenciones agricultura, pdf, boe
```

Sin esa lista, media inversión se va en gente que busca el trámite oficial.

- [ ] Confirmar presupuesto: 1.000 €/mes durante 3 meses. Por debajo no hay
      datos para optimizar; por encima se arriesga sin saber qué funciona.
- [ ] Etiquetar **todas** las campañas con UTM. Es lo que hace funcionar la
      atribución del CRM.

---

## 9 · Calendario

El reloj no lo pones tú: **el 30 de septiembre cierra Rehabilita Madrid 2026**.

| Semanas | Qué |
|---|---|
| 1-2 | Bloqueantes, desplegar, dominio y correo |
| 1-2 | Analítica sin cookies + Perfil de Empresa en Google |
| 2-5 | Las páginas de la primera tanda (hechas) y las de la segunda |
| 3-12 | Ronda de administradores de fincas |
| hasta 30-sep | Presentar expedientes a Rehabilita Madrid 2026 |
| 5+ | Encender Google Ads (con banner y CMP) |
| continuo | Dos contenidos al mes |

Los anuncios no se encienden hasta la semana 5, cuando ya hay páginas donde
aterrizar y analítica que mida. Encenderlos antes es pagar por visitas que no
puedes ni recibir bien ni contar.

---

## 10 · Por confirmar

| Asunto | Qué hacer | Por qué importa |
|---|---|---|
| Registro de gestores en Madrid | Preguntar en la DG de Vivienda y Rehabilitación | Condiciona si Cimenta puede llamarse «gestor de la rehabilitación» |
| Dirección y teléfono públicos | Decidir cuáles se usan | Sin ellos no hay Perfil de Empresa ni confianza ante una junta |
| Identificación LSSI en el aviso legal | Denominación, NIF y domicilio | Lo exige el art. 10 de la LSSI |
| Revisión legal de `/audita-tu-oferta` | Que un abogado revise la página | La disciplina de «solo aritmética verificable» protege, pero conviene refrendarla |
| Política de cookies | Reescribirla el día que enciendas anuncios | Hoy dice que no usas cookies de seguimiento |
| Presupuesto de anuncios | Confirmar 1.000 €/mes × 3 meses | Por debajo no hay datos para optimizar |

---

*Documento interno de trabajo. No es asesoramiento legal ni fiscal: las
secciones 4 y 10 deben confirmarse con un profesional antes de actuar.*
