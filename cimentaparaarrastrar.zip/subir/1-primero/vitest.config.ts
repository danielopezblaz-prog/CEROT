import path from "node:path";
import { defineConfig } from "vitest/config";

export default defineConfig({
  resolve: {
    alias: { "@": path.resolve(__dirname, "src") },
  },
  test: {
    environment: "node",
    include: ["src/**/*.prueba.ts"],
    env: { DATABASE_PATH: ":memory:", SESSION_SECRET: "secreto-de-pruebas-no-usar" },
  },
});
