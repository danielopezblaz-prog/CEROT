# Web pública de Cimenta

Sitio web de **Cimenta**, consultoría independiente en subvenciones a la rehabilitación en Madrid: identificamos y tramitamos las ayudas que le corresponden a cada comunidad de propietarios y comparamos los presupuestos de las empresas, con cobro por éxito.

Cimenta **no es agente rehabilitador** (figura del RD 853/2021 ligada a la cesión del derecho de cobro): no dirige obras ni percibe las ayudas en nombre de la comunidad.

El objetivo único de la web es generar **solicitudes del pre-informe gratuito**: cada sección empuja hacia el formulario final.

## Stack

- [Next.js 15](https://nextjs.org) (App Router) + TypeScript
- [Tailwind CSS 4](https://tailwindcss.com)
- [Framer Motion](https://www.framer.com/motion/) (scroll-storytelling del hero, reveals, count-ups)
- Solo fuentes del sistema e ilustraciones SVG propias — cero webfonts, cero fotos de stock

## Desarrollo

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # compilación de producción
npm start          # servir la compilación
```

## Cómo cambiar el copy

**Todo el texto de la web vive en [`src/content.ts`](src/content.ts)**: titulares, servicios, pasos, preguntas, formulario, páginas legales y metadatos SEO. Edita ese archivo y no toques componentes.

- Los fragmentos entre dobles asteriscos (`**así**`) se pintan en negrita.
- El email, el teléfono, la dirección y el dominio canónico están en el objeto `marca` (se usan en metadatos, sitemap, JSON-LD, pie y enlaces `mailto:`/`tel:`). **Teléfono y dirección están vacíos a propósito**: todo lo que los usa se oculta solo mientras falten, para no publicar datos inventados. Cuando existan, deben escribirse igual que en el Perfil de Empresa en Google.

## Páginas de aterrizaje

Cada búsqueda distinta necesita su página. Viven en
[`src/content-paginas.ts`](src/content-paginas.ts) y comparten shell, sistema
visual y formulario con la home — son puertas distintas a la misma casa, no
microsites.

| URL | Qué búsqueda ataca |
| --- | --- |
| `/plan-rehabilita-madrid` | La convocatoria, con su fecha de cierre real |
| `/simulador` | «cuánto cuesta rehabilitar mi fachada» |
| `/audita-tu-oferta` | «segunda opinión presupuesto obra» |
| `/administradores-de-fincas` | El canal prescriptor |
| `/agente-rehabilitador-o-gestor` | El término que la marca no usa, captado explicándolo |

Añadir una página = añadir una entrada a `PAGINAS` + una carpeta en `src/app/`
con cuatro líneas. **El sitemap y el pie se rellenan solos.**

La constante `PUEDE_LLAMARSE_GESTOR` controla si Cimenta se describe como
«gestor de la rehabilitación». Está en `false` hasta confirmar si la Comunidad
de Madrid exige inscripción en un registro de gestores
(ver [`docs/LANZAMIENTO.md`](docs/LANZAMIENTO.md) §2).

## Analítica

[`src/components/Analitica.tsx`](src/components/Analitica.tsx) no carga nada
mientras no configures `NEXT_PUBLIC_ANALITICA_*`. Está pensada para
herramientas de medición de audiencia **sin cookies** (Plausible, Umami,
Matomo autoalojado), que se acogen a la exención de consentimiento de la guía
de la AEPD y por eso **no necesitan banner**.

Google Analytics, el píxel de Meta y las conversiones de Google Ads **no**
entran ahí: exigen banner con CMP certificado y Consent Mode v2, y obligan a
reescribir la sección de cookies de la política de privacidad.

La medición que de verdad importa no necesita navegador: cada lead guarda sus
UTM y el panel del CRM los agrupa por campaña, así que el coste por mandato
firmado sale de cruzar esa tabla con el gasto de cada campaña.

## Constantes del simulador

Las fórmulas del mini-simulador («¿Cuánto pagaría cada vecino?») están en constantes editables al inicio de [`src/components/Simulador.tsx`](src/components/Simulador.tsx):

| Constante | Qué controla |
| --- | --- |
| `OBRAS` | Coste fijo por edificio, coste por vivienda y % de ayuda de cada alcance (fachada, fachada + cubierta, integral) |
| `VIVIENDAS` | Mínimo, máximo y valor inicial del control de viviendas |
| `IMPORTE` | Rango y paso del importe medio de obra por vivienda |
| `TRAMOS` | % de ayuda y tope por vivienda de cada tramo de ahorro (40/65/80 %) |
| `PLAZOS` / `INTERES_ANUAL` | Plazos ofrecidos e interés de la financiación de comunidad |
| `MESES_PUENTE` | Meses que la comunidad adelanta la parte subvencionada si no hay anticipo |

Son **valores orientativos de ejemplo** (marcados con `TODO`): ajústalos con datos reales antes de campañas. Las cifras del contador del hero (derrama/cuota de ejemplo) se cambian en `hero.contador` dentro de `content.ts`.

## Formulario y envío de leads

El formulario es una **ficha única** de tres bloques (edificio → tú → dónde te
respondemos) que hace `POST /api/lead`
([`src/app/api/lead/route.ts`](src/app/api/lead/route.ts)). Valida, filtra spam
(campo señuelo), guarda el consentimiento con fecha y crea el lead en el CRM
con sus parámetros UTM de origen. Los textos se editan en `formulario` dentro
de `content.ts`.

Al enviarse correctamente lleva a **`/solicitud-recibida`**, una página de
gracias con URL propia: es el destino estable contra el que se miden las
conversiones de anuncios, y evita que recargar reenvíe la solicitud.

El aviso por email sale por [Resend](https://resend.com) si defines
`RESEND_API_KEY` ([`src/lib/crm/correo.ts`](src/lib/crm/correo.ts)); sin clave
queda registrado en el log del servidor. Configura **SPF, DKIM y DMARC** en el
dominio o los avisos acabarán en spam.

## Despliegue

**Este repositorio es web pública + CRM en la misma aplicación, y el CRM
guarda su base de datos en un fichero SQLite.** Eso descarta las plataformas
con sistema de ficheros efímero: allí los leads se perderían en cada
despliegue.

Vía recomendada: un nodo con disco persistente (Railway, Fly.io, Render o un
VPS). Hay [`Dockerfile`](Dockerfile) listo, con `output: "standalone"`; solo
hay que **montar un volumen en `/datos`**.

```bash
docker build -t cimenta .
docker run -p 3000:3000 -v cimenta-datos:/datos \
  -e SESSION_SECRET=... -e RESEND_API_KEY=... cimenta
```

El checklist completo de lanzamiento —dominio, SPF/DKIM/DMARC, analítica,
Perfil de Empresa en Google, anuncios y calendario— está en
[`docs/LANZAMIENTO.md`](docs/LANZAMIENTO.md).

Antes de publicar en el dominio definitivo, revisa `marca.dominio` en `src/content.ts` (afecta a canónicas, Open Graph, `robots.txt` y `sitemap.xml`). La imagen Open Graph que se sirve es [`public/og.png`](public/og.png) (1200×630), porque varias plataformas no aceptan SVG. Su fuente editable es [`public/og.svg`](public/og.svg): edita el SVG y regenera el PNG con `sharp`, que ya viene con Next.js —

```bash
node -e 'const s=require("sharp"),f=require("fs");s(f.readFileSync("public/og.svg")).png({compressionLevel:9}).toFile("/tmp/og.png").then(()=>f.copyFileSync("/tmp/og.png","public/og.png"))'
```

## Accesibilidad y movimiento

- HTML semántico con landmarks, labels en todos los campos, foco visible y contraste AA sobre papel y sobre tinta.
- Con `prefers-reduced-motion` activado, toda la web es estática: el hero muestra directamente el edificio rehabilitado con sus anotaciones.
- La pieza de scroll del hero anima solo `transform`/`opacity` (más el trazado de líneas SVG) para mantener 60 fps.

---

# CRM interno de leads (`/crm`)

CRM privado del equipo de Cimenta, dentro de este mismo repositorio. Captura
automáticamente todos los leads del formulario público y permite gestionarlos
de principio a fin: listado con filtros, ficha con cronología, tareas,
pipeline Kanban, dashboard, exportación CSV y gestión de usuarios.

## Stack del CRM

- Next.js 15 (App Router) + React 19 + TypeScript — el mismo de la web.
- **SQLite** (better-sqlite3) con **Drizzle ORM** y migraciones (`drizzle-kit`).
- Sesiones **JWT firmadas (jose)** en cookie `httpOnly` + contraseñas **bcrypt**.
- Sin dependencias de UI nuevas: tokens y componentes de la propia web.

## Instalación y arranque

```bash
npm install
cp .env.example .env.local     # y rellena SESSION_SECRET
npm run db:seed                # datos de DESARROLLO (ver credenciales abajo)
npm run dev                    # http://localhost:3000/crm
```

Las migraciones se aplican solas al arrancar (carpeta `src/db/migraciones`).
Tras cambiar `src/db/esquema.ts`, regenera con `npm run db:generar`.

## Variables de entorno (`.env.example`)

| Variable | Obligatoria | Para qué |
|---|---|---|
| `SESSION_SECRET` | En producción | Firma de sesiones (≥ 16 caracteres; `openssl rand -base64 32`) |
| `DATABASE_PATH` | No | Ruta del fichero SQLite (por defecto `datos/crm.db`) |
| `RESEND_API_KEY` | No | Avisos por email vía Resend; sin clave, los avisos van al log |
| `CRM_EMAIL_AVISOS` | Con Resend | Buzón que recibe los avisos de nuevo lead |
| `CRM_EMAIL_REMITENTE` | No | Remitente de los avisos |
| `ADMIN_NOMBRE/EMAIL/CONTRASENA` | Solo `db:admin` | Alta del primer administrador |

## Primer administrador (producción)

```bash
ADMIN_NOMBRE="Nombre Real" ADMIN_EMAIL="correo@cimenta.es" \
ADMIN_CONTRASENA="una-contraseña-larga" npm run db:admin
```

Credenciales de las semillas de **desarrollo** (`npm run db:seed`, nunca en
producción): `admin@cimenta.dev / cimenta-admin-dev`,
`carlos@cimenta.dev / cimenta-carlos-dev`, `lucia@cimenta.dev / cimenta-lucia-dev`.

## Comandos

```bash
npm run dev        # desarrollo
npm run build      # compilación de producción
npm run lint       # ESLint
npm run typecheck  # tsc --noEmit
npm run test       # Vitest (BD en memoria)
npm run db:generar # regenerar migraciones desde el esquema
npm run db:seed    # semillas de desarrollo
npm run db:admin   # primer admin de producción
```

## Cómo se conecta un formulario al CRM

`POST /api/lead` con JSON: `nombre` y `contacto` (email o teléfono)
obligatorios; opcionales `rol`, `direccion`, `viviendas`, `simulacion`,
`consentimiento` (boolean), `origen` (`{url, referrer, utmSource, utmMedium,
utmCampaign, utmTerm, utmContent}`) y el señuelo `referencia` (déjalo vacío;
si llega relleno la petición se ignora en silencio). El lead entra en estado
`Nuevo`, se normaliza el contacto, se marcan posibles duplicados y, si la base
de datos fallara, los datos quedan íntegros en un log estructurado además de
intentarse un aviso por email: ningún lead se pierde.

Los estados del pipeline, tipos de tarea, prioridades y fuentes viven
centralizados en `src/db/catalogo.ts` — ampliar el CRM es tocar ese archivo.

## Pipeline del ciclo real de venta

`Nuevo → Contactado → Visita programada → Pre-informe entregado → En junta →
Mandato firmado (ganado) | Perdido | No válido` (motivo obligatorio al perder).

## Roles y permisos

- **admin**: todo, incluido eliminar leads (borrado lógico), exportar CSV y
  gestionar usuarios (crear, editar, activar/desactivar; sin borrado físico).
- **comercial**: ve y gestiona todos los leads (criterio acordado: visibilidad
  global con filtro «Mis leads»), sin eliminar/exportar/usuarios.
- La autorización se aplica en el servidor en cada página, acción y endpoint;
  el middleware solo corta el paso sin sesión válida.

## Despliegue

Pensado para un nodo con disco persistente (el fichero SQLite vive en
`datos/`): Railway, Fly.io, Render o un VPS con `npm run build && npm start`.

**Plataformas sin disco (Vercel y similares)**: el sistema de ficheros es
efímero — SQLite no persiste. Migración prevista: cambiar `src/db/indice.ts`
y el esquema a `drizzle-orm/pg-core` con Postgres gestionado (Neon o Supabase;
Vercel retiró su propio Postgres) y regenerar migraciones; el resto de la
aplicación no cambia porque todo el acceso pasa por Drizzle.

## RGPD y servicios externos (revisión legal pendiente)

- Consentimiento del formulario registrado con fecha (`consentimiento_en`).
- Borrado/anonimización a petición del interesado: eliminar el lead desde el
  CRM (borrado lógico) y, si se exige supresión total, borrar la fila y su
  historial en la base de datos — documentado aquí como procedimiento manual.
- Datos personales que salen del sistema: **Resend** (si se configura) recibe
  nombre, contacto y dirección en el email de aviso. No hay más terceros.
- Los accesos y las exportaciones quedan en el log de actividad.
- Este README documenta buenas prácticas técnicas; la revisión jurídica
  (textos legales, registro de tratamientos) queda fuera del alcance del MVP.

## Riesgos conocidos

- Rate limiting en memoria: por instancia; suficiente para el volumen actual.
- SQLite = un solo nodo con disco; el camino a Postgres está descrito arriba.
- El aviso por email depende de configurar Resend; sin clave solo hay log.
