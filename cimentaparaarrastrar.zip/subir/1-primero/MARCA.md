# Ecosistema de marca — Cimenta

Guía breve para generar piezas de marca (logos, aplicaciones, imágenes y vídeo) coherentes con la web. Incluye prompts listos para herramientas de IA generativa.

## Concepto

**La malla verde de obra.** La tela que cubre los andamios y que en España significa «este edificio se está rehabilitando». Todo el lenguaje visual nace del mundo de los planos de obra: alzados en línea fina, cotas, líneas de anotación con puntos de referencia, tramas diagonales a 45°, sellos de expediente en monospace. Tono: técnico pero cercano; transparente, sin humo.

## Paleta (tokens exactos)

| Uso | Nombre | Valor |
| --- | --- | --- |
| Fondo papel | `papel` | `#f7f7f4` |
| Superficies | `superficie` | `#ffffff` |
| Lavado verde | `lavado` | `#edf3ee` |
| Tinta (texto) | `tinta` | `#18211c` |
| Gris secundario | `gris` | `#5b6862` |
| Líneas | `linea` | `rgba(24,33,28,.1)` |
| Verde principal | `verde` | `#25714f` |
| Verde hover | `verde-oscuro` | `#1b5038` |
| Malla | `malla` | `#7ec9a3` |

**Prohibido:** gradientes morados/azules, glassmorphism, serifas, modo oscuro, fotos de stock, estética de plantilla de agencia.

## Tipografía

- **Display:** sans del sistema (`-apple-system` / `system-ui`), peso 800, tracking −0,02 em.
- **Etiquetas y cotas:** monospace (`ui-monospace`), mayúsculas, letter-spacing amplio (0,14–0,16 em).
- Cero webfonts.

## Logotipo

- **Marca:** cuadrado verde `#25714f` con esquinas redondeadas y trama de malla (líneas diagonales blancas al 50 % de opacidad, a 45°, paso ~5 px).
- **Lockup:** marca + «Cimenta» (sans 800) + «CONSULTORES EN REHABILITACIÓN» debajo en monospace pequeño, mayúsculas, tracking amplio, gris.
- Versión negativa: sobre tinta `#18211c`, la marca mantiene el verde y el texto pasa a blanco/malla.

## Motivos recurrentes

- Alzado de edificio madrileño en línea fina (bajo + 4 plantas, balcones con barandilla, cornisa, antena).
- Andamio de líneas verdes y malla desplegada (trama diagonal `#7ec9a3` sobre lavado).
- Cotas con terminadores en barra, líneas de referencia con punto y codo, chips de anotación en monospace.
- Sellos con borde discontinuo y ligera rotación («EXPEDIENTE CERRADO · AYUDA COBRADA»).

## Archivos del logotipo (`marca/`)

| Archivo | Uso |
| --- | --- |
| `logo-cimenta.svg` | Lockup principal horizontal, sobre papel o superficies claras |
| `logo-cimenta-negativo.svg` | Lockup para fondos tinta o fotografías oscuras |
| `logo-cimenta-vertical.svg` | Versión apilada para portadas y espacios cuadrados |
| `marca-cimenta.svg` | Marca sola en verde (avatares, sello, tamaños pequeños) |
| `marca-cimenta-tinta.svg` / `marca-cimenta-blanca.svg` | Monocromos para casos especiales |
| `sello-cimenta.svg` | Sello circular «Cimenta · Consultores en rehabilitación · Madrid» |

Normas rápidas: área de respeto de media marca (½ M) por cada lado; mínimo digital de la marca sola 24 px y del lockup 110 px; los textos del SVG usan la sans del sistema — **convertir a trazados antes de enviar a imprenta**. No deformar, no recolorear, no aplicar sombras ni degradados.

## Prompts para IA generativa (Google Flow, Gemini, etc.)

**Logo / marca (ES):**
> Logotipo minimalista para «Cimenta», consultoría independiente en subvenciones a la rehabilitación de edificios en Madrid. Un cuadrado verde oscuro (#25714f) de esquinas redondeadas cubierto por una trama fina de líneas diagonales blancas a 45°, como la malla verde que cubre los andamios. Al lado, la palabra «Cimenta» en una sans grotesca muy negra (peso 800, tracking apretado), color casi negro verdoso (#18211c), y debajo «CONSULTORES EN REHABILITACIÓN» en monospace pequeño, mayúsculas, espaciado amplio, gris (#5b6862). Fondo papel (#f7f7f4). Estilo plano, sin degradados, sin sombras, sin 3D.

**Imagen de marca / escena (ES):**
> Ilustración técnica en estilo de plano de arquitectura: alzado de un edificio residencial madrileño dibujado a línea fina color tinta (#18211c) sobre fondo papel (#f7f7f4), con balcones y cornisa. La mitad del edificio está cubierta por un andamio de líneas verdes (#25714f) y una malla de obra semitransparente con trama diagonal verde claro (#7ec9a3). Cotas de plano, pequeñas anotaciones en tipografía monospace mayúscula y un sello de borde discontinuo verde. Composición limpia, mucho aire, sin personas, sin texturas fotográficas, sin degradados morados o azules.

**Vídeo corto (Flow, ES):**
> Animación limpia estilo plano técnico sobre fondo papel (#f7f7f4): un alzado de edificio madrileño se dibuja a línea fina; aparecen grietas; un andamio de líneas verdes (#25714f) se traza pieza a pieza y una malla verde (#7ec9a3, trama diagonal) lo cubre de arriba abajo; al final la malla se retira y el edificio queda limpio con detalles verdes y un sello «EXPEDIENTE CERRADO». Ritmo sereno, cámara fija, sin 3D realista, sin texto adicional, sin música mostrada.

Consejo: genera siempre sobre fondo `#f7f7f4` o `#18211c`, pide «flat vector style, thin line technical drawing» si la herramienta deriva a foto-realismo, y descarta cualquier resultado con degradados azules/morados o serifas.
